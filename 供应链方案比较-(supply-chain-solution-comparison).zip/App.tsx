
import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { Criterion, Solution, SolutionCriterionScore, ModalType } from './types';
import { analyzeSolutionsWithGemini } from './services/geminiService';
import Header from './components/Header';
import Footer from './components/Footer';
import Modal from './components/Modal';
import Spinner from './components/Spinner';
import Alert from './components/Alert';
import PlusIcon from './components/icons/PlusIcon';
import TrashIcon from './components/icons/TrashIcon';
import EditIcon from './components/icons/EditIcon';
import LightbulbIcon from './components/icons/LightbulbIcon';
import { parse as markedParse } from 'marked';

const App: React.FC = () => {
  const [criteria, setCriteria] = useState<Criterion[]>([]);
  const [solutions, setSolutions] = useState<Solution[]>([]);
  
  const [activeModal, setActiveModal] = useState<ModalType>(ModalType.NONE);
  const [currentCriterion, setCurrentCriterion] = useState<Criterion | null>(null);
  const [criterionName, setCriterionName] = useState<string>('');
  
  const [currentSolution, setCurrentSolution] = useState<Solution | null>(null);
  const [solutionName, setSolutionName] = useState<string>('');
  const [solutionDescription, setSolutionDescription] = useState<string>('');
  const [solutionScores, setSolutionScores] = useState<SolutionCriterionScore[]>([]);

  const [geminiAnalysis, setGeminiAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [userFocus, setUserFocus] = useState<string>('');
  
  const [appError, setAppError] = useState<string | null>(null);

  // Load from localStorage
  useEffect(() => {
    try {
      const storedCriteria = localStorage.getItem('supplyChainCriteria');
      if (storedCriteria) {
        setCriteria(JSON.parse(storedCriteria));
      }
      const storedSolutions = localStorage.getItem('supplyChainSolutions');
      if (storedSolutions) {
        setSolutions(JSON.parse(storedSolutions));
      }
    } catch (error) {
        console.error("Failed to load data from localStorage", error);
        setAppError("Failed to load saved data. Your data might be corrupted.");
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('supplyChainCriteria', JSON.stringify(criteria));
    } catch (error) {
      console.error("Failed to save criteria to localStorage", error);
      setAppError("Failed to save criteria. Your changes might not persist.");
    }
  }, [criteria]);

  useEffect(() => {
    try {
      localStorage.setItem('supplyChainSolutions', JSON.stringify(solutions));
    } catch (error) {
      console.error("Failed to save solutions to localStorage", error);
      setAppError("Failed to save solutions. Your changes might not persist.");
    }
  }, [solutions]);


  const openModal = (type: ModalType, data?: Criterion | Solution) => {
    setActiveModal(type);
    setAppError(null); 
    if (type === ModalType.ADD_CRITERION) {
      setCriterionName('');
      setCurrentCriterion(null);
    } else if (type === ModalType.EDIT_CRITERION && data && 'name' in data) {
      setCurrentCriterion(data as Criterion);
      setCriterionName((data as Criterion).name);
    } else if (type === ModalType.ADD_SOLUTION) {
      setCurrentSolution(null);
      setSolutionName('');
      setSolutionDescription('');
      setSolutionScores(criteria.map(c => ({ criterionId: c.id, value: '' })));
    } else if (type === ModalType.EDIT_SOLUTION && data && 'scores' in data) {
      const sol = data as Solution;
      setCurrentSolution(sol);
      setSolutionName(sol.name);
      setSolutionDescription(sol.description);
      const updatedScores = criteria.map(c => {
        const existingScore = sol.scores.find(s => s.criterionId === c.id);
        return existingScore || { criterionId: c.id, value: '' };
      });
      setSolutionScores(updatedScores);
    }
  };

  const closeModal = () => {
    setActiveModal(ModalType.NONE);
    setCurrentCriterion(null);
    setCurrentSolution(null);
    setCriterionName('');
    setSolutionName('');
    setSolutionDescription('');
    setSolutionScores([]);
  };

  const handleCriterionSubmit = () => {
    if (!criterionName.trim()) {
      setAppError("Criterion name cannot be empty.");
      return;
    }
    if (currentCriterion) { 
      setCriteria(criteria.map(c => c.id === currentCriterion.id ? { ...c, name: criterionName.trim() } : c));
    } else { 
      if (criteria.some(c => c.name.toLowerCase() === criterionName.trim().toLowerCase())) {
        setAppError("Criterion with this name already exists.");
        return;
      }
      const newCriterion: Criterion = { id: Date.now().toString(), name: criterionName.trim() };
      setCriteria([...criteria, newCriterion]);
      setSolutions(prevSolutions => prevSolutions.map(sol => ({
        ...sol,
        scores: [...sol.scores, { criterionId: newCriterion.id, value: '' }]
      })));
    }
    closeModal();
  };

  const deleteCriterion = (id: string) => {
    if (window.confirm("Are you sure you want to delete this criterion? This will also remove its scores from all solutions.")) {
      setCriteria(criteria.filter(c => c.id !== id));
      setSolutions(solutions.map(s => ({
        ...s,
        scores: s.scores.filter(score => score.criterionId !== id)
      })));
    }
  };
  
  const handleSolutionScoreChange = (criterionId: string, value: string) => {
    setSolutionScores(prevScores => 
      prevScores.map(score => score.criterionId === criterionId ? { ...score, value } : score)
    );
  };

  const handleSolutionSubmit = () => {
    if (!solutionName.trim()) {
      setAppError("Solution name cannot be empty.");
      return;
    }
    const finalScores = solutionScores.map(s => ({...s, value: s.value.toString()}));

    if (currentSolution) { 
      setSolutions(solutions.map(s => s.id === currentSolution.id ? { ...s, name: solutionName.trim(), description: solutionDescription.trim(), scores: finalScores } : s));
    } else { 
      if (solutions.some(s => s.name.toLowerCase() === solutionName.trim().toLowerCase())) {
        setAppError("Solution with this name already exists.");
        return;
      }
      const newSolution: Solution = { 
        id: Date.now().toString(), 
        name: solutionName.trim(), 
        description: solutionDescription.trim(), 
        scores: finalScores 
      };
      setSolutions([...solutions, newSolution]);
    }
    closeModal();
  };

  const deleteSolution = (id: string) => {
    if (window.confirm("Are you sure you want to delete this solution?")) {
      setSolutions(solutions.filter(s => s.id !== id));
    }
  };

  const handleAnalyze = useCallback(async () => {
    if (solutions.length === 0 || criteria.length === 0) {
      setAnalysisError("Please add criteria and solutions before analyzing.");
      return;
    }
    setIsAnalyzing(true);
    setAnalysisError(null);
    setGeminiAnalysis('');
    try {
      const result = await analyzeSolutionsWithGemini(criteria, solutions, userFocus);
      setGeminiAnalysis(result);
    } catch (error: any) {
      setAnalysisError(error.toString() || "Failed to get analysis from Gemini.");
    } finally {
      setIsAnalyzing(false);
    }
  }, [criteria, solutions, userFocus]);

  const analysisHtml = useMemo(() => {
    if (!geminiAnalysis) return '';
    // Use marked to parse markdown to HTML
    // gfm: true enables GitHub Flavored Markdown (tables, strikethrough, etc.)
    // breaks: true makes single newlines in markdown render as <br> tags
    // pedantic: false is less strict about markdown formatting
    return markedParse(geminiAnalysis, { gfm: true, breaks: true, pedantic: false });
  }, [geminiAnalysis]);


  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        {appError && <Alert message={appError} type="error" onClose={() => setAppError(null)} />}

        <section className="mb-8 p-6 bg-white shadow-lg rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-semibold text-gray-800">Comparison Criteria</h2>
            <button
              onClick={() => openModal(ModalType.ADD_CRITERION)}
              className="bg-primary-600 hover:bg-primary-700 text-white font-semibold py-2 px-4 rounded-md shadow-md flex items-center transition duration-150 ease-in-out"
            >
              <PlusIcon className="w-5 h-5 mr-2" /> Add Criterion
            </button>
          </div>
          {criteria.length === 0 ? (
            <p className="text-gray-600">No criteria added yet. Add criteria to start comparing solutions.</p>
          ) : (
            <ul className="space-y-2">
              {criteria.map(c => (
                <li key={c.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md border border-gray-200">
                  <span className="text-gray-700">{c.name}</span>
                  <div className="space-x-2">
                    <button onClick={() => openModal(ModalType.EDIT_CRITERION, c)} className="text-blue-500 hover:text-blue-700"><EditIcon className="w-5 h-5"/></button>
                    <button onClick={() => deleteCriterion(c.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-5 h-5"/></button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="mb-8 p-6 bg-white shadow-lg rounded-lg">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-800">Supply Chain Solutions</h2>
            <button
              onClick={() => openModal(ModalType.ADD_SOLUTION)}
              disabled={criteria.length === 0}
              className={`bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-md shadow-md flex items-center transition duration-150 ease-in-out ${criteria.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <PlusIcon className="w-5 h-5 mr-2" /> Add Solution
            </button>
          </div>
          {criteria.length === 0 && <p className="text-sm text-yellow-600 bg-yellow-50 p-3 rounded-md">Please add at least one criterion before adding solutions.</p>}
          
          {solutions.length === 0 ? (
            <p className="text-gray-600 mt-4">No solutions added yet.</p>
          ) : (
            <div className="overflow-x-auto mt-4">
              <table className="min-w-full divide-y divide-gray-200 border border-gray-300">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Solution Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Description</th>
                    {criteria.map(c => (
                      <th key={c.id} className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider whitespace-nowrap">{c.name}</th>
                    ))}
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {solutions.map(s => (
                    <tr key={s.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{s.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-700 max-w-xs truncate" title={s.description}>{s.description || '-'}</td>
                      {criteria.map(c => {
                        const score = s.scores.find(sc => sc.criterionId === c.id);
                        return <td key={`${s.id}-${c.id}`} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{score ? score.value : '-'}</td>;
                      })}
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <button onClick={() => openModal(ModalType.EDIT_SOLUTION, s)} className="text-blue-600 hover:text-blue-800"><EditIcon className="w-5 h-5"/></button>
                        <button onClick={() => deleteSolution(s.id)} className="text-red-600 hover:text-red-800"><TrashIcon className="w-5 h-5"/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="p-6 bg-white shadow-lg rounded-lg">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">AI-Powered Analysis (Gemini)</h2>
          {analysisError && <Alert message={analysisError} type="error" onClose={() => setAnalysisError(null)} />}
          
          <div className="mb-4">
            <label htmlFor="userFocus" className="block text-sm font-medium text-gray-700 mb-1">
              Optional: What is your primary focus or key question for the AI? (e.g., "Which solution is best for cost-sensitive operations?")
            </label>
            <input
              type="text"
              id="userFocus"
              value={userFocus}
              onChange={(e) => setUserFocus(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="Enter your focus here..."
            />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing || solutions.length === 0 || criteria.length === 0}
            className={`bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded-md shadow-md flex items-center justify-center transition duration-150 ease-in-out w-full sm:w-auto
              ${(isAnalyzing || solutions.length === 0 || criteria.length === 0) ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isAnalyzing ? <Spinner size="sm" color="text-white"/> : <LightbulbIcon className="w-5 h-5 mr-2" />}
            {isAnalyzing ? 'Analyzing...' : 'Get Gemini Analysis'}
          </button>
          
          {geminiAnalysis && (
            <div className="mt-6 p-4 border border-gray-200 rounded-md bg-gray-50">
              <h3 className="text-xl font-semibold text-gray-700 mb-3">Gemini Analysis:</h3>
              <div 
                className="prose prose-sm max-w-none text-gray-800"
                dangerouslySetInnerHTML={{ __html: analysisHtml }} 
              />
            </div>
          )}
        </section>

      </main>
      <Footer />

      <Modal 
        isOpen={activeModal === ModalType.ADD_CRITERION || activeModal === ModalType.EDIT_CRITERION}
        onClose={closeModal}
        title={currentCriterion ? "Edit Criterion" : "Add New Criterion"}
      >
        <div className="space-y-4">
          <div>
            <label htmlFor="criterionName" className="block text-sm font-medium text-gray-700">Criterion Name</label>
            <input
              type="text"
              id="criterionName"
              value={criterionName}
              onChange={(e) => setCriterionName(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="e.g., Cost, Lead Time, Scalability"
            />
          </div>
          {appError && activeModal !== ModalType.NONE && (
             <p className="text-sm text-red-600">{appError}</p>
          )}
          <div className="flex justify-end space-x-2 pt-2">
            <button onClick={closeModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md border border-gray-300">Cancel</button>
            <button onClick={handleCriterionSubmit} className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-md shadow-sm">
              {currentCriterion ? 'Save Changes' : 'Add Criterion'}
            </button>
          </div>
        </div>
      </Modal>

      <Modal
        isOpen={activeModal === ModalType.ADD_SOLUTION || activeModal === ModalType.EDIT_SOLUTION}
        onClose={closeModal}
        title={currentSolution ? "Edit Solution" : "Add New Solution"}
        size="2xl"
      >
        <div className="space-y-6">
          <div>
            <label htmlFor="solutionName" className="block text-sm font-medium text-gray-700">Solution Name</label>
            <input
              type="text"
              id="solutionName"
              value={solutionName}
              onChange={(e) => setSolutionName(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="e.g., In-house Logistics, Third-Party Logistics (3PL)"
            />
          </div>
          <div>
            <label htmlFor="solutionDescription" className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              id="solutionDescription"
              value={solutionDescription}
              onChange={(e) => setSolutionDescription(e.target.value)}
              rows={3}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="Brief description of the solution"
            />
          </div>
          <div>
            <h4 className="text-md font-medium text-gray-700 mb-2">Scores/Values for Criteria:</h4>
            {criteria.length > 0 ? (
              <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                {criteria.map(c => {
                  const currentScore = solutionScores.find(s => s.criterionId === c.id);
                  return (
                    <div key={c.id}>
                      <label htmlFor={`score-${c.id}`} className="block text-sm font-medium text-gray-600">{c.name}</label>
                      <input
                        type="text"
                        id={`score-${c.id}`}
                        value={currentScore?.value || ''}
                        onChange={(e) => handleSolutionScoreChange(c.id, e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        placeholder={`Value for ${c.name} (e.g., Low, 5/10, $100k)`}
                      />
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-gray-500">No criteria defined. Please add criteria first.</p>
            )}
          </div>
          {appError && activeModal !== ModalType.NONE && (
             <p className="text-sm text-red-600">{appError}</p>
          )}
          <div className="flex justify-end space-x-2 pt-4 border-t">
            <button onClick={closeModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md border border-gray-300">Cancel</button>
            <button onClick={handleSolutionSubmit} className="px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-md shadow-sm">
              {currentSolution ? 'Save Changes' : 'Add Solution'}
            </button>
          </div>
        </div>
      </Modal>

    </div>
  );
};

export default App;