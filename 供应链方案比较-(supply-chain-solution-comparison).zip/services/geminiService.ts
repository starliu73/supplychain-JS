
import { GoogleGenAI, GenerateContentResponse, Part } from "@google/genai";
import { Criterion, Solution } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not found. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" }); // Fallback to prevent crash if API_KEY is undefined

export const analyzeSolutionsWithGemini = async (
  criteria: Criterion[],
  solutions: Solution[],
  userFocus?: string
): Promise<string> => {
  if (!API_KEY) {
    return Promise.reject("Gemini API Key is not configured. Please set the API_KEY environment variable.");
  }
  if (criteria.length === 0 || solutions.length === 0) {
    return Promise.resolve("Please add at least one criterion and one solution to get an analysis.");
  }

  const promptParts: Part[] = [];

  let prompt = `You are an expert supply chain analyst. Please provide a detailed comparison of the following supply chain solutions based on the given criteria.

**Criteria:**
${criteria.map(c => `- ${c.name}`).join('\n')}

**Solutions:**
`;

  solutions.forEach(s => {
    prompt += `
Solution: ${s.name}
Description: ${s.description}
${s.scores.map(score => {
  const crit = criteria.find(c => c.id === score.criterionId);
  return crit ? `  - ${crit.name}: ${score.value || 'Not specified'}` : '';
}).filter(Boolean).join('\n')}
`;
  });

  if (userFocus && userFocus.trim() !== "") {
    prompt += `\n**User's Primary Focus / Key Question:** ${userFocus}\n`;
  }

  prompt += `
**Analysis Request:**
Please provide:
1.  A brief summary of each solution.
2.  A comparative analysis highlighting strengths and weaknesses of each solution against the criteria.
3.  Consider the user's primary focus (if provided) in your recommendation.
4.  A concluding recommendation for the best solution(s) based on this information, explaining your reasoning.

Format your response using markdown for clarity (e.g., headings, bullet points).
`;
  
  promptParts.push({ text: prompt });

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: [{ role: "user", parts: promptParts }],
      // config: { temperature: 0.7 } // Optional: adjust temperature for creativity
    });
    
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        return Promise.reject(`Error analyzing solutions with Gemini: ${error.message}`);
    }
    return Promise.reject("An unknown error occurred while analyzing solutions with Gemini.");
  }
};
