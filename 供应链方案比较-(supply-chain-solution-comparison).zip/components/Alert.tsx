
import React from 'react';

interface AlertProps {
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
  onClose?: () => void;
}

const Alert: React.FC<AlertProps> = ({ message, type, onClose }) => {
  const baseClasses = "p-4 rounded-md flex items-center justify-between";
  const typeClasses = {
    success: "bg-green-100 text-green-700",
    error: "bg-red-100 text-red-700",
    info: "bg-blue-100 text-blue-700",
    warning: "bg-yellow-100 text-yellow-700",
  };

  if (!message) return null;

  return (
    <div className={`${baseClasses} ${typeClasses[type]} mb-4`} role="alert">
      <span>{message}</span>
      {onClose && (
        <button
          onClick={onClose}
          className={`ml-4 p-1 rounded-md hover:bg-opacity-20 ${
            type === 'success' ? 'hover:bg-green-200' :
            type === 'error' ? 'hover:bg-red-200' :
            type === 'info' ? 'hover:bg-blue-200' : 'hover:bg-yellow-200'
          }`}
          aria-label="Close alert"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}
    </div>
  );
};

export default Alert;
