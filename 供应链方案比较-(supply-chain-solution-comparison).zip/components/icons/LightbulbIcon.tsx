
import React from 'react';

interface IconProps {
  className?: string;
}

const LightbulbIcon: React.FC<IconProps> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.355a7.5 7.5 0 0 1-3 0m3 0a7.5 7.5 0 0 0-3 0m.375 0a6.003 6.003 0 0 0-3.75 0m0 0h-.375m3.75 0h.375m-3.375 0a6.003 6.003 0 0 1 3.75 0m0 0c.621 0 1.192-.036 1.743-.105M1.806 13.553A11.969 11.969 0 0 1 5.25 6.842a11.969 11.969 0 0 1 11.318 1.906M1.806 13.553c.16.942.383 1.847.648 2.7M3 10.5a5.978 5.978 0 0 1 .634-2.577m2.846.362A9.752 9.752 0 0 1 12 5.25a9.752 9.752 0 0 1 5.52 2.035m0 0A5.978 5.978 0 0 1 21 10.5m-2.244-2.839A11.953 11.953 0 0 0 12 2.25C6.477 2.25 2.25 6.477 2.25 12c0 1.341.229 2.636.648 3.842M1.806 13.553 3.657 15H20.343l1.851-1.447" />
  </svg>
);

export default LightbulbIcon;
