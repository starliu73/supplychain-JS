
import React from 'react';
import LightbulbIcon from './icons/LightbulbIcon';

const Header: React.FC = () => {
  return (
    <header className="bg-primary-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-5 flex items-center justify-between">
        <div className="flex items-center space-x-2">
           <LightbulbIcon className="w-8 h-8 text-yellow-300" />
           <h1 className="text-2xl font-bold">供应链方案比较</h1>
        </div>
        <span className="text-sm text-primary-200">Supply Chain Solution Comparison</span>
      </div>
    </header>
  );
};

export default Header;
