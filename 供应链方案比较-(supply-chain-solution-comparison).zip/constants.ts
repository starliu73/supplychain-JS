
export const GEMINI_MODEL_NAME = "gemini-2.5-flash-preview-04-17";
// To enable search grounding, uncomment and use:
// export const GEMINI_MODEL_NAME_FOR_SEARCH = "gemini-2.5-flash-preview-04-17";
