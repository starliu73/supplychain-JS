
export interface Criterion {
  id: string;
  name: string;
}

export interface SolutionCriterionScore {
  criterionId: string;
  value: string; // Could be a numerical score as string, or descriptive text
}

export interface Solution {
  id: string;
  name: string;
  description: string;
  scores: SolutionCriterionScore[];
}

export enum ModalType {
  NONE,
  ADD_CRITERION,
  EDIT_CRITERION,
  ADD_SOLUTION,
  EDIT_SOLUTION,
}
