
import React, { useState, useCallback, useEffect } from 'react';
import { ExistingDC, PotentialDC, MIPSolution, SimulationScenario, SimulatedSolutionPerformance, AppStep } from './types';
import { APP_TITLE } from './constants';
import { generateMIPSolutions } from './services/mipService';
import { runSimulationsForSolution } from './services/simulationService';

import { Stepper } from './components/Stepper';
import { InitialConfigStep } from './components/InitialConfigStep';
import { MIPResultsStep } from './components/MIPResultsStep';
import { SimulationSetupStep } from './components/SimulationSetupStep';
import { SimulationResultsDisplay } from './components/SimulationResultsDisplay';
import { DecisionDashboardStep } from './components/DecisionDashboardStep';
import { CubeIcon } from './components/icons/CubeIcon';
import { ChartBarIcon } from './components/icons/ChartBarIcon';


const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<AppStep>(AppStep.INITIAL_CONFIG);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [existingDCs, setExistingDCs] = useState<ExistingDC[]>([]);
  const [potentialDCs, setPotentialDCs] = useState<PotentialDC[]>([]);
  
  const [mipSolutions, setMipSolutions] = useState<MIPSolution[]>([]);
  const [selectedMIPSolution, setSelectedMIPSolution] = useState<MIPSolution | null>(null);
  
  const [currentSimulationRunResults, setCurrentSimulationRunResults] = useState<SimulatedSolutionPerformance[]>([]);
  const [allSimulationResults, setAllSimulationResults] = useState<SimulatedSolutionPerformance[]>([]);


  const handleInitialConfigComplete = useCallback(async (existing: ExistingDC[], potential: PotentialDC[]) => {
    setExistingDCs(existing);
    setPotentialDCs(potential);
    setIsLoading(true);
    setCurrentStep(AppStep.MIP_RESULTS); 
    try {
      const solutions = await generateMIPSolutions(existing, potential);
      setMipSolutions(solutions);
    } catch (error) {
      console.error("生成MIP方案时出错:", error);
      setMipSolutions([]); 
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSelectMIPSolution = useCallback((solution: MIPSolution) => {
    setSelectedMIPSolution(solution);
    setCurrentSimulationRunResults([]); 
    setCurrentStep(AppStep.SIMULATION_SETUP);
  }, []);

  const handleRunSimulations = useCallback(async (scenarios: SimulationScenario[]) => {
    if (!selectedMIPSolution) return;
    setIsLoading(true);
    try {
      const results = await runSimulationsForSolution(selectedMIPSolution, scenarios);
      setCurrentSimulationRunResults(results);
      setAllSimulationResults(prevResults => {
        const updatedResultsForSolution = prevResults
            .filter(pr => pr.mipSolutionId !== selectedMIPSolution.id) 
            .concat(results); 
        return updatedResultsForSolution;
      });
      setCurrentStep(AppStep.SIMULATION_RESULTS);
    } catch (error) {
      console.error("运行仿真时出错:", error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedMIPSolution]);

  const handleProceedToDashboard = useCallback(() => {
    setCurrentStep(AppStep.DECISION_DASHBOARD);
  }, []);
  
  const handleSimulateAnotherSolution = useCallback(() => {
    setSelectedMIPSolution(null);
    setCurrentSimulationRunResults([]);
    setCurrentStep(AppStep.MIP_RESULTS);
  }, []);

  const navigateToStep = useCallback((step: AppStep) => {
    if (step === AppStep.DECISION_DASHBOARD && allSimulationResults.length === 0 && currentStep !== AppStep.SIMULATION_RESULTS) {
        setCurrentStep(AppStep.MIP_RESULTS);
        return;
    }
     if (step === AppStep.SIMULATION_SETUP && !selectedMIPSolution && mipSolutions.length > 0) {
        setCurrentStep(AppStep.MIP_RESULTS);
        return;
    }
    setCurrentStep(step);
  }, [allSimulationResults, selectedMIPSolution, mipSolutions, currentStep]);


  const renderCurrentStep = () => {
    switch (currentStep) {
      case AppStep.INITIAL_CONFIG:
        return <InitialConfigStep onConfigComplete={handleInitialConfigComplete} setStep={navigateToStep} />;
      case AppStep.MIP_RESULTS:
        return <MIPResultsStep mipSolutions={mipSolutions} onSelectSolution={handleSelectMIPSolution} isLoading={isLoading} setStep={navigateToStep}/>;
      case AppStep.SIMULATION_SETUP:
        if (!selectedMIPSolution) {
          setCurrentStep(AppStep.MIP_RESULTS);
          return <MIPResultsStep mipSolutions={mipSolutions} onSelectSolution={handleSelectMIPSolution} isLoading={false} setStep={navigateToStep}/>;
        }
        return <SimulationSetupStep selectedMIPSolution={selectedMIPSolution} onRunSimulations={handleRunSimulations} isLoading={isLoading} setStep={navigateToStep}/>;
      case AppStep.SIMULATION_RESULTS:
        if (!selectedMIPSolution) { 
             setCurrentStep(AppStep.MIP_RESULTS);
             return null;
        }
        return <SimulationResultsDisplay 
                    results={currentSimulationRunResults} 
                    mipSolutionName={selectedMIPSolution.name}
                    onProceedToDashboard={handleProceedToDashboard}
                    onSimulateAnother={handleSimulateAnotherSolution}
                />;
      case AppStep.DECISION_DASHBOARD:
        return <DecisionDashboardStep allSimulationResults={allSimulationResults} setStep={navigateToStep} />;
      default:
        return <InitialConfigStep onConfigComplete={handleInitialConfigComplete} setStep={navigateToStep} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center">
               <ChartBarIcon className="h-10 w-10 text-blue-600" />
              <h1 className="ml-3 text-2xl sm:text-3xl font-bold text-slate-800">{APP_TITLE}</h1>
            </div>
          </div>
        </div>
        <Stepper currentStep={currentStep} setStep={navigateToStep} />
      </header>

      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentStep()}
      </main>

      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-sm text-slate-500">
          &copy; {new Date().getFullYear()} 战略性DC评估工具。仅供演示。
        </div>
      </footer>
    </div>
  );
};

export default App;