
export interface DC {
  id: string;
  name: string;
  location: string;
  capacity: number; // Units (e.g., pallets, sqft)
  operatingCost: number; // Annual operating cost
}

export interface ExistingDC extends DC {}

export interface PotentialDC extends DC {
  capex: number; // Capital expenditure to build
}

export interface MIPSolution {
  id: string;
  name: string;
  description: string;
  openedDCs: PotentialDC[]; // DCs to be opened
  closedDCs: ExistingDC[]; // Existing DCs to be closed
  keptDCs: ExistingDC[];   // Existing DCs to be kept
  totalCapex: number;
  annualOpexChange: number; // Positive if new opex is higher, negative if lower
}

export interface SimulationScenario {
  id: string;
  name: string;
  durationYears: number;
  demandGrowthRate: number; // e.g., 0.05 for 5% annual growth
  disruptionFrequency: number; // events per year
  disruptionImpact: number; // e.g., 0.2 for 20% impact on operations
}

export interface SimulationResultMetrics {
  totalSimulatedCost: number; // NPV or total cost over simulation period
  resilienceScore: number; // 0.0 - 1.0 (e.g., uptime percentage)
  serviceLevelScore: number; // 0.0 - 1.0 (e.g., on-time delivery rate)
}

export interface SimulatedSolutionPerformance {
  mipSolutionId: string;
  mipSolutionName: string;
  simulationScenarioId: string;
  simulationScenarioName: string;
  metrics: SimulationResultMetrics;
}

export enum AppStep {
  INITIAL_CONFIG,
  MIP_RESULTS,
  SIMULATION_SETUP,
  SIMULATION_RESULTS,
  DECISION_DASHBOARD
}
