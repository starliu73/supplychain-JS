
import { ExistingDC, PotentialDC, MIPSolution } from '../types';

// Mock function to simulate MIP analysis
export const generateMIPSolutions = async (
  existingDCs: ExistingDC[],
  potentialDCs: PotentialDC[],
  // In a real scenario, more parameters like budget constraints, service levels etc. would be passed.
  numSolutionsToGenerate: number = 3
): Promise<MIPSolution[]> => {
  return new Promise(resolve => {
    setTimeout(() => {
      const solutions: MIPSolution[] = [];

      if (potentialDCs.length === 0 && existingDCs.length === 0) {
        resolve([]);
        return;
      }
      
      for (let i = 0; i < numSolutionsToGenerate; i++) {
        const opened: PotentialDC[] = [];
        const closed: ExistingDC[] = [];
        const kept: ExistingDC[] = [...existingDCs]; // Start with all existing DCs as kept

        let totalCapex = 0;
        let annualOpexChange = 0;

        if (i === 0 && potentialDCs.length > 0) {
          const toOpen = potentialDCs[0];
          opened.push(toOpen);
          totalCapex += toOpen.capex;
          annualOpexChange += toOpen.operatingCost;
        } else if (i === 1 && potentialDCs.length > 1 && existingDCs.length > 0) {
          const toOpen1 = potentialDCs[0];
          const toOpen2 = potentialDCs[1];
          opened.push(toOpen1, toOpen2);
          totalCapex += toOpen1.capex + toOpen2.capex;
          annualOpexChange += toOpen1.operatingCost + toOpen2.operatingCost;

          const toClose = existingDCs[0];
          closed.push(toClose);
          kept.splice(kept.findIndex(dc => dc.id === toClose.id), 1);
          annualOpexChange -= toClose.operatingCost;

        } else if (i === 2) {
            if (existingDCs.length > 0) {
                const toClose = existingDCs[existingDCs.length-1]; 
                closed.push(toClose);
                kept.splice(kept.findIndex(dc => dc.id === toClose.id), 1);
                annualOpexChange -= toClose.operatingCost;
            } else if (potentialDCs.length > 0) {
                const toOpen = potentialDCs[0];
                opened.push(toOpen);
                totalCapex += toOpen.capex;
                annualOpexChange += toOpen.operatingCost;
            }
        } else { 
            if (potentialDCs.length > i) {
                const toOpen = potentialDCs[i % potentialDCs.length];
                 opened.push(toOpen);
                 totalCapex += toOpen.capex;
                 annualOpexChange += toOpen.operatingCost;
            }
             if (existingDCs.length > i && i % 2 === 0) { 
                const toClose = existingDCs[i % existingDCs.length];
                if (!closed.find(c => c.id === toClose.id) && kept.find(k => k.id === toClose.id)) {
                    closed.push(toClose);
                    kept.splice(kept.findIndex(dc => dc.id === toClose.id), 1);
                    annualOpexChange -= toClose.operatingCost;
                }
            }
        }
        
        closed.forEach(closedDc => {
            const indexInKept = kept.findIndex(k => k.id === closedDc.id);
            if (indexInKept !== -1) {
                kept.splice(indexInKept, 1);
            }
        });

        const solutionName = `MIP方案 ${String.fromCharCode(65 + i)}`; // MIP Option -> MIP方案
        let descriptionParts = [];
        if (opened.length > 0) descriptionParts.push(`开启${opened.map(dc => dc.name).join('、')}`);
        if (closed.length > 0) descriptionParts.push(`关闭${closed.map(dc => dc.name).join('、')}`);
        if (kept.length > 0) descriptionParts.push(`保留${kept.map(dc => dc.name).join('、')}`);
        
        let currentDescription = `${solutionName}：`;
        if (descriptionParts.length > 0) {
            currentDescription += descriptionParts.join('；') + '。';
        } else {
            // Check if any original DCs were kept, even if none were opened or closed explicitly by logic
            // This case implies "maintain current" only if keptDCs equals initial existingDCs and no potentialDCs were involved.
            // For simplicity, this mock will assume 'maintain current' if no specific open/close actions.
            currentDescription += '维持当前配置。';
        }


        solutions.push({
          id: `MIP_SOL_${Date.now()}_${i}`,
          name: solutionName,
          description: currentDescription,
          openedDCs: opened,
          closedDCs: closed,
          keptDCs: kept,
          totalCapex: totalCapex,
          annualOpexChange: annualOpexChange,
        });
      }
      resolve(solutions.filter(s => s.openedDCs.length > 0 || s.closedDCs.length > 0 || solutions.length === numSolutionsToGenerate));
    }, 1500);
  });
};