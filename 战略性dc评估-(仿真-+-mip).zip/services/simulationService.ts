
import { MIPSolution, SimulationScenario, SimulationResultMetrics, SimulatedSolutionPerformance } from '../types';

// Mock function to simulate performance of an MIP solution under a given scenario
export const runSimulation = async (
  mipSolution: MIPSolution,
  scenario: SimulationScenario
): Promise<SimulationResultMetrics> => {
  return new Promise(resolve => {
    setTimeout(() => {
      // Base cost influenced by number of DCs and their opex/capex
      let baseCost = mipSolution.totalCapex / scenario.durationYears; // Spread capex
      mipSolution.openedDCs.forEach(dc => baseCost += dc.operatingCost);
      mipSolution.keptDCs.forEach(dc => baseCost += dc.operatingCost);
      
      // Adjust cost by demand growth (higher growth might mean higher throughput cost or efficiency gains)
      const demandFactor = 1 + (scenario.demandGrowthRate * scenario.durationYears / 2); // Average growth impact
      let totalSimulatedCost = baseCost * scenario.durationYears * demandFactor;

      // Resilience: Base resilience + impact of disruptions
      // Higher capacity/more DCs might mean higher resilience initially
      const totalCapacity = [...mipSolution.openedDCs, ...mipSolution.keptDCs].reduce((sum, dc) => sum + dc.capacity, 0);
      let resilienceScore = Math.min(0.95, 0.6 + (totalCapacity / 500000)); // Arbitrary base resilience
      resilienceScore -= scenario.disruptionFrequency * scenario.disruptionImpact * 0.1; // Disruptions reduce resilience
      resilienceScore = Math.max(0.3, Math.min(1.0, resilienceScore)); // Clamp between 0.3 and 1.0

      // Service Level: Similar logic to resilience, impacted by demand and disruptions
      let serviceLevelScore = Math.min(0.98, 0.65 + (totalCapacity / 600000));
      serviceLevelScore -= (scenario.demandGrowthRate * 0.2); // Higher demand might strain service
      serviceLevelScore -= scenario.disruptionFrequency * scenario.disruptionImpact * 0.05; // Disruptions reduce service
      serviceLevelScore = Math.max(0.4, Math.min(1.0, serviceLevelScore)); // Clamp

      // Add some randomness
      totalSimulatedCost *= (1 + (Math.random() - 0.5) * 0.1); // +/- 5%
      resilienceScore *= (1 + (Math.random() - 0.5) * 0.05);
      serviceLevelScore *= (1 + (Math.random() - 0.5) * 0.05);
      
      resolve({
        totalSimulatedCost: Math.round(totalSimulatedCost),
        resilienceScore: parseFloat(resilienceScore.toFixed(2)),
        serviceLevelScore: parseFloat(serviceLevelScore.toFixed(2)),
      });
    }, 2000 + Math.random() * 1000); // Simulate network latency/computation time
  });
};


export const runSimulationsForSolution = async (
  mipSolution: MIPSolution,
  scenarios: SimulationScenario[]
): Promise<SimulatedSolutionPerformance[]> => {
    const results: SimulatedSolutionPerformance[] = [];
    for (const scenario of scenarios) {
        const metrics = await runSimulation(mipSolution, scenario);
        results.push({
            mipSolutionId: mipSolution.id,
            mipSolutionName: mipSolution.name,
            simulationScenarioId: scenario.id,
            simulationScenarioName: scenario.name,
            metrics: metrics,
        });
    }
    return results;
};
