
import { ExistingDC, PotentialDC, SimulationScenario } from './types';

export const INITIAL_EXISTING_DCS: ExistingDC[] = [
  { id: 'EDC001', name: '阿尔法中央DC', location: '美国中西部', capacity: 100000, operatingCost: 5000000 },
  { id: 'EDC002', name: '贝塔沿海枢纽', location: '美国西海岸', capacity: 75000, operatingCost: 4000000 },
  { id: 'EDC003', name: '伽马区域中心', location: '美国东南部', capacity: 50000, operatingCost: 3000000 },
];

export const INITIAL_POTENTIAL_DCS: PotentialDC[] = [
  { id: 'PDC001', name: '德尔塔北部扩展', location: '美国北部', capacity: 120000, operatingCost: 5500000, capex: 20000000 },
  { id: 'PDC002', name: '艾普西隆南部枢纽', location: '美国南部', capacity: 90000, operatingCost: 4500000, capex: 15000000 },
  { id: 'PDC003', name: '泽塔自动化中心', location: '美国中部', capacity: 200000, operatingCost: 7000000, capex: 35000000 },
];

export const DEFAULT_SIMULATION_SCENARIOS: SimulationScenario[] = [
  { id: 'SCN001', name: '基线增长', durationYears: 5, demandGrowthRate: 0.03, disruptionFrequency: 1, disruptionImpact: 0.1 },
  { id: 'SCN002', name: '高增长，中度中断', durationYears: 5, demandGrowthRate: 0.08, disruptionFrequency: 2, disruptionImpact: 0.15 },
  { id: 'SCN003', name: '市场停滞，高度中断', durationYears: 5, demandGrowthRate: 0.01, disruptionFrequency: 3, disruptionImpact: 0.25 },
];

export const APP_TITLE = "战略性DC网络评估";