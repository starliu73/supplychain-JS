
import React from 'react';
import { AppStep } from '../types';
import { ChevronRightIcon } from './icons/ChevronRightIcon';

interface StepperProps {
  currentStep: AppStep;
  setStep: (step: AppStep) => void;
}

const stepsConfig = [
  { id: AppStep.INITIAL_CONFIG, label: '1. MIP设置' },
  { id: AppStep.MIP_RESULTS, label: '2. MIP方案' },
  { id: AppStep.SIMULATION_SETUP, label: '3. 方案仿真' },
  { id: AppStep.DECISION_DASHBOARD, label: '4. 决策仪表盘' },
];

export const Stepper: React.FC<StepperProps> = ({ currentStep, setStep }) => {
  return (
    <nav className="flex items-center justify-center p-4" aria-label="进度">
      <ol role="list" className="flex items-center space-x-2 md:space-x-4">
        {stepsConfig.map((step, index) => (
          <li key={step.id}>
            <div className="flex items-center">
              <button
                onClick={() => {
                   if (step.id <= currentStep || stepsConfig.find(s => s.id === currentStep)?.id === AppStep.SIMULATION_RESULTS && step.id === AppStep.SIMULATION_SETUP) {
                     setStep(step.id);
                   }
                }}
                disabled={step.id > currentStep && !(stepsConfig.find(s => s.id === currentStep)?.id === AppStep.SIMULATION_RESULTS && step.id === AppStep.SIMULATION_SETUP)}
                className={`flex flex-col items-center px-2 py-1 md:px-3 md:py-1.5 rounded-md transition-colors ${
                  currentStep === step.id
                    ? 'bg-blue-600 text-white'
                    : step.id < currentStep || (stepsConfig.find(s => s.id === currentStep)?.id === AppStep.SIMULATION_RESULTS && step.id === AppStep.SIMULATION_SETUP)
                    ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                    : 'bg-slate-100 text-slate-500 cursor-not-allowed'
                }`}
              >
                <span className="text-xs md:text-sm font-medium">{step.label}</span>
              </button>
              {index !== stepsConfig.length - 1 && (
                <ChevronRightIcon className="h-5 w-5 text-slate-400 mx-1 md:mx-2" aria-hidden="true" />
              )}
            </div>
          </li>
        ))}
      </ol>
    </nav>
  );
};