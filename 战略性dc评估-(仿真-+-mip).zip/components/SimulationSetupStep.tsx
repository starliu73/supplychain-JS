
import React, { useState } from 'react';
import { MIPSolution, SimulationScenario, AppStep } from '../types';
import { DEFAULT_SIMULATION_SCENARIOS } from '../constants';
import { Button } from './common/Button';
import { Card } from './common/Card';

interface SimulationSetupStepProps {
  selectedMIPSolution: MIPSolution;
  onRunSimulations: (scenarios: SimulationScenario[]) => void;
  isLoading: boolean;
  setStep: (step: AppStep) => void;
}

export const SimulationSetupStep: React.FC<SimulationSetupStepProps> = ({
  selectedMIPSolution,
  onRunSimulations,
  isLoading,
  setStep
}) => {
  const [selectedScenarios, setSelectedScenarios] = useState<SimulationScenario[]>(DEFAULT_SIMULATION_SCENARIOS);

  const handleToggleScenario = (scenario: SimulationScenario) => {
    setSelectedScenarios(prev =>
      prev.find(s => s.id === scenario.id)
        ? prev.filter(s => s.id !== scenario.id)
        : [...prev, scenario]
    );
  };

  const handleRun = () => {
    if (selectedScenarios.length > 0) {
      onRunSimulations(selectedScenarios);
    } else {
      alert("请至少选择一个仿真场景。");
    }
  };

  return (
    <Card title={`步骤3：为 ${selectedMIPSolution.name} 配置仿真`}>
      <p className="mb-6 text-slate-600">
        定义或选择仿真场景以对选定的MIP方案 ({selectedMIPSolution.name}) 进行压力测试。
        这些场景将模拟未来的不确定性，如需求变化和中断。
      </p>

      <div className="mb-6">
        <h4 className="text-lg font-semibold text-slate-700 mb-3">可用仿真场景：</h4>
        <div className="space-y-3">
          {DEFAULT_SIMULATION_SCENARIOS.map(scenario => (
            <label key={scenario.id} className="flex items-center p-3 bg-slate-50 rounded-md border border-slate-200 hover:bg-slate-100 cursor-pointer">
              <input
                type="checkbox"
                className="h-5 w-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                checked={selectedScenarios.some(s => s.id === scenario.id)}
                onChange={() => handleToggleScenario(scenario)}
              />
              <div className="ml-3">
                <p className="font-medium text-slate-800">{scenario.name}</p>
                <p className="text-sm text-slate-600">
                  持续时间: {scenario.durationYears} 年, 需求增长: {(scenario.demandGrowthRate * 100).toFixed(0)}%/年,
                  中断: {scenario.disruptionFrequency}/年 (影响: {(scenario.disruptionImpact * 100).toFixed(0)}%)
                </p>
              </div>
            </label>
          ))}
        </div>
      </div>
      
      {isLoading && (
         <div className="flex justify-center items-center h-20 my-4">
          <svg className="animate-spin h-8 w-8 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="ml-3 text-slate-600 text-md">正在运行仿真，请稍候...</p>
        </div>
      )}

      <div className="mt-8 flex justify-between items-center border-t pt-6">
        <Button onClick={() => setStep(AppStep.MIP_RESULTS)} variant="secondary" disabled={isLoading}>
          返回MIP方案
        </Button>
        <Button onClick={handleRun} variant="primary" size="lg" isLoading={isLoading} disabled={selectedScenarios.length === 0}>
          运行选定仿真
        </Button>
      </div>
    </Card>
  );
};