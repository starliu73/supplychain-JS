
import React from 'react';
import { SimulatedSolutionPerformance, AppStep } from '../types';
import { Button } from './common/Button';
import { Card } from './common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface SimulationResultsDisplayProps {
  results: SimulatedSolutionPerformance[];
  mipSolutionName: string;
  onProceedToDashboard: () => void;
  onSimulateAnother: () => void;
}

const formatCurrency = (value: number) => `¥${(value / 1000000).toFixed(2)} 百万`;
const formatPercentage = (value: number) => `${(value * 100).toFixed(1)}%`;

export const SimulationResultsDisplay: React.FC<SimulationResultsDisplayProps> = ({
  results,
  mipSolutionName,
  onProceedToDashboard,
  onSimulateAnother,
}) => {
  if (results.length === 0) {
    return (
      <Card title={`“${mipSolutionName}”的仿真结果`}>
        <p className="text-slate-600">此方案尚无仿真结果可显示。</p>
        <div className="mt-6 flex justify-end space-x-3">
          <Button onClick={onSimulateAnother} variant="secondary">仿真其他MIP方案</Button>
          <Button onClick={onProceedToDashboard} variant="primary">转到决策仪表盘</Button>
        </div>
      </Card>
    );
  }

  const chartData = results.map(r => ({
    name: r.simulationScenarioName,
    Cost: r.metrics.totalSimulatedCost / 1000000, // in Millions for chart value
    Resilience: r.metrics.resilienceScore * 100,
    ServiceLevel: r.metrics.serviceLevelScore * 100,
  }));

  return (
    <Card title={`仿真结果：${mipSolutionName}`}>
      <p className="mb-6 text-slate-600">
        方案“{mipSolutionName}”在各种模拟未来场景下的性能表现。
      </p>

      <div className="overflow-x-auto mb-8">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">场景</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">总成本</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">弹性</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">服务水平</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {results.map(result => (
              <tr key={`${result.mipSolutionId}-${result.simulationScenarioId}`}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{result.simulationScenarioName}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{formatCurrency(result.metrics.totalSimulatedCost)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{formatPercentage(result.metrics.resilienceScore)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{formatPercentage(result.metrics.serviceLevelScore)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="mb-8 h-96">
        <h4 className="text-lg font-semibold text-slate-700 mb-4">性能比较图 (按场景)</h4>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" angle={-15} textAnchor="end" height={50} interval={0} 
                   tick={{fontSize: '0.75rem'}}/>
            <YAxis yAxisId="left" orientation="left" stroke="#8884d8" label={{ value: '成本 (百万¥)', angle: -90, position: 'insideLeft', fontSize: '0.8rem', dx:-10 }} tickFormatter={(value) => `${value}`}/>
            <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" label={{ value: '性能 (%)', angle: 90, position: 'insideRight', fontSize: '0.8rem', dx:10 }} domain={[0, 100]} tickFormatter={(value) => `${value}%`}/>
            <Tooltip 
              formatter={(value, name) => {
                if (name === '成本') return [`¥${Number(value).toFixed(2)} 百万`, name];
                return [`${Number(value).toFixed(1)}%`, name];
              }}
            />
            <Legend wrapperStyle={{fontSize: '0.8rem'}}/>
            <Bar yAxisId="left" dataKey="Cost" name="成本" fill="#8884d8" />
            <Bar yAxisId="right" dataKey="Resilience" name="弹性" fill="#82ca9d" />
            <Bar yAxisId="right" dataKey="ServiceLevel" name="服务水平" fill="#ffc658" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-10 flex flex-col sm:flex-row justify-between items-center border-t pt-6 space-y-4 sm:space-y-0">
        <p className="text-sm text-slate-500">
          已完成对“{mipSolutionName}”的分析。您可以仿真另一个MIP方案或继续查看总体决策仪表盘。
        </p>
        <div className="flex space-x-3">
          <Button onClick={onSimulateAnother} variant="secondary">仿真其他方案</Button>
          <Button onClick={onProceedToDashboard} variant="primary" size="lg">查看决策仪表盘</Button>
        </div>
      </div>
    </Card>
  );
};