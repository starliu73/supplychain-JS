
import React from 'react';
import { SimulatedSolutionPerformance, AppStep } from '../types';
import { Button } from './common/Button';
import { Card } from './common/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface DecisionDashboardStepProps {
  allSimulationResults: SimulatedSolutionPerformance[];
  setStep: (step: AppStep) => void;
}

const formatCurrency = (value: number) => `¥${(value / 1000000).toFixed(2)} 百万`;
const formatPercentage = (value: number) => `${(value * 100).toFixed(1)}%`;

export const DecisionDashboardStep: React.FC<DecisionDashboardStepProps> = ({ allSimulationResults, setStep }) => {
  if (allSimulationResults.length === 0) {
    return (
      <Card title="步骤4：决策仪表盘">
        <p className="text-slate-600 mb-4">尚无仿真结果。请先为MIP方案运行仿真。</p>
        <Button onClick={() => setStep(AppStep.MIP_RESULTS)} variant="primary">
          转到MIP方案
        </Button>
      </Card>
    );
  }

  const aggregatedResults = React.useMemo(() => {
    const solutionMap = new Map<string, { name: string; costs: number[]; resiliences: number[]; services: number[]; count: number }>();
    
    allSimulationResults.forEach(res => {
      if (!solutionMap.has(res.mipSolutionId)) {
        solutionMap.set(res.mipSolutionId, { name: res.mipSolutionName, costs: [], resiliences: [], services: [], count: 0 });
      }
      const entry = solutionMap.get(res.mipSolutionId)!;
      entry.costs.push(res.metrics.totalSimulatedCost);
      entry.resiliences.push(res.metrics.resilienceScore);
      entry.services.push(res.metrics.serviceLevelScore);
      entry.count++;
    });

    return Array.from(solutionMap.values()).map(entry => ({
      name: entry.name,
      avgCost: entry.costs.reduce((a, b) => a + b, 0) / entry.count,
      avgResilience: entry.resiliences.reduce((a, b) => a + b, 0) / entry.count,
      avgServiceLevel: entry.services.reduce((a, b) => a + b, 0) / entry.count,
    }));
  }, [allSimulationResults]);

  const chartData = aggregatedResults.map(r => ({
    name: r.name,
    AvgCost: r.avgCost / 1000000, // in Millions for chart value
    AvgResilience: r.avgResilience * 100,
    AvgServiceLevel: r.avgServiceLevel * 100,
  }));
  
  const recommendedSolution = React.useMemo(() => {
    if (aggregatedResults.length === 0) return null;
    return aggregatedResults.reduce((best, current) => {
        if (current.avgServiceLevel > best.avgServiceLevel) return current;
        if (current.avgServiceLevel === best.avgServiceLevel && current.avgResilience > best.avgResilience) return current;
        if (current.avgServiceLevel === best.avgServiceLevel && current.avgResilience === best.avgResilience && current.avgCost < best.avgCost) return current;
        return best;
    }, aggregatedResults[0]);
  }, [aggregatedResults]);


  return (
    <Card title="步骤4：决策仪表盘 - 对比分析">
      <p className="mb-6 text-slate-600">
        此仪表盘汇总了不同MIP方案的仿真性能。结果是针对每个方案运行的所有场景的平均值。
      </p>

      {recommendedSolution && (
        <div className="mb-8 p-4 bg-green-50 border border-green-200 rounded-lg">
            <h4 className="text-lg font-semibold text-green-700">初步建议</h4>
            <p className="text-green-600">根据仿真结果，<strong>{recommendedSolution.name}</strong> 在整体性能上表现出强大的平衡性 (平均成本：{formatCurrency(recommendedSolution.avgCost)}，平均弹性：{formatPercentage(recommendedSolution.avgResilience)}，平均服务水平：{formatPercentage(recommendedSolution.avgServiceLevel)})。</p>
            <p className="text-xs text-slate-500 mt-1">注意：这是一个简化建议。建议进行进一步的定性分析。</p>
        </div>
      )}

      <div className="overflow-x-auto mb-8">
        <table className="min-w-full divide-y divide-slate-200 shadow-sm rounded-lg">
          <thead className="bg-slate-100">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">MIP方案</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">平均总成本</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">平均弹性</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-600 uppercase tracking-wider">平均服务水平</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {aggregatedResults.map(result => (
              <tr key={result.name} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{result.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700">{formatCurrency(result.avgCost)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700">{formatPercentage(result.avgResilience)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700">{formatPercentage(result.avgServiceLevel)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mb-8 h-96">
        <h4 className="text-lg font-semibold text-slate-700 mb-4">汇总性能比较图</h4>
         <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 5, right: 30, left: 30, bottom: 50 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" angle={-30} textAnchor="end" interval={0} height={70} tick={{fontSize: '0.8rem'}}/>
            <YAxis yAxisId="left" orientation="left" stroke="#8884d8" label={{ value: '平均成本 (百万¥)', angle: -90, position: 'insideLeft', fontSize: '0.8rem', dx:-10 }} tickFormatter={(value) => `${value}`}/>
            <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" label={{ value: '平均性能 (%)', angle: 90, position: 'insideRight', fontSize: '0.8rem', dx:10 }} domain={[0, 100]} tickFormatter={(value) => `${value}%`}/>
            <Tooltip 
              formatter={(value, name) => {
                if (name === '平均成本') return [`¥${Number(value).toFixed(2)} 百万`, name];
                return [`${Number(value).toFixed(1)}%`, name];
              }}
            />
            <Legend wrapperStyle={{fontSize: '0.8rem'}} verticalAlign="top" height={36}/>
            <Bar yAxisId="left" dataKey="AvgCost" name="平均成本" fill="#8884d8" />
            <Bar yAxisId="right" dataKey="AvgResilience" name="平均弹性" fill="#82ca9d" />
            <Bar yAxisId="right" dataKey="AvgServiceLevel" name="平均服务水平" fill="#ffc658" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-10 border-t pt-6 flex justify-start">
        <Button onClick={() => setStep(AppStep.INITIAL_CONFIG)} variant="secondary" size="lg">
          开始新的评估
        </Button>
      </div>
    </Card>
  );
};