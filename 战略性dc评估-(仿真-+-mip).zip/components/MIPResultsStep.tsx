
import React from 'react';
import { MIPSolution, AppStep } from '../types';
import { Button } from './common/Button';
import { Card } from './common/Card';

interface MIPResultsStepProps {
  mipSolutions: MIPSolution[];
  onSelectSolution: (solution: MIPSolution) => void;
  isLoading: boolean;
  setStep: (step: AppStep) => void;
}

export const MIPResultsStep: React.FC<MIPResultsStepProps> = ({ mipSolutions, onSelectSolution, isLoading, setStep }) => {
  if (isLoading) {
    return (
      <Card title="步骤2：正在生成MIP方案...">
        <div className="flex justify-center items-center h-40">
          <svg className="animate-spin h-10 w-10 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="ml-4 text-slate-600 text-lg">正在分析网络配置...</p>
        </div>
      </Card>
    );
  }

  if (mipSolutions.length === 0 && !isLoading) {
    return (
       <Card title="步骤2：MIP方案">
         <p className="text-slate-600 mb-4">未能生成MIP方案。这可能是由于输入配置或MIP求解器出现问题所致。</p>
         <Button onClick={() => setStep(AppStep.INITIAL_CONFIG)} variant="secondary">
            返回配置
          </Button>
       </Card>
    );
  }

  return (
    <Card title="步骤2：查看混合整数规划 (MIP) 方案">
      <p className="mb-6 text-slate-600">
        MIP分析已提出以下战略性DC网络配置。选择一个方案以进行压力测试仿真。
      </p>
      <div className="space-y-6">
        {mipSolutions.map(solution => (
          <div key={solution.id} className="p-6 bg-slate-50 rounded-lg border border-slate-200 hover:shadow-md transition-shadow">
            <h4 className="text-xl font-semibold text-blue-700 mb-2">{solution.name}</h4>
            <p className="text-sm text-slate-600 mb-3">{solution.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3 text-sm">
              <div>
                <strong className="text-slate-700">新开DC：</strong>
                {solution.openedDCs.length > 0 ? (
                  <ul className="list-disc list-inside ml-4">
                    {solution.openedDCs.map(dc => <li key={dc.id}>{dc.name}</li>)}
                  </ul>
                ) : <span className="text-slate-500"> 无</span>}
              </div>
              <div>
                <strong className="text-slate-700">关闭DC：</strong>
                {solution.closedDCs.length > 0 ? (
                  <ul className="list-disc list-inside ml-4">
                    {solution.closedDCs.map(dc => <li key={dc.id}>{dc.name}</li>)}
                  </ul>
                ) : <span className="text-slate-500"> 无</span>}
              </div>
              <div>
                <strong className="text-slate-700">保留DC：</strong>
                 {solution.keptDCs.length > 0 ? (
                  <ul className="list-disc list-inside ml-4">
                    {solution.keptDCs.map(dc => <li key={dc.id}>{dc.name}</li>)}
                  </ul>
                ) : <span className="text-slate-500"> 无</span>}
              </div>
               <div>
                <strong className="text-slate-700">预计总资本支出：</strong>
                <span className="ml-2">¥{solution.totalCapex.toLocaleString()}</span>
              </div>
              <div>
                <strong className="text-slate-700">预计年度运营成本变化：</strong>
                <span className={`ml-2 ${solution.annualOpexChange >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {solution.annualOpexChange >= 0 ? '+' : ''}¥{solution.annualOpexChange.toLocaleString()}
                </span>
              </div>
            </div>

            <Button onClick={() => onSelectSolution(solution)} variant="primary" size="md">
              仿真此方案
            </Button>
          </div>
        ))}
      </div>
       <div className="mt-8 border-t pt-6">
          <Button onClick={() => setStep(AppStep.INITIAL_CONFIG)} variant="secondary">
            返回DC配置
          </Button>
        </div>
    </Card>
  );
};