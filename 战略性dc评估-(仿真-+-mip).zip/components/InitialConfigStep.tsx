
import React from 'react';
import { ExistingDC, PotentialDC, AppStep } from '../types';
import { INITIAL_EXISTING_DCS, INITIAL_POTENTIAL_DCS } from '../constants';
import { Button } from './common/Button';
import { Card } from './common/Card';
import { CubeIcon } from './icons/CubeIcon';

interface InitialConfigStepProps {
  onConfigComplete: (existing: ExistingDC[], potential: PotentialDC[]) => void;
  setStep: (step: AppStep) => void; 
}

export const InitialConfigStep: React.FC<InitialConfigStepProps> = ({ onConfigComplete }) => {
  const [existingDCs, setExistingDCs] = React.useState<ExistingDC[]>(INITIAL_EXISTING_DCS);
  const [potentialDCs, setPotentialDCs] = React.useState<PotentialDC[]>(INITIAL_POTENTIAL_DCS);

  const handleProceed = () => {
    onConfigComplete(existingDCs, potentialDCs);
  };

  const DCList: React.FC<{ dcs: (ExistingDC | PotentialDC)[]; title: string }> = ({ dcs, title }) => (
    <div className="mb-6">
      <h4 className="text-lg font-semibold text-slate-700 mb-2">{title}</h4>
      {dcs.length === 0 ? <p className="text-slate-500">未定义DC。</p> :
      <ul className="space-y-2">
        {dcs.map(dc => (
          <li key={dc.id} className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-center">
            <CubeIcon className="h-5 w-5 text-blue-500 mr-3" />
            <div>
              <p className="font-medium text-slate-800">{dc.name} <span className="text-xs text-slate-500">({dc.location})</span></p>
              <p className="text-sm text-slate-600">
                容量: {dc.capacity.toLocaleString()} 单位, 运营成本: ¥{dc.operatingCost.toLocaleString()}/年
                {'capex' in dc && `, 资本支出: ¥${(dc as PotentialDC).capex.toLocaleString()}`}
              </p>
            </div>
          </li>
        ))}
      </ul>}
    </div>
  );

  return (
    <Card title="步骤1：定义用于MIP分析的配送网络">
      <p className="mb-6 text-slate-600">
        回顾当前和潜在的配送中心。本演示程序预填了初始数据。
        在完整的应用程序中，您将能够添加、编辑或删除这些数据。
      </p>
      
      <DCList dcs={existingDCs} title="当前现有DC" />
      <DCList dcs={potentialDCs} title="潜在新DC" />

      <div className="mt-8 text-right">
        <Button onClick={handleProceed} variant="primary" size="lg">
          生成MIP方案
        </Button>
      </div>
    </Card>
  );
};