
export interface City {
  id: number;
  x: number;
  y: number;
}

export type Path = number[]; // Array of city IDs representing a path

export type DistanceMatrix = number[][]; // distanceMatrix[i][j] = distance between city i and city j

export type PheromoneMatrix = number[][]; // pheromoneMatrix[i][j] = pheromone level on edge (i,j)

export interface ACOParams {
  numCities: number;
  numAnts: number;
  numIterations: number;
  alpha: number; // Pheromone influence
  beta: number;  // Heuristic influence (inverse distance)
  evaporationRate: number; // rho
  Q: number;     // Pheromone deposit factor
  initialPheromone: number;
  minPheromone: number; // Minimum pheromone to avoid stagnation
}

export interface ACOIterationResult {
  allAntSolutions: { path: Path; distance: number }[];
  bestAntPathOfIteration: { path: Path; distance: number } | null;
  pheromones: PheromoneMatrix;
}
