
import React from 'react';
import { ACOParams } from '../types';

interface ControlsProps {
  params: ACOParams;
  onParamsChange: <K extends keyof ACOParams>(key: K, value: ACOParams[K]) => void;
  onStart: () => void;
  onReset: () => void;
  onGenerateCities: () => void;
  isOptimizing: boolean;
  showPheromones: boolean;
  onToggleShowPheromones: () => void;
}

const InputField: React.FC<{
  label: string;
  id: keyof ACOParams;
  value: number;
  type?: string;
  step?: string;
  min?: string;
  max?: string;
  onChange: (id: keyof ACOParams, value: number) => void;
  disabled?: boolean;
}> = ({ label, id, value, type = "number", step, min, max, onChange, disabled }) => (
  <div className="mb-3">
    <label htmlFor={id as string} className="block text-sm font-medium text-slate-300 mb-1">{label}</label>
    <input
      type={type}
      id={id as string}
      name={id as string}
      value={value}
      step={step}
      min={min}
      max={max}
      onChange={(e) => onChange(id, parseFloat(e.target.value))}
      disabled={disabled}
      className="mt-1 block w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 disabled:bg-slate-600 disabled:text-slate-400"
    />
  </div>
);


const Controls: React.FC<ControlsProps> = ({ 
    params, 
    onParamsChange, 
    onStart, 
    onReset, 
    onGenerateCities, 
    isOptimizing,
    showPheromones,
    onToggleShowPheromones
}) => {
  return (
    <div className="p-4 bg-slate-800 shadow-xl rounded-lg h-full overflow-y-auto no-scrollbar">
      <h2 className="text-xl font-semibold text-sky-400 mb-4">ACO Controls</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
        <InputField label="Number of Cities" id="numCities" value={params.numCities} min="3" max="100" step="1" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Number of Ants" id="numAnts" value={params.numAnts} min="1" max="200" step="1" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Number of Iterations" id="numIterations" value={params.numIterations} min="1" max="1000" step="1" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Alpha (Pheromone Influence)" id="alpha" value={params.alpha} type="number" step="0.1" min="0" max="10" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Beta (Heuristic Influence)" id="beta" value={params.beta} type="number" step="0.1" min="0" max="10" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Evaporation Rate (Rho)" id="evaporationRate" value={params.evaporationRate} type="number" step="0.01" min="0.01" max="1" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Q (Pheromone Deposit)" id="Q" value={params.Q} type="number" step="10" min="1" max="1000" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Initial Pheromone" id="initialPheromone" value={params.initialPheromone} type="number" step="0.01" min="0.01" max="10" onChange={onParamsChange} disabled={isOptimizing} />
        <InputField label="Min Pheromone" id="minPheromone" value={params.minPheromone} type="number" step="0.001" min="0.001" max="1" onChange={onParamsChange} disabled={isOptimizing} />
      </div>

      <div className="mt-4 mb-3 border-t border-slate-700 pt-3">
        <label htmlFor="showPheromonesToggle" className="flex items-center cursor-pointer">
          <div className="relative">
            <input 
              type="checkbox" 
              id="showPheromonesToggle" 
              className="sr-only" 
              checked={showPheromones} 
              onChange={onToggleShowPheromones}
              disabled={isOptimizing}
            />
            <div className={`block bg-slate-600 w-10 h-6 rounded-full transition-colors ${showPheromones ? 'bg-sky-500' : ''}`}></div>
            <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${showPheromones ? 'translate-x-4' : ''}`}></div>
          </div>
          <div className="ml-3 text-sm text-slate-300">Show Pheromone Trails</div>
        </label>
      </div>


      <div className="space-y-3">
        <button
          onClick={onStart}
          disabled={isOptimizing || params.numCities < 2}
          className="w-full bg-sky-600 hover:bg-sky-700 disabled:bg-sky-800 disabled:text-slate-400 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out"
        >
          {isOptimizing ? 'Optimizing...' : 'Start Optimization'}
        </button>
        <button
          onClick={onGenerateCities}
          disabled={isOptimizing}
          className="w-full bg-teal-500 hover:bg-teal-600 disabled:bg-teal-700 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out"
        >
          Generate New Cities
        </button>
        <button
          onClick={onReset}
          disabled={isOptimizing}
          className="w-full bg-slate-500 hover:bg-slate-600 disabled:bg-slate-700 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out"
        >
          Reset Simulation
        </button>
      </div>
    </div>
  );
};

export default Controls;
