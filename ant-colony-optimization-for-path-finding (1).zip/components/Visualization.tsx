
import React from 'react';
import { City, Path, PheromoneMatrix } from '../types';
import { VISUALIZATION_WIDTH, VISUALIZATION_HEIGHT } from '../services/acoService';

interface VisualizationProps {
  cities: City[];
  bestPath: Path | null;
  pheromones: PheromoneMatrix | null;
  showPheromones: boolean;
  minPheromoneValue: number; // To help with normalization floor
}

const Visualization: React.FC<VisualizationProps> = ({ cities, bestPath, pheromones, showPheromones, minPheromoneValue }) => {
  const pathCoordinates = React.useMemo(() => {
    if (!bestPath || bestPath.length === 0 || cities.length === 0) return [];
    return bestPath.map(cityId => {
      const city = cities.find(c => c.id === cityId);
      return city ? { x: city.x, y: city.y } : null;
    }).filter(c => c !== null) as { x: number, y: number }[];
  }, [bestPath, cities]);

  const pheromoneTrails = React.useMemo(() => {
    if (!showPheromones || !pheromones || cities.length < 2) return [];

    const trails: { x1: number, y1: number, x2: number, y2: number, opacity: number }[] = [];
    let maxPheromoneInMatrix = minPheromoneValue;
    if (pheromones.length > 0) {
        pheromones.forEach(row => row.forEach(val => {
            if (val > maxPheromoneInMatrix) maxPheromoneInMatrix = val;
        }));
    }
    // If maxPheromoneInMatrix is still minPheromoneValue (e.g., all pheromones are at min), 
    // or if max is not significantly larger, avoid division by zero or extreme opacities.
    const range = Math.max(0.001, maxPheromoneInMatrix - minPheromoneValue); 


    for (let i = 0; i < cities.length; i++) {
      for (let j = i + 1; j < cities.length; j++) { // Iterate unique pairs
        const city1 = cities[i];
        const city2 = cities[j];
        const pheromoneLevel = pheromones[city1.id]?.[city2.id] ?? minPheromoneValue;
        
        // Normalize pheromone to opacity (e.g., 0.05 to 0.7)
        const normalized = Math.max(0, (pheromoneLevel - minPheromoneValue) / range);
        const opacity = 0.05 + normalized * 0.65; // Cap opacity to make trails subtle

        trails.push({
          x1: city1.x,
          y1: city1.y,
          x2: city2.x,
          y2: city2.y,
          opacity: Math.min(Math.max(opacity, 0.05), 0.7) // Ensure opacity is within bounds
        });
      }
    }
    return trails;
  }, [showPheromones, pheromones, cities, minPheromoneValue]);

  return (
    <div className="p-4 bg-slate-800 shadow-xl rounded-lg flex justify-center items-center h-full">
      <svg 
        width={VISUALIZATION_WIDTH} 
        height={VISUALIZATION_HEIGHT} 
        viewBox={`0 0 ${VISUALIZATION_WIDTH} ${VISUALIZATION_HEIGHT}`}
        className="bg-slate-700 rounded shadow-inner"
        aria-label="Visualization of cities and ant paths"
        role="img"
      >
        <title>ACO Path Visualization</title>
        <desc>
          A map showing cities as circles. Blue lines represent pheromone trails between cities,
          with opacity indicating strength. The current best path found by ants is highlighted with a thicker, bright blue line.
        </desc>
        
        {/* Draw Pheromone Trails */}
        {showPheromones && pheromoneTrails.map((trail, index) => (
          <line
            key={`pheromone-${index}`}
            x1={trail.x1}
            y1={trail.y1}
            x2={trail.x2}
            y2={trail.y2}
            stroke="#475569" // slate-600, a bit darker for subtlety
            strokeWidth="1.5"
            strokeOpacity={trail.opacity}
            strokeLinecap="round"
          />
        ))}

        {/* Draw Best Path */}
        {pathCoordinates.length > 1 && (
          <polyline
            points={pathCoordinates.map(p => `${p.x},${p.y}`).join(' ')}
            fill="none"
            stroke="#38bdf8" // Brighter sky blue for best path (sky-500)
            strokeWidth="3"   // Thicker than pheromone trails
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-label={`Best path found connecting ${pathCoordinates.length} cities.`}
          />
        )}

        {/* Draw cities */}
        {cities.map((city) => (
          <g key={city.id} role="listitem" aria-label={`City ${city.id} at coordinates ${city.x.toFixed(0)}, ${city.y.toFixed(0)}`}>
            <circle
              cx={city.x}
              cy={city.y}
              r="6"
              fill="#0ea5e9" // Sky blue (sky-600)
              stroke="#f8fafc" // Whiteish border (slate-50)
              strokeWidth="1.5"
            />
            <text
              x={city.x + 8}
              y={city.y + 4}
              fontSize="10"
              fill="#e2e8f0" // Light slate (slate-200)
              aria-hidden="true" // City ID is part of the group's aria-label
            >
              {city.id}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
};

export default React.memo(Visualization);
