
import React from 'react';

interface ResultsProps {
  bestDistance: number | null;
  currentIteration: number;
  maxIterations: number;
  statusMessage: string;
  isOptimizing: boolean;
}

const Results: React.FC<ResultsProps> = ({ bestDistance, currentIteration, maxIterations, statusMessage, isOptimizing }) => {
  return (
    <div className="p-4 bg-slate-800 shadow-xl rounded-lg">
      <h2 className="text-xl font-semibold text-sky-400 mb-4">Results & Status</h2>
      <div className="space-y-2 text-slate-300">
        <p>
          Status: <span className={`font-semibold ${isOptimizing ? 'text-yellow-400' : 'text-green-400'}`}>{statusMessage}</span>
        </p>
        <p>
          Current Iteration: <span className="font-semibold text-slate-100">{currentIteration} / {maxIterations}</span>
        </p>
         {isOptimizing && maxIterations > 0 && (
          <div className="w-full bg-slate-700 rounded-full h-2.5">
            <div 
              className="bg-sky-500 h-2.5 rounded-full transition-all duration-150 ease-linear" 
              style={{ width: `${(currentIteration / maxIterations) * 100}%` }}
            ></div>
          </div>
        )}
        <p>
          Best Path Distance: <span className="font-semibold text-slate-100">{bestDistance !== null && Number.isFinite(bestDistance) ? bestDistance.toFixed(2) : 'N/A'}</span>
        </p>
      </div>
    </div>
  );
};

export default Results;
