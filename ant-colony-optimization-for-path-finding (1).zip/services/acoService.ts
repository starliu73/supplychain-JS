
import { City, Path, DistanceMatrix, PheromoneMatrix, ACOParams, ACOIterationResult } from '../types';

export const VISUALIZATION_WIDTH = 600;
export const VISUALIZATION_HEIGHT = 400;

export const calculateDistance = (city1: City, city2: City): number => {
  return Math.sqrt(Math.pow(city1.x - city2.x, 2) + Math.pow(city1.y - city2.y, 2));
};

export const generateRandomCities = (count: number): City[] => {
  const cities: City[] = [];
  const padding = 20; // Padding from edges of visualization area
  for (let i = 0; i < count; i++) {
    cities.push({
      id: i,
      x: padding + Math.random() * (VISUALIZATION_WIDTH - 2 * padding),
      y: padding + Math.random() * (VISUALIZATION_HEIGHT - 2 * padding),
    });
  }
  return cities;
};

export const calculateDistances = (cities: City[]): DistanceMatrix => {
  const numCities = cities.length;
  if (numCities === 0) return [];
  const distances: DistanceMatrix = Array(numCities)
    .fill(null)
    .map(() => Array(numCities).fill(0));

  for (let i = 0; i < numCities; i++) {
    for (let j = i; j < numCities; j++) {
      if (i === j) {
        distances[i][j] = Infinity; 
      } else {
        const dist = calculateDistance(cities[i], cities[j]);
        distances[i][j] = dist;
        distances[j][i] = dist;
      }
    }
  }
  return distances;
};

export const initializePheromones = (numCities: number, initialPheromoneValue: number): PheromoneMatrix => {
  if (numCities === 0) return [];
  return Array(numCities)
    .fill(null)
    .map(() => Array(numCities).fill(initialPheromoneValue));
};

const selectNextCity = (
  currentCityIndex: number,
  visited: boolean[],
  pheromones: PheromoneMatrix,
  distances: DistanceMatrix,
  alpha: number,
  beta: number,
  numCities: number
): number => {
  const probabilities: number[] = new Array(numCities).fill(0);
  let probabilitiesSum = 0;

  for (let i = 0; i < numCities; i++) {
    if (!visited[i]) {
      const pheromone = Math.pow(pheromones[currentCityIndex][i], alpha);
      const distance = distances[currentCityIndex][i];
      // Heuristic: 1/distance. Handle distance=0 or Infinity carefully.
      const heuristic = Math.pow(1.0 / (distance > 0 && Number.isFinite(distance) ? distance : 1e-10), beta);
      probabilities[i] = pheromone * heuristic;
      if (Number.isFinite(probabilities[i])) {
         probabilitiesSum += probabilities[i];
      } else {
        probabilities[i] = 0; // Avoid NaN/Infinity issues
      }
    }
  }

  if (probabilitiesSum === 0) {
    const unvisitedCities = visited.map((v, idx) => !v ? idx : -1).filter(idx => idx !== -1);
    if (unvisitedCities.length > 0) {
      return unvisitedCities[Math.floor(Math.random() * unvisitedCities.length)];
    }
    return -1; 
  }

  // Normalize probabilities
  for (let i = 0; i < numCities; i++) {
    if (!visited[i] && Number.isFinite(probabilities[i])) {
      probabilities[i] /= probabilitiesSum;
    } else {
       probabilities[i] = 0;
    }
  }

  let randomChoice = Math.random();
  let cumulativeProbability = 0;
  for (let i = 0; i < numCities; i++) {
    if (!visited[i]) {
      cumulativeProbability += probabilities[i];
      if (randomChoice <= cumulativeProbability) {
        return i;
      }
    }
  }
  
  const unvisitedCities = visited.map((v, idx) => !v ? idx : -1).filter(idx => idx !== -1);
  if (unvisitedCities.length > 0) {
      return unvisitedCities[Math.floor(Math.random() * unvisitedCities.length)];
  }
  return -1; 
};

export const constructAntSolution = (
  startCityIndex: number,
  numCities: number,
  pheromones: PheromoneMatrix,
  distances: DistanceMatrix,
  alpha: number,
  beta: number
): Path => {
  const path: Path = [startCityIndex];
  const visited: boolean[] = new Array(numCities).fill(false);
  visited[startCityIndex] = true;
  let currentCityIndex = startCityIndex;

  for (let i = 0; i < numCities - 1; i++) {
    const nextCityIndex = selectNextCity(currentCityIndex, visited, pheromones, distances, alpha, beta, numCities);
    if (nextCityIndex === -1) break; 
    path.push(nextCityIndex);
    visited[nextCityIndex] = true;
    currentCityIndex = nextCityIndex;
  }
  
  if (path.length === numCities) { // Ensure all cities visited before returning
    path.push(startCityIndex); // Complete the tour by returning to the start city
  } else {
    // Path construction failed to visit all cities, return an incomplete or invalid path marker
    // This can be an empty array or handle it based on how App.tsx expects invalid paths
    return []; 
  }
  return path;
};

export const calculatePathDistance = (path: Path, distances: DistanceMatrix): number => {
  if (path.length < 2) return Infinity; // Not a valid path
  let totalDistance = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const dist = distances[path[i]][path[i+1]];
    if (!Number.isFinite(dist)) return Infinity; // Invalid edge
    totalDistance += dist;
  }
  return totalDistance;
};

export const updatePheromones = (
  pheromones: PheromoneMatrix,
  antSolutions: { path: Path; distance: number }[],
  evaporationRate: number,
  Q: number,
  numCities: number,
  minPheromone: number
): PheromoneMatrix => {
  const newPheromones = pheromones.map(row => [...row]);

  for (let i = 0; i < numCities; i++) {
    for (let j = 0; j < numCities; j++) {
      newPheromones[i][j] *= (1 - evaporationRate);
      if (newPheromones[i][j] < minPheromone) {
        newPheromones[i][j] = minPheromone;
      }
    }
  }

  for (const ant of antSolutions) {
    if (ant.distance === 0 || !Number.isFinite(ant.distance) || ant.path.length < numCities +1) continue;
    const pheromoneDeposit = Q / ant.distance;
    for (let i = 0; i < ant.path.length - 1; i++) {
      const city1 = ant.path[i];
      const city2 = ant.path[i+1];
      newPheromones[city1][city2] += pheromoneDeposit;
      newPheromones[city2][city1] += pheromoneDeposit; 
    }
  }
  return newPheromones;
};

export const runACOIteration = (
    cities: City[],
    pheromones: PheromoneMatrix,
    distances: DistanceMatrix,
    params: ACOParams,
): ACOIterationResult => {
    const numCities = cities.length;
    if (numCities === 0) {
      return { allAntSolutions: [], bestAntPathOfIteration: null, pheromones: [] };
    }
    const antSolutions: { path: Path; distance: number }[] = [];
    let bestAntPathOfIteration: { path: Path; distance: number } | null = null;

    for (let k = 0; k < params.numAnts; k++) {
        const startCityIndex = Math.floor(Math.random() * numCities);
        const path = constructAntSolution(startCityIndex, numCities, pheromones, distances, params.alpha, params.beta);
        const distance = calculatePathDistance(path, distances);
        
        if (path.length === numCities + 1 && Number.isFinite(distance)) { // Valid complete tour
            antSolutions.push({ path, distance });
            if (bestAntPathOfIteration === null || distance < bestAntPathOfIteration.distance) {
                bestAntPathOfIteration = { path, distance };
            }
        }
    }

    const updatedPheromones = updatePheromones(
        pheromones,
        antSolutions,
        params.evaporationRate,
        params.Q,
        numCities,
        params.minPheromone
    );

    return {
        allAntSolutions: antSolutions,
        bestAntPathOfIteration,
        pheromones: updatedPheromones
    };
};
