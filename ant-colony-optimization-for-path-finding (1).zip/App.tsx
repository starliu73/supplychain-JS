
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { City, Path, ACOParams, DistanceMatrix, PheromoneMatrix } from './types';
import Controls from './components/Controls';
import Visualization from './components/Visualization';
import Results from './components/Results';
import {
  generateRandomCities,
  calculateDistances,
  initializePheromones,
  runACOIteration
} from './services/acoService';

const DEFAULT_ACO_PARAMS: ACOParams = {
  numCities: 15,
  numAnts: 20,
  numIterations: 100,
  alpha: 1.0,
  beta: 3.0,
  evaporationRate: 0.3,
  Q: 100,
  initialPheromone: 0.1,
  minPheromone: 0.01,
};

const App: React.FC = () => {
  const [acoParams, setAcoParams] = useState<ACOParams>(DEFAULT_ACO_PARAMS);
  const [cities, setCities] = useState<City[]>(() => generateRandomCities(DEFAULT_ACO_PARAMS.numCities));
  const [distances, setDistances] = useState<DistanceMatrix | null>(null);
  const [pheromones, setPheromones] = useState<PheromoneMatrix | null>(null);
  
  const [bestPathOverall, setBestPathOverall] = useState<Path | null>(null);
  const [bestDistanceOverall, setBestDistanceOverall] = useState<number>(Infinity);
  
  const [currentIteration, setCurrentIteration] = useState<number>(0);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('Ready. Configure parameters and start.');
  const [visualizationKey, setVisualizationKey] = useState<number>(0); 
  const [showPheromones, setShowPheromones] = useState<boolean>(true); // New state for pheromone visibility

  useEffect(() => {
    if (cities.length > 0) {
      setDistances(calculateDistances(cities));
      setPheromones(initializePheromones(cities.length, acoParams.initialPheromone));
      setBestPathOverall(null);
      setBestDistanceOverall(Infinity);
      setCurrentIteration(0);
      setVisualizationKey(prev => prev + 1); 
    } else {
      setDistances(null);
      setPheromones(null);
    }
  }, [cities, acoParams.initialPheromone]);

  const handleParamsChange = useCallback(<K extends keyof ACOParams>(key: K, value: ACOParams[K]) => {
    setAcoParams(prevParams => {
      const newParams = { ...prevParams, [key]: value };
      if (key === 'numCities' && typeof value === 'number' && !isOptimizing) {
        setCities(generateRandomCities(value)); 
        setStatusMessage('Cities regenerated. Ready.');
      }
      return newParams;
    });
  }, [isOptimizing]);

  const handleGenerateCities = useCallback(() => {
    if (!isOptimizing) {
      setCities(generateRandomCities(acoParams.numCities));
      setStatusMessage('New cities generated. Ready.');
    }
  }, [acoParams.numCities, isOptimizing]);

  const resetSimulationState = useCallback(() => {
    setIsOptimizing(false);
    setCurrentIteration(0);
    if (cities.length > 0) {
      setPheromones(initializePheromones(cities.length, acoParams.initialPheromone));
    }
    setBestPathOverall(null);
    setBestDistanceOverall(Infinity);
    setStatusMessage('Simulation reset. Ready.');
  }, [cities, acoParams.initialPheromone]);


  const handleStartOptimization = useCallback(() => {
    if (cities.length < 2 || !distances) {
      setStatusMessage('Please generate at least 2 cities.');
      return;
    }
    // Reset state but keep current cities and params
    setIsOptimizing(false); // Temporarily set to false to allow state updates
    setCurrentIteration(0);
    const initialPheromonesMatrix = initializePheromones(cities.length, acoParams.initialPheromone);
    setPheromones(initialPheromonesMatrix);
    setBestPathOverall(null);
    setBestDistanceOverall(Infinity);
    
    // Defer starting optimization to allow state to propagate
    requestAnimationFrame(() => {
        setIsOptimizing(true);
        setStatusMessage('Optimization started...');
    });

  }, [cities, distances, acoParams.initialPheromone]);


  useEffect(() => {
    let timerId: number | undefined;

    if (isOptimizing && currentIteration < acoParams.numIterations && cities.length > 0 && distances && pheromones) {
      timerId = window.setTimeout(() => {
        const result = runACOIteration(cities, pheromones, distances, acoParams);
        setPheromones(result.pheromones);

        let currentBestDistance = bestDistanceOverall;
        if (result.bestAntPathOfIteration && result.bestAntPathOfIteration.distance < currentBestDistance) {
          setBestDistanceOverall(result.bestAntPathOfIteration.distance);
          setBestPathOverall(result.bestAntPathOfIteration.path);
          currentBestDistance = result.bestAntPathOfIteration.distance;
        }
        
        setCurrentIteration(prev => prev + 1);
        if (currentIteration + 1 < acoParams.numIterations) {
            setStatusMessage(`Optimizing... Iteration ${currentIteration + 1}`);
        } else {
            setStatusMessage(`Optimization complete. Best distance: ${Number.isFinite(currentBestDistance) ? currentBestDistance.toFixed(2) : 'N/A'}`);
            setIsOptimizing(false);
        }

      }, 30); 
    } else if (isOptimizing && currentIteration >= acoParams.numIterations && cities.length > 0) {
      // This case handles when optimization finishes by reaching max iterations
      setIsOptimizing(false);
      setStatusMessage(`Optimization complete. Best distance: ${bestDistanceOverall.toFixed(2)}`);
    }


    return () => clearTimeout(timerId);
  }, [isOptimizing, currentIteration, acoParams, cities, distances, pheromones, bestDistanceOverall, bestPathOverall]);
  
  const memoizedVisualization = useMemo(() => (
    <Visualization 
      key={visualizationKey} 
      cities={cities} 
      bestPath={bestPathOverall} 
      pheromones={pheromones}
      showPheromones={showPheromones}
      minPheromoneValue={acoParams.minPheromone}
    />
  ), [visualizationKey, cities, bestPathOverall, pheromones, showPheromones, acoParams.minPheromone]);

  const handleToggleShowPheromones = useCallback(() => {
    setShowPheromones(prev => !prev);
  }, []);

  return (
    <div className="min-h-screen flex flex-col p-4 bg-slate-900 text-slate-100">
      <header className="mb-6 text-center">
        <h1 className="text-4xl font-bold text-sky-400">Ant Colony Optimization</h1>
        <p className="text-slate-400">Visualizing Path Finding for Logistics</p>
      </header>

      <main className="flex-grow grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-7xl w-full mx-auto">
        <div className="lg:col-span-1 h-[calc(100vh-150px)] lg:h-auto lg:max-h-[calc(100vh-120px)] overflow-hidden">
          <Controls
            params={acoParams}
            onParamsChange={handleParamsChange}
            onStart={handleStartOptimization}
            onReset={resetSimulationState}
            onGenerateCities={handleGenerateCities}
            isOptimizing={isOptimizing}
            showPheromones={showPheromones}
            onToggleShowPheromones={handleToggleShowPheromones}
          />
        </div>
        <div className="lg:col-span-2 space-y-6 h-full flex flex-col">
          <div className="flex-grow min-h-[420px]">
             {memoizedVisualization}
          </div>
          <Results
            bestDistance={bestDistanceOverall}
            currentIteration={currentIteration}
            maxIterations={acoParams.numIterations}
            statusMessage={statusMessage}
            isOptimizing={isOptimizing}
          />
        </div>
      </main>
    </div>
  );
};

export default App;
