
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL_NAME } from '../constants';
import { zh } from '../locales/zh';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  try {
    ai = new GoogleGenAI({ apiKey: API_KEY });
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
    // ai remains null, and the functions below will handle this
  }
} else {
  console.warn("API_KEY environment variable not set. Gemini API functionality will be disabled.");
}

export interface ExplanationResult {
  text: string;
  error?: string;
}

export const fetchExplanation = async (promptDetail: string): Promise<ExplanationResult> => {
  if (!ai) {
    return { text: "", error: zh.gemini_apiClientNotInitialized };
  }
  try {
    // The prompt structure is slightly adjusted to be more direct.
    // The prompt to Gemini remains in English.
    const fullPrompt = `You are an expert in supply chain management. Provide a concise and informative explanation for the following topic in the context of Smart Supply Chain Architecture. Aim for about 100-150 words, focusing on core concepts, roles, and benefits. The explanation should be suitable for a general audience interested in technology and business. Topic: "${promptDetail}"`;
    
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: fullPrompt,
      config: {
        temperature: 0.6, 
        topP: 0.9,
      }
    });

    const generatedText = response.text;
    if (!generatedText || generatedText.trim() === "") {
        return { text: "", error: zh.gemini_emptyResponse};
    }

    return { text: generatedText };
  } catch (error) {
    console.error("Error fetching explanation from Gemini:", error);
    let errorMessage = zh.gemini_unknownFetchError;
    if (error instanceof Error) {
        errorMessage = `${zh.gemini_fetchErrorPrefix}${error.message}`;
    }
    return { text: "", error: errorMessage };
  }
};
