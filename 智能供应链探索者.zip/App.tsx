
import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import TopicCard from './components/TopicCard';
import ExplanationArea from './components/ExplanationArea';
import { TOPICS_DATA, BENEFITS_TOPIC_DATA, CHALLENGES_TOPIC_DATA } from './constants';
import { fetchExplanation, ExplanationResult } from './services/geminiService';
import { Topic } from './types';
import { zh } from './locales/zh';


const App: React.FC = () => {
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<string | null>(null); // English explanation
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // allTopics will have Chinese titles and descriptions due to constants.tsx update
  const allTopics: Topic[] = [...TOPICS_DATA, BENEFITS_TOPIC_DATA, CHALLENGES_TOPIC_DATA];

  const handleTopicSelect = useCallback(async (topicId: string) => {
    setSelectedTopicId(topicId);
    setIsLoading(true);
    setExplanation(null);
    setError(null);

    const selected = allTopics.find(t => t.id === topicId);
    if (selected) {
      // selected.promptDetail is still in English
      const result: ExplanationResult = await fetchExplanation(selected.promptDetail);
      if (result.error) {
        setError(result.error); // Error message is already in Chinese from geminiService
      } else {
        setExplanation(result.text); // result.text is English explanation
      }
    } else {
      setError(zh.selectedTopicNotFound);
    }
    setIsLoading(false);
  }, [allTopics]); // allTopics is stable as it's derived from constants

  useEffect(() => {
    if (selectedTopicId && !isLoading) {
      const explanationElement = document.getElementById('explanation-area');
      if (explanationElement) {
        explanationElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [selectedTopicId, isLoading, explanation, error]);


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 md:p-8 selection:bg-sky-500 selection:text-white">
      <Header />
      <main className="w-full max-w-6xl mx-auto space-y-8 sm:space-y-12 flex-grow">
        <section id="intro-text" className="text-center bg-slate-800/60 p-6 rounded-xl shadow-xl backdrop-blur-sm border border-slate-700/50">
          <h2 className="text-2xl sm:text-3xl font-semibold text-sky-400 mb-3">{zh.app_discoverTitle}</h2>
          <p className="text-gray-300 text-sm sm:text-base max-w-3xl mx-auto">
            {zh.app_discoverSubtitle}
          </p>
        </section>

        <section id="topics-grid" aria-labelledby="topics-heading">
          <h2 id="topics-heading" className="sr-only">{zh.app_sr_topicsHeading}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {TOPICS_DATA.map((topic) => ( // topic.title and topic.description are now Chinese
              <TopicCard key={topic.id} topic={topic} onSelect={handleTopicSelect} isSelected={selectedTopicId === topic.id} />
            ))}
            <TopicCard topic={BENEFITS_TOPIC_DATA} onSelect={handleTopicSelect} isSelected={selectedTopicId === BENEFITS_TOPIC_DATA.id} />
            <TopicCard topic={CHALLENGES_TOPIC_DATA} onSelect={handleTopicSelect} isSelected={selectedTopicId === CHALLENGES_TOPIC_DATA.id} />
          </div>
        </section>

        <ExplanationArea
          topicTitle={selectedTopicId ? allTopics.find(t => t.id === selectedTopicId)?.title || null : null} // Chinese title
          explanation={explanation} // English explanation
          isLoading={isLoading}
          error={error} // Chinese error message
        />
      </main>
      <Footer />
    </div>
  );
};

export default App;
