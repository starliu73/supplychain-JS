
import React from 'react';
import { zh } from '../locales/zh';

const Header: React.FC = () => {
  return (
    <header className="w-full max-w-5xl mx-auto py-6 sm:py-8 text-center">
      <h1 className="text-4xl sm:text-5xl font-extrabold">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500">
          {zh.header_title1}
        </span>
        <span className="block text-3xl sm:text-4xl text-slate-300 mt-1">{zh.header_title2}</span>
      </h1>
    </header>
  );
};

export default Header;
