
import React from 'react';
import { Topic } from '../types';

interface TopicCardProps {
  topic: Topic;
  onSelect: (topicId: string) => void;
  isSelected: boolean;
}

const TopicCard: React.FC<TopicCardProps> = ({ topic, onSelect, isSelected }) => {
  const IconComponent = topic.icon;

  const baseClasses = "relative flex flex-col items-center p-6 rounded-xl shadow-lg transition-all duration-300 ease-in-out cursor-pointer group hover:shadow-sky-500/30 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900";
  const selectedClasses = isSelected ? "bg-sky-700/50 ring-2 ring-sky-500 scale-105 shadow-sky-500/40" : "bg-slate-800 hover:bg-slate-700/80";
  
  return (
    <div
      role="button"
      tabIndex={0}
      className={`${baseClasses} ${selectedClasses}`}
      onClick={() => onSelect(topic.id)}
      onKeyPress={(e) => e.key === 'Enter' && onSelect(topic.id)}
    >
      <div className={`p-3 rounded-full mb-4 transition-colors duration-300 ${isSelected ? 'bg-sky-500 text-white' : 'bg-slate-700 group-hover:bg-sky-600 text-sky-400 group-hover:text-white'}`}>
        <IconComponent className="w-8 h-8 sm:w-10 sm:h-10" />
      </div>
      <h3 className={`text-lg sm:text-xl font-semibold mb-2 text-center ${isSelected ? 'text-white' : 'text-sky-300 group-hover:text-sky-200'}`}>{topic.title}</h3>
      <p className={`text-xs sm:text-sm text-center ${isSelected ? 'text-slate-200' : 'text-slate-400 group-hover:text-slate-300'}`}>{topic.description}</p>
      {isSelected && (
        <div className="absolute -top-2 -right-2 w-5 h-5 bg-sky-400 rounded-full flex items-center justify-center shadow-md">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>
      )}
    </div>
  );
};

export default TopicCard;
