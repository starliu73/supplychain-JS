
import React from 'react';
import { zh } from '../locales/zh';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="w-full max-w-5xl mx-auto py-6 mt-12 text-center text-sm text-slate-400 border-t border-slate-700">
      <p>{zh.footer_copyright.replace('{year}', currentYear.toString())}</p>
      <p className="mt-1">{zh.footer_disclaimer}</p>
    </footer>
  );
};

export default Footer;
