
import React from 'react';
import LoadingSpinner from './LoadingSpinner';
import { zh } from '../locales/zh';

interface ExplanationAreaProps {
  topicTitle: string | null; // This will be the Chinese title
  explanation: string | null; // This will be the English explanation from Gemini
  isLoading: boolean;
  error: string | null;
}

const ExplanationArea: React.FC<ExplanationAreaProps> = ({ topicTitle, explanation, isLoading, error }) => {
  return (
    <section id="explanation-area" className="w-full mt-8 sm:mt-12 p-6 sm:p-8 bg-slate-800/70 rounded-xl shadow-2xl min-h-[200px] flex flex-col justify-center items-center relative overflow-hidden backdrop-blur-sm border border-slate-700">
      {isLoading && <LoadingSpinner />}
      {!isLoading && error && (
        <div className="text-center">
          <h3 className="text-2xl font-semibold text-red-400 mb-3">{zh.errorTitle}</h3>
          <p className="text-red-300 bg-red-900/50 p-4 rounded-md whitespace-pre-wrap">{error}</p>
        </div>
      )}
      {!isLoading && !error && explanation && topicTitle && (
        <div className="w-full">
          <h3 className="text-2xl sm:text-3xl font-bold text-sky-400 mb-4 text-center sm:text-left">
            {topicTitle} {zh.explanationArea_topicExplainedSuffix}
          </h3>
          {/* The explanation itself is in English, as received from Gemini */}
          <div className="prose prose-sm sm:prose-base prose-invert max-w-none text-slate-300 whitespace-pre-wrap leading-relaxed">
            {explanation.split('\\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>
      )}
      {!isLoading && !error && !explanation && !topicTitle && (
        <div className="text-center">
          <h3 className="text-xl sm:text-2xl font-semibold text-slate-400">{zh.explanationArea_selectTopic}</h3>
          <p className="text-slate-500 mt-2">{zh.explanationArea_selectTopicHint}</p>
        </div>
      )}
    </section>
  );
};

export default ExplanationArea;
