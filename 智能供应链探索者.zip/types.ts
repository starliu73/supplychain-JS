
import React from 'react';

export interface Topic {
  id: string;
  title: string;
  description: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  promptDetail: string;
}
