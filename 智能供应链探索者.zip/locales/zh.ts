
export const zh = {
  // Global
  appName: "智能供应链探索者",
  appDescriptionMeta: "一个交互式Web应用程序，用于探索智能供应链架构的概念、组件、优势和挑战，其解释由Gemini API提供支持。",
  noscript: "您需要启用 JavaScript 才能运行此应用。",
  errorTitle: "错误",
  selectedTopicNotFound: "未找到选定的主题。",

  // Header
  header_title1: "智能供应链",
  header_title2: "架构浏览器",

  // Footer
  footer_copyright: "© {year} 智能供应链探索者。由 React、Tailwind CSS 和 Gemini API 驱动。",
  footer_disclaimer: "仅供说明之用。API 密钥必须在环境中配置。",

  // App component specific
  app_discoverTitle: "发现供应链的未来",
  app_discoverSubtitle: "探索智能供应链架构的核心技术、变革性优势和潜在挑战。点击下面的主题以查看由 Google Gemini API 生成的解释。",
  app_sr_topicsHeading: "智能供应链架构中的关键主题",

  // Topic Cards (Data in constants.tsx will refer to these)
  topics: {
    intro: { title: "简介：智能供应链", description: "智能互联供应链系统的基础。" },
    iot: { title: "物联网 (IoT)", description: "通过传感器和连接设备实现实时数据可见性。" },
    ai_ml: { title: "人工智能与机器学习", description: "用于预测、优化和自动化的算法。" },
    blockchain: { title: "区块链技术", description: "确保货物和交易的透明度、安全性和可追溯性。" },
    big_data: { title: "大数据与分析", description: "利用海量数据获取洞察并改进决策。" },
    cloud_computing: { title: "云计算", description: "为数据、处理和应用程序提供可扩展平台。" },
  },
  benefits: { 
    title: "总体优势", 
    description: "实施智能供应链架构的主要好处。" 
  },
  challenges: { 
    title: "实施挑战", 
    description: "采用智能供应链解决方案的潜在障碍。" 
  },

  // Explanation Area
  explanationArea_topicExplainedSuffix: "解析", // e.g. "物联网 (IoT) 解析" - will be {topicTitle} + suffix
  explanationArea_selectTopic: "选择一个主题",
  explanationArea_selectTopicHint: "点击上方任何主题卡片以查看 AI 生成的解释。",

  // Loading Spinner
  loadingSpinner_text: "解释加载中...",

  // Gemini Service
  gemini_apiClientNotInitialized: "Gemini API 客户端未初始化。请确保 API_KEY 已在您的环境中正确配置。",
  gemini_emptyResponse: "从 API 收到了空或无效的解释。",
  gemini_fetchErrorPrefix: "获取解释失败：",
  gemini_unknownFetchError: "获取解释时发生未知错误。",
};
