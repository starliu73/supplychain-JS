
import React from 'react';
import { Topic } from './types';
import { zh } from './locales/zh';

// --- Icon Components (Heroicons style) ---

export const CubeTransparentIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
  </svg>
);

export const WifiIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.75 20.25h.008v.008h-.008v-.008z" />
  </svg>
);

export const CpuChipIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
     <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h12A2.25 2.25 0 0020.25 14.25V3M3.75 3H1.5m2.25 0H6M20.25 3h2.25m-2.25 0h-2.25m0 0V1.5m0 1.5V6M6 3v3m0 0V1.5m0 1.5H3.75m0 0H1.5m2.25 0h2.25M3.75 6H6m0 0h12M6 6H3.75m16.5 0H18m0 0h2.25m0 0V1.5m0 1.5V6m0 0h-2.25m2.25 0h-2.25M3.75 16.5v2.25M6 16.5v2.25m12-2.25v2.25m-2.25-2.25v2.25M18 16.5v2.25M20.25 16.5v2.25M6 12h12v2.25H6V12zm0 0H3.75M6 12H1.5m16.5 0H18m0 0h2.25m0 0h2.25M12 6.75A.75.75 0 0112.75 6h.5a.75.75 0 01.75.75v3.75a.75.75 0 01-.75.75h-.5a.75.75 0 01-.75-.75V6.75z" />
  </svg>
);

export const LinkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" />
  </svg>
);

export const CircleStackIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25 16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75M9 12.75h6" />
  </svg>
);

export const CloudIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15a4.5 4.5 0 004.5 4.5H18a3.75 3.75 0 001.332-7.257 3 3 0 00-2.43-2.43A3.75 3.75 0 0013.5 4.5c-1.356 0-2.583.56-3.443 1.458A4.502 4.502 0 006.75 4.5c-2.485 0-4.5 2.015-4.5 4.5v6z" />
  </svg>
);

export const CheckBadgeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const ExclamationTriangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
  </svg>
);

export const TOPICS_DATA: Topic[] = [
  {
    id: "intro",
    title: zh.topics.intro.title,
    description: zh.topics.intro.description,
    promptDetail: "What is a Smart Supply Chain Architecture? Explain its core concepts, goals, and key differentiators from traditional supply chains. Keep it concise, around 100-150 words.",
    icon: CubeTransparentIcon,
  },
  {
    id: "iot",
    title: zh.topics.iot.title,
    description: zh.topics.iot.description,
    promptDetail: "Explain the role of IoT in Smart Supply Chain Architecture, including examples like RFID, smart sensors, and GPS tracking, and their impact on visibility and automation. Keep it concise, around 100-150 words.",
    icon: WifiIcon,
  },
  {
    id: "ai_ml",
    title: zh.topics.ai_ml.title,
    description: zh.topics.ai_ml.description,
    promptDetail: "Describe how AI and Machine Learning are used in Smart Supply Chains for tasks like demand forecasting, predictive maintenance, route optimization, and automated decision-making. Keep it concise, around 100-150 words.",
    icon: CpuChipIcon,
  },
  {
    id: "blockchain",
    title: zh.topics.blockchain.title,
    description: zh.topics.blockchain.description,
    promptDetail: "Explain the benefits and applications of Blockchain technology in enhancing transparency, security, and traceability within a Smart Supply Chain. Provide examples. Keep it concise, around 100-150 words.",
    icon: LinkIcon,
  },
  {
    id: "big_data",
    title: zh.topics.big_data.title,
    description: zh.topics.big_data.description,
    promptDetail: "How do Big Data and Analytics contribute to a Smart Supply Chain? Discuss their impact on operational efficiency, risk management, and strategic planning. Keep it concise, around 100-150 words.",
    icon: CircleStackIcon,
  },
  {
    id: "cloud_computing",
    title: zh.topics.cloud_computing.title,
    description: zh.topics.cloud_computing.description,
    promptDetail: "What is the role of Cloud Computing in enabling Smart Supply Chain solutions? Focus on scalability, accessibility, collaboration, and cost-effectiveness. Keep it concise, around 100-150 words.",
    icon: CloudIcon,
  },
];

export const BENEFITS_TOPIC_DATA: Topic = {
  id: "benefits",
  title: zh.benefits.title,
  description: zh.benefits.description,
  promptDetail: "Summarize the key benefits of adopting a Smart Supply Chain Architecture for businesses. Include aspects like efficiency, cost reduction, resilience, customer satisfaction, and sustainability. Keep it concise, around 100-150 words.",
  icon: CheckBadgeIcon,
};

export const CHALLENGES_TOPIC_DATA: Topic = {
  id: "challenges",
  title: zh.challenges.title,
  description: zh.challenges.description,
  promptDetail: "What are common challenges faced when implementing Smart Supply Chain technologies? Consider aspects like data integration, security concerns, initial investment costs, skill gaps, and change management. Keep it concise, around 100-150 words.",
  icon: ExclamationTriangleIcon,
};

export const GEMINI_MODEL_NAME = "gemini-2.5-flash-preview-04-17";
