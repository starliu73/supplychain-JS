
export interface Supplier {
  id: string;
  name: string;
  cost: number;
  quality: number; // e.g., 1-10 scale
  capacity: number;
}

export type Chromosome = number[]; // Binary array, 1 if supplier selected, 0 otherwise

export interface GAParameters {
  populationSize: number;
  generations: number;
  crossoverRate: number;
  mutationRate: number;
  elitismCount: number;
}

export interface DemandConstraints {
  requiredDemand: number;
  minQualityAverage: number; // Minimum average quality of selected suppliers
}

export interface FitnessDataPoint {
  generation: number;
  bestFitness: number; // Lower is better
  avgFitness: number;
}

export interface SolutionMetrics {
  selectedSuppliers: Supplier[];
  totalCost: number;
  averageQuality: number;
  totalCapacity: number;
  fitness: number;
}

export interface GARunResult {
  bestSolutionMetrics: SolutionMetrics | null;
  fitnessHistory: FitnessDataPoint[];
}

export interface LogEntry {
  id: number;
  message: string;
  type: 'info' | 'success' | 'error';
}
