
import React, { useState, useCallback, useEffect } from 'react';
import { Supplier, GAParameters, DemandConstraints, GARunResult, FitnessDataPoint, LogEntry, SolutionMetrics } from './types';
import { DEFAULT_SUPPLIERS, DEFAULT_GA_PARAMETERS, DEFAULT_DEMAND_CONSTRAINTS } from './constants';
import SupplierConfigPanel from './components/SupplierConfigPanel';
import GAParametersPanel from './components/GAParametersPanel';
import RunControls from './components/RunControls';
import ResultsDisplay from './components/ResultsDisplay';
import EvolutionChart from './components/EvolutionChart';
import LogView from './components/LogView';
import { runGeneticAlgorithm } from './services/geneticAlgorithm';

const App: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>(DEFAULT_SUPPLIERS);
  const [gaParams, setGaParams] = useState<GAParameters>(DEFAULT_GA_PARAMETERS);
  const [demandConstraints, setDemandConstraints] = useState<DemandConstraints>(DEFAULT_DEMAND_CONSTRAINTS);
  
  const [gaResult, setGaResult] = useState<GARunResult | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [currentGeneration, setCurrentGeneration] = useState<number>(0);

  const addLog = useCallback((message: string, type: LogEntry['type'] = 'info') => {
    setLogs(prevLogs => [{ id: Date.now(), message, type }, ...prevLogs.slice(0, 99)]);
  }, []);

  const handleRunGA = useCallback(async () => {
    if (suppliers.length === 0) {
      addLog("Cannot run GA: No suppliers defined.", 'error');
      return;
    }
    setIsRunning(true);
    setGaResult(null);
    setCurrentGeneration(0);
    setLogs([]);
    addLog("Genetic Algorithm started...", 'info');

    try {
      // Simulate progress for UI updates during long computations
      const updateProgress = (generation: number, bestFitnessThisGen: number, avgFitnessThisGen: number) => {
        setCurrentGeneration(generation);
         // Update fitness history incrementally for live chart updates
        setGaResult(prev => ({
            bestSolutionMetrics: prev?.bestSolutionMetrics || null,
            fitnessHistory: [...(prev?.fitnessHistory || []), { generation, bestFitness: bestFitnessThisGen, avgFitness: avgFitnessThisGen }]
        }));
      };
      
      const result = await runGeneticAlgorithm(
        suppliers,
        gaParams,
        demandConstraints,
        addLog,
        updateProgress
      );
      setGaResult(result);
      if (result.bestSolutionMetrics) {
        addLog(`GA finished. Best solution cost: ${result.bestSolutionMetrics.totalCost.toFixed(2)}`, 'success');
      } else {
        addLog("GA finished. No feasible solution found.", 'error');
      }
    } catch (error) {
      console.error("Error running GA:", error);
      addLog(`Error running GA: ${error instanceof Error ? error.message : String(error)}`, 'error');
    } finally {
      setIsRunning(false);
      setCurrentGeneration(gaParams.generations); // Ensure generation count is final
    }
  }, [suppliers, gaParams, demandConstraints, addLog]);

  const handleReset = useCallback(() => {
    setSuppliers(DEFAULT_SUPPLIERS);
    setGaParams(DEFAULT_GA_PARAMETERS);
    setDemandConstraints(DEFAULT_DEMAND_CONSTRAINTS);
    setGaResult(null);
    setIsRunning(false);
    setLogs([]);
    setCurrentGeneration(0);
    addLog("Settings and results reset to default.", 'info');
  }, [addLog]);

  useEffect(() => {
    addLog("Application initialized. Configure suppliers and parameters, then run the GA.", "info")
  }, [addLog]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-gray-100 p-4 sm:p-6 lg:p-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-pink-500">
          遗传算法：供应商选择优化器
        </h1>
        <p className="text-slate-400 mt-2 text-sm sm:text-base">
          通过模拟生物进化过程（选择、交叉、变异）来优化供应链中的供应商选择方案。
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Configuration */}
        <div className="lg:col-span-1 space-y-6">
          <SupplierConfigPanel 
            suppliers={suppliers} 
            setSuppliers={setSuppliers} 
            disabled={isRunning} 
          />
          <GAParametersPanel
            gaParams={gaParams}
            setGaParams={setGaParams}
            demandConstraints={demandConstraints}
            setDemandConstraints={setDemandConstraints}
            disabled={isRunning}
          />
          <RunControls 
            onRun={handleRunGA} 
            onReset={handleReset} 
            isRunning={isRunning} 
            currentGeneration={currentGeneration}
            totalGenerations={gaParams.generations}
          />
        </div>

        {/* Right Column: Results & Visualization */}
        <div className="lg:col-span-2 space-y-6">
          <ResultsDisplay 
            bestSolutionMetrics={gaResult?.bestSolutionMetrics || null} 
            isLoading={isRunning && !gaResult?.bestSolutionMetrics} 
          />
          <EvolutionChart 
            fitnessHistory={gaResult?.fitnessHistory || []} 
            isLoading={isRunning && (!gaResult || gaResult.fitnessHistory.length === 0)}
          />
          <LogView logs={logs} />
        </div>
      </div>
       <footer className="text-center mt-12 py-4 text-slate-500 text-sm">
        <p>Powered by React, Tailwind CSS, and Genetic Algorithms.</p>
      </footer>
    </div>
  );
};

export default App;
