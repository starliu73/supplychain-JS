
import { Supplier, Chromosome, GAParameters, DemandConstraints, GARunResult, FitnessDataPoint, SolutionMetrics, LogEntry } from '../types';
import { PENALTY_FACTOR_DEMAND, PENALTY_FACTOR_QUALITY } from '../constants';

// Helper: Calculate metrics and fitness for a chromosome
const evaluateChromosome = (
  chromosome: Chromosome,
  suppliers: Supplier[],
  constraints: DemandConstraints
): SolutionMetrics => {
  const selectedSuppliers: Supplier[] = [];
  let totalCost = 0;
  let totalQualityPoints = 0;
  let totalCapacity = 0;

  chromosome.forEach((gene, index) => {
    if (gene === 1) {
      const supplier = suppliers[index];
      selectedSuppliers.push(supplier);
      totalCost += supplier.cost;
      totalQualityPoints += supplier.quality;
      totalCapacity += supplier.capacity;
    }
  });

  const averageQuality = selectedSuppliers.length > 0 ? totalQualityPoints / selectedSuppliers.length : 0;

  // Penalties
  let penalty = 0;
  if (totalCapacity < constraints.requiredDemand) {
    penalty += (constraints.requiredDemand - totalCapacity) * PENALTY_FACTOR_DEMAND;
  }
  if (selectedSuppliers.length > 0 && averageQuality < constraints.minQualityAverage) {
     // Only apply quality penalty if suppliers are selected, otherwise demand penalty covers it
    penalty += (constraints.minQualityAverage - averageQuality) * PENALTY_FACTOR_QUALITY;
  } else if (selectedSuppliers.length === 0 && constraints.requiredDemand > 0) {
    // If no suppliers selected but demand exists, it's heavily penalized by demand penalty already
    // but we can add a small extra penalty for quality not being met implicitly
     penalty += constraints.minQualityAverage * PENALTY_FACTOR_QUALITY; // Penalize for not meeting quality by default
  }


  const fitness = totalCost + penalty; // Lower is better

  return { selectedSuppliers, totalCost, averageQuality, totalCapacity, fitness };
};

// Initialize population
const initializePopulation = (popSize: number, numSuppliers: number): Chromosome[] => {
  const population: Chromosome[] = [];
  for (let i = 0; i < popSize; i++) {
    const chromosome: Chromosome = Array(numSuppliers).fill(0).map(() => Math.random() < 0.3 ? 1 : 0); // Start with ~30% suppliers selected
    // Ensure at least one supplier is selected if possible, to avoid empty initial solutions completely dominating early stage if penalties are not tuned.
    // This is a heuristic, might not always be best.
    if (numSuppliers > 0 && chromosome.every(gene => gene === 0)) {
        const randomIndex = Math.floor(Math.random() * numSuppliers);
        chromosome[randomIndex] = 1;
    }
    population.push(chromosome);
  }
  return population;
};

// Tournament selection
const selectParentsTournament = (
  population: Chromosome[],
  fitnesses: number[],
  tournamentSize: number = 3
): [Chromosome, Chromosome] => {
  const selectOne = (): Chromosome => {
    let bestIndex = -1;
    let bestFitness = Infinity;
    for (let i = 0; i < tournamentSize; i++) {
      const randomIndex = Math.floor(Math.random() * population.length);
      if (fitnesses[randomIndex] < bestFitness) {
        bestFitness = fitnesses[randomIndex];
        bestIndex = randomIndex;
      }
    }
    return population[bestIndex];
  };
  return [selectOne(), selectOne()];
};

// Single-point crossover
const crossover = (
  parent1: Chromosome,
  parent2: Chromosome,
  crossoverRate: number
): [Chromosome, Chromosome] => {
  if (Math.random() > crossoverRate || parent1.length <= 1) {
    return [[...parent1], [...parent2]]; // No crossover
  }
  const point = Math.floor(Math.random() * (parent1.length - 1)) + 1;
  const child1 = [...parent1.slice(0, point), ...parent2.slice(point)];
  const child2 = [...parent2.slice(0, point), ...parent1.slice(point)];
  return [child1, child2];
};

// Bit-flip mutation
const mutate = (chromosome: Chromosome, mutationRate: number): Chromosome => {
  return chromosome.map(gene => (Math.random() < mutationRate ? 1 - gene : gene));
};

// Main GA function
export const runGeneticAlgorithm = async (
  suppliers: Supplier[],
  gaParams: GAParameters,
  constraints: DemandConstraints,
  addLog: (message: string, type?: LogEntry['type']) => void,
  updateProgress: (generation: number, bestFitnessThisGen: number, avgFitnessThisGen: number) => void
): Promise<GARunResult> => {
  
  if (suppliers.length === 0) {
    return { bestSolutionMetrics: null, fitnessHistory: [] };
  }

  let population = initializePopulation(gaParams.populationSize, suppliers.length);
  const fitnessHistory: FitnessDataPoint[] = [];
  let overallBestSolutionMetrics: SolutionMetrics | null = null;

  for (let gen = 0; gen < gaParams.generations; gen++) {
    const fitnesses = population.map(chrom => evaluateChromosome(chrom, suppliers, constraints).fitness);
    
    // Find best in current generation
    let bestFitnessThisGen = Infinity;
    let bestChromThisGenIndex = -1;
    let totalFitnessThisGen = 0;

    fitnesses.forEach((fitness, index) => {
      totalFitnessThisGen += fitness;
      if (fitness < bestFitnessThisGen) {
        bestFitnessThisGen = fitness;
        bestChromThisGenIndex = index;
      }
    });
    const avgFitnessThisGen = totalFitnessThisGen / population.length;

    // Update overall best solution
    const currentBestMetrics = evaluateChromosome(population[bestChromThisGenIndex], suppliers, constraints);
    if (!overallBestSolutionMetrics || currentBestMetrics.fitness < overallBestSolutionMetrics.fitness) {
      overallBestSolutionMetrics = currentBestMetrics;
    }
    
    // Log progress and update fitness history for chart
    if ((gen + 1) % 10 === 0 || gen === 0 || gen === gaParams.generations - 1) {
       addLog(`Generation ${gen + 1}: Best Fitness = ${currentBestMetrics.fitness.toFixed(2)}, Avg Fitness = ${avgFitnessThisGen.toFixed(2)}`);
    }
    fitnessHistory.push({ generation: gen + 1, bestFitness: currentBestMetrics.fitness, avgFitness: avgFitnessThisGen });
    updateProgress(gen + 1, currentBestMetrics.fitness, avgFitnessThisGen);


    // Create new population
    const newPopulation: Chromosome[] = [];

    // Elitism: carry over the best individuals
    const sortedPopulationIndices = fitnesses
        .map((fitness, index) => ({ fitness, index }))
        .sort((a, b) => a.fitness - b.fitness)
        .map(item => item.index);
        
    for(let i=0; i < gaParams.elitismCount && i < sortedPopulationIndices.length; i++) {
        newPopulation.push([...population[sortedPopulationIndices[i]]]);
    }


    // Fill the rest of the new population
    while (newPopulation.length < gaParams.populationSize) {
      const [parent1, parent2] = selectParentsTournament(population, fitnesses);
      let [child1, child2] = crossover(parent1, parent2, gaParams.crossoverRate);
      child1 = mutate(child1, gaParams.mutationRate);
      child2 = mutate(child2, gaParams.mutationRate);
      newPopulation.push(child1);
      if (newPopulation.length < gaParams.populationSize) {
        newPopulation.push(child2);
      }
    }
    population = newPopulation;
    
    // Yield to event loop to prevent UI freezing on very long runs
    if (gen % 20 === 0) { // Adjust frequency as needed
        await new Promise(resolve => setTimeout(resolve, 0));
    }
  }

  return { bestSolutionMetrics: overallBestSolutionMetrics, fitnessHistory };
};
