
import React from 'react';
import { GAParameters, DemandConstraints } from '../types';

interface GAParametersPanelProps {
  gaParams: GAParameters;
  setGaParams: React.Dispatch<React.SetStateAction<GAParameters>>;
  demandConstraints: DemandConstraints;
  setDemandConstraints: React.Dispatch<React.SetStateAction<DemandConstraints>>;
  disabled: boolean;
}

const InputField: React.FC<{label: string, id: string, type?: string, value: string | number, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, disabled: boolean, min?: string, max?: string, step?: string, hint?: string}> = 
  ({label, id, type="number", value, onChange, disabled, min, max, step, hint}) => (
  <div>
    <label htmlFor={id} className="block text-sm font-medium text-slate-300">{label}</label>
    <input
      type={type}
      id={id}
      name={id}
      value={value}
      onChange={onChange}
      disabled={disabled}
      min={min}
      max={max}
      step={step}
      className="mt-1 block w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-md shadow-sm placeholder-slate-500 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm text-white disabled:opacity-70"
    />
    {hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
  </div>
);


const GAParametersPanel: React.FC<GAParametersPanelProps> = ({ gaParams, setGaParams, demandConstraints, setDemandConstraints, disabled }) => {
  const handleGaParamChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setGaParams(prev => ({ ...prev, [name]: parseInt(value, 10) || parseFloat(value) }));
  };

  const handleDemandConstraintChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDemandConstraints(prev => ({ ...prev, [name]: parseFloat(value) }));
  };

  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6">
      <h2 className="text-2xl font-semibold text-primary-400 mb-4 border-b border-slate-700 pb-2">算法参数与约束</h2>
      
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-slate-200 mt-2">遗传算法参数</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label="种群大小" id="populationSize" value={gaParams.populationSize} onChange={handleGaParamChange} disabled={disabled} min="10" />
          <InputField label="迭代代数" id="generations" value={gaParams.generations} onChange={handleGaParamChange} disabled={disabled} min="10" />
          <InputField label="交叉概率" id="crossoverRate" type="number" value={gaParams.crossoverRate} onChange={handleGaParamChange} disabled={disabled} min="0" max="1" step="0.01" />
          <InputField label="变异概率" id="mutationRate" type="number" value={gaParams.mutationRate} onChange={handleGaParamChange} disabled={disabled} min="0" max="1" step="0.01" />
           <InputField label="精英数量" id="elitismCount" value={gaParams.elitismCount} onChange={handleGaParamChange} disabled={disabled} min="0" hint="最佳个体直接进入下一代"/>
        </div>

        <h3 className="text-lg font-medium text-slate-200 mt-6">需求与约束</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label="总需求量" id="requiredDemand" value={demandConstraints.requiredDemand} onChange={handleDemandConstraintChange} disabled={disabled} min="0" />
          <InputField label="最低平均质量" id="minQualityAverage" type="number" value={demandConstraints.minQualityAverage} onChange={handleDemandConstraintChange} disabled={disabled} min="0" max="10" step="0.1" />
        </div>
      </div>
    </div>
  );
};

export default GAParametersPanel;
