
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { FitnessDataPoint } from '../types';
import { ChartBarIcon, ExclamationTriangleIcon } from './Icons';

interface EvolutionChartProps {
  fitnessHistory: FitnessDataPoint[];
  isLoading: boolean;
}

const EvolutionChart: React.FC<EvolutionChartProps> = ({ fitnessHistory, isLoading }) => {
  if (isLoading && fitnessHistory.length === 0) {
     return (
      <div className="bg-slate-800 shadow-xl rounded-lg p-6">
        <h2 className="text-2xl font-semibold text-primary-400 mb-4 flex items-center">
          <ChartBarIcon className="w-6 h-6 mr-2" />
          适应度进化曲线
        </h2>
        <div className="flex justify-center items-center h-64 text-slate-400">
          <svg className="animate-spin h-8 w-8 text-primary-500 mr-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          图表生成中...
        </div>
      </div>
    );
  }
  
  if (!isLoading && fitnessHistory.length === 0) {
    return (
      <div className="bg-slate-800 shadow-xl rounded-lg p-6">
        <h2 className="text-2xl font-semibold text-primary-400 mb-4 flex items-center">
          <ChartBarIcon className="w-6 h-6 mr-2" />
          适应度进化曲线
        </h2>
        <div className="flex flex-col items-center justify-center h-64 text-slate-400">
          <ExclamationTriangleIcon className="w-12 h-12 text-yellow-500 mb-3" />
          <p>暂无数据以生成图表。</p>
          <p className="text-sm">请运行算法以查看进化过程。</p>
        </div>
      </div>
    );
  }

  // Ensure fitness values are numbers and handle potential NaN/Infinity for robust charting
  const sanitizedHistory = fitnessHistory.map(p => ({
    ...p,
    bestFitness: Number.isFinite(p.bestFitness) ? p.bestFitness : null, 
    avgFitness: Number.isFinite(p.avgFitness) ? p.avgFitness : null,
  })).filter(p => p.bestFitness !== null || p.avgFitness !== null);


  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6">
      <h2 className="text-2xl font-semibold text-primary-400 mb-6 flex items-center border-b border-slate-700 pb-2">
        <ChartBarIcon className="w-6 h-6 mr-2" />
        适应度进化曲线
      </h2>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
          <LineChart data={sanitizedHistory} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
            <XAxis dataKey="generation" stroke="#94a3b8" name="代数" />
            <YAxis stroke="#94a3b8" 
                domain={['auto', 'auto']}
                allowDataOverflow={true}
                name="适应度值"
                tickFormatter={(value) => Number.isFinite(value) ? value.toFixed(0) : ''}
            />
            <Tooltip
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '0.5rem' }}
              labelStyle={{ color: '#cbd5e1', fontWeight: 'bold' }}
              itemStyle={{ color: '#94a3b8' }}
              formatter={(value: number, name: string) => [`${Number(value).toFixed(2)}`, name === 'bestFitness' ? '最佳适应度' : '平均适应度']}
            />
            <Legend wrapperStyle={{ color: '#e2e8f0' }} formatter={(value) => value === 'bestFitness' ? '最佳适应度' : '平均适应度'} />
            <Line type="monotone" dataKey="bestFitness" stroke="#3b82f6" strokeWidth={2} dot={{r:1}} activeDot={{ r: 6 }} name="最佳适应度" connectNulls={true} />
            <Line type="monotone" dataKey="avgFitness" stroke="#8b5cf6" strokeWidth={2} dot={{r:1}} activeDot={{ r: 6 }} name="平均适应度" connectNulls={true} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default EvolutionChart;
