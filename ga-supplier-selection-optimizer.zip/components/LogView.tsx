
import React from 'react';
import { LogEntry } from '../types';
import { InformationCircleIcon, CheckCircleIcon, ExclamationCircleIcon, Bars3Icon } from './Icons';

interface LogViewProps {
  logs: LogEntry[];
}

const LogView: React.FC<LogViewProps> = ({ logs }) => {
  const getIconForType = (type: LogEntry['type']) => {
    switch (type) {
      case 'success': return <CheckCircleIcon className="w-5 h-5 text-green-400" />;
      case 'error': return <ExclamationCircleIcon className="w-5 h-5 text-red-400" />;
      case 'info':
      default:
        return <InformationCircleIcon className="w-5 h-5 text-blue-400" />;
    }
  };

  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6">
      <h2 className="text-2xl font-semibold text-primary-400 mb-4 flex items-center border-b border-slate-700 pb-2">
        <Bars3Icon className="w-6 h-6 mr-2" />
        运行日志
      </h2>
      {logs.length === 0 ? (
        <p className="text-slate-500 text-center py-4">日志为空。运行算法以查看消息。</p>
      ) : (
        <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
          {logs.map(log => (
            <div
              key={log.id}
              className={`flex items-start p-2.5 rounded-md text-sm ${
                log.type === 'error' ? 'bg-red-900/30 text-red-300' : 
                log.type === 'success' ? 'bg-green-900/30 text-green-300' : 
                'bg-slate-700/50 text-slate-300'
              }`}
            >
              <span className="mr-2 flex-shrink-0">{getIconForType(log.type)}</span>
              <span>{log.message}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default LogView;
