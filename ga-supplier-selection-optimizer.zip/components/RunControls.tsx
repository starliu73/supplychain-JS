
import React from 'react';
import { PlayIcon, StopIcon, ArrowPathIcon } from './Icons';

interface RunControlsProps {
  onRun: () => void;
  onReset: () => void;
  isRunning: boolean;
  currentGeneration: number;
  totalGenerations: number;
}

const RunControls: React.FC<RunControlsProps> = ({ onRun, onReset, isRunning, currentGeneration, totalGenerations }) => {
  const progressPercentage = totalGenerations > 0 ? (currentGeneration / totalGenerations) * 100 : 0;

  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6">
      <h2 className="text-2xl font-semibold text-primary-400 mb-6 border-b border-slate-700 pb-2">控制面板</h2>
      <div className="space-y-4">
        <button
          onClick={onRun}
          disabled={isRunning}
          className="w-full flex items-center justify-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-green-500 disabled:opacity-50 transition-colors"
        >
          {isRunning ? <StopIcon className="w-5 h-5 mr-2 animate-spin" /> : <PlayIcon className="w-5 h-5 mr-2" />}
          {isRunning ? `运行中 (代: ${currentGeneration}/${totalGenerations})` : '开始优化'}
        </button>
        <button
          onClick={onReset}
          disabled={isRunning}
          className="w-full flex items-center justify-center px-6 py-3 border border-slate-600 rounded-md shadow-sm text-base font-medium text-slate-300 bg-slate-700 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-primary-500 disabled:opacity-50 transition-colors"
        >
          <ArrowPathIcon className="w-5 h-5 mr-2" />
          重置参数
        </button>
      </div>
      {isRunning && (
        <div className="mt-4">
          <div className="text-sm text-slate-400 mb-1 text-center">
            优化进度: {currentGeneration} / {totalGenerations} 代
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2.5">
            <div
              className="bg-primary-600 h-2.5 rounded-full transition-all duration-150 ease-linear"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RunControls;
