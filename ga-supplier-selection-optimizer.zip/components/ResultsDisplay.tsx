
import React from 'react';
import { SolutionMetrics, Supplier } from '../types';
import { CheckCircleIcon, ExclamationTriangleIcon, LightBulbIcon } from './Icons';

interface ResultsDisplayProps {
  bestSolutionMetrics: SolutionMetrics | null;
  isLoading: boolean;
}

const MetricCard: React.FC<{title: string; value: string | number; unit?: string; icon: React.ReactNode}> = ({ title, value, unit, icon }) => (
  <div className="bg-slate-700 p-4 rounded-lg shadow flex items-center">
    <div className="mr-3 text-primary-400">{icon}</div>
    <div>
      <h4 className="text-sm text-slate-400 font-medium">{title}</h4>
      <p className="text-xl font-semibold text-white">
        {value} <span className="text-xs text-slate-400">{unit}</span>
      </p>
    </div>
  </div>
);


const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ bestSolutionMetrics, isLoading }) => {
  if (isLoading) {
    return (
      <div className="bg-slate-800 shadow-xl rounded-lg p-6 text-center">
        <h2 className="text-2xl font-semibold text-primary-400 mb-4">优化结果</h2>
        <div className="flex justify-center items-center h-48">
          <svg className="animate-spin h-10 w-10 text-primary-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="ml-4 text-slate-300 text-lg">正在计算最佳方案...</p>
        </div>
      </div>
    );
  }

  if (!bestSolutionMetrics) {
    return (
      <div className="bg-slate-800 shadow-xl rounded-lg p-6">
        <h2 className="text-2xl font-semibold text-primary-400 mb-4">优化结果</h2>
        <div className="flex flex-col items-center justify-center h-48 text-slate-400">
            <ExclamationTriangleIcon className="w-12 h-12 text-yellow-500 mb-3"/>
            <p className="text-lg">等待运行或未找到可行解。</p>
            <p className="text-sm">请配置参数并运行算法，或调整约束条件。</p>
        </div>
      </div>
    );
  }

  const { selectedSuppliers, totalCost, averageQuality, totalCapacity, fitness } = bestSolutionMetrics;

  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6">
      <h2 className="text-2xl font-semibold text-primary-400 mb-6 border-b border-slate-700 pb-2">最佳方案</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard title="总成本" value={totalCost.toFixed(2)} unit="元" icon={<CheckCircleIcon className="w-8 h-8"/>} />
        <MetricCard title="平均质量" value={averageQuality.toFixed(2)} unit="/10" icon={<CheckCircleIcon className="w-8 h-8"/>} />
        <MetricCard title="总产能" value={totalCapacity} unit="单位" icon={<CheckCircleIcon className="w-8 h-8"/>} />
        <MetricCard title="适应度值" value={fitness.toFixed(2)} unit="(越低越好)" icon={<LightBulbIcon className="w-8 h-8"/>} />
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-200 mb-3">选中的供应商:</h3>
        {selectedSuppliers.length > 0 ? (
          <ul className="space-y-2 max-h-60 overflow-y-auto bg-slate-750 p-3 rounded-md">
            {selectedSuppliers.map((s: Supplier) => (
              <li key={s.id} className="p-3 bg-slate-700 rounded-md shadow flex justify-between items-center">
                <div>
                  <span className="font-medium text-primary-300">{s.name} (ID: {s.id})</span>
                  <p className="text-xs text-slate-400">
                    成本: {s.cost.toFixed(2)}, 质量: {s.quality.toFixed(1)}, 产能: {s.capacity}
                  </p>
                </div>
                 <CheckCircleIcon className="w-5 h-5 text-green-500" />
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-400 p-3 bg-slate-750 rounded-md">未选择任何供应商 (可能未找到满足约束的方案)。</p>
        )}
      </div>
    </div>
  );
};

export default ResultsDisplay;
