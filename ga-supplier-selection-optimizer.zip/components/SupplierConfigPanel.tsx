
import React from 'react';
import { Supplier } from '../types';
import { PlusCircleIcon, TrashIcon, PencilIcon, CheckIcon, XCircleIcon } from './Icons'; // Assuming Icons.tsx

interface EditableSupplierRowProps {
  supplier: Supplier;
  onUpdate: (updatedSupplier: Supplier) => void;
  onDelete: () => void;
  disabled: boolean;
  isEditing: boolean;
  onEditToggle: () => void;
}

const EditableSupplierRow: React.FC<EditableSupplierRowProps> = ({ supplier, onUpdate, onDelete, disabled, isEditing, onEditToggle }) => {
  const [editableSupplier, setEditableSupplier] = React.useState<Supplier>(supplier);

  React.useEffect(() => {
    setEditableSupplier(supplier);
  }, [supplier]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setEditableSupplier(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value,
    }));
  };

  const handleSave = () => {
    onUpdate(editableSupplier);
    onEditToggle();
  };

  const handleCancel = () => {
    setEditableSupplier(supplier); // Reset changes
    onEditToggle();
  }

  if (isEditing) {
    return (
      <tr className="bg-slate-700">
        <td className="p-2 border-b border-slate-600"><input type="text" name="name" value={editableSupplier.name} onChange={handleChange} className="w-full bg-slate-600 text-white p-1 rounded border border-slate-500 focus:ring-primary-500 focus:border-primary-500" /></td>
        <td className="p-2 border-b border-slate-600"><input type="number" name="cost" value={editableSupplier.cost} onChange={handleChange} className="w-20 bg-slate-600 text-white p-1 rounded border border-slate-500 focus:ring-primary-500 focus:border-primary-500" /></td>
        <td className="p-2 border-b border-slate-600"><input type="number" name="quality" value={editableSupplier.quality} step="0.1" min="0" max="10" onChange={handleChange} className="w-20 bg-slate-600 text-white p-1 rounded border border-slate-500 focus:ring-primary-500 focus:border-primary-500" /></td>
        <td className="p-2 border-b border-slate-600"><input type="number" name="capacity" value={editableSupplier.capacity} onChange={handleChange} className="w-20 bg-slate-600 text-white p-1 rounded border border-slate-500 focus:ring-primary-500 focus:border-primary-500" /></td>
        <td className="p-2 border-b border-slate-600 flex space-x-1">
          <button onClick={handleSave} className="p-1 text-green-400 hover:text-green-300 disabled:opacity-50" disabled={disabled}><CheckIcon className="w-5 h-5"/></button>
          <button onClick={handleCancel} className="p-1 text-red-400 hover:text-red-300 disabled:opacity-50" disabled={disabled}><XCircleIcon className="w-5 h-5"/></button>
        </td>
      </tr>
    );
  }

  return (
    <tr className="hover:bg-slate-700 transition-colors">
      <td className="p-2 border-b border-slate-600">{supplier.name} ({supplier.id})</td>
      <td className="p-2 border-b border-slate-600">{supplier.cost.toFixed(2)}</td>
      <td className="p-2 border-b border-slate-600">{supplier.quality.toFixed(1)}</td>
      <td className="p-2 border-b border-slate-600">{supplier.capacity}</td>
      <td className="p-2 border-b border-slate-600">
        <button onClick={onEditToggle} className="p-1 text-primary-400 hover:text-primary-300 disabled:opacity-50" disabled={disabled}><PencilIcon className="w-4 h-4"/></button>
        <button onClick={onDelete} className="p-1 text-red-400 hover:text-red-300 disabled:opacity-50 ml-1" disabled={disabled}><TrashIcon className="w-4 h-4"/></button>
      </td>
    </tr>
  );
};


interface SupplierConfigPanelProps {
  suppliers: Supplier[];
  setSuppliers: React.Dispatch<React.SetStateAction<Supplier[]>>;
  disabled: boolean;
}

const SupplierConfigPanel: React.FC<SupplierConfigPanelProps> = ({ suppliers, setSuppliers, disabled }) => {
  const [editingSupplierId, setEditingSupplierId] = React.useState<string | null>(null);

  const handleAddSupplier = () => {
    const newId = `S${suppliers.length + 1}`;
    const newSupplier: Supplier = { id: newId, name: `Supplier ${suppliers.length + 1}`, cost: 100, quality: 5, capacity: 50 };
    setSuppliers(prev => [...prev, newSupplier]);
    setEditingSupplierId(newId); // Automatically edit the new supplier
  };

  const handleUpdateSupplier = (updatedSupplier: Supplier) => {
    setSuppliers(prev => prev.map(s => s.id === updatedSupplier.id ? updatedSupplier : s));
  };

  const handleDeleteSupplier = (id: string) => {
    setSuppliers(prev => prev.filter(s => s.id !== id));
    if (editingSupplierId === id) {
      setEditingSupplierId(null);
    }
  };
  
  const toggleEdit = (id: string) => {
    setEditingSupplierId(prevId => (prevId === id ? null : id));
  };


  return (
    <div className="bg-slate-800 shadow-xl rounded-lg p-6">
      <h2 className="text-2xl font-semibold text-primary-400 mb-4 border-b border-slate-700 pb-2">供应商配置</h2>
      <div className="overflow-x-auto mb-4 max-h-96">
        <table className="w-full text-sm text-left text-slate-300">
          <thead className="text-xs text-primary-300 uppercase bg-slate-700">
            <tr>
              <th className="p-2">名称 (ID)</th>
              <th className="p-2">成本</th>
              <th className="p-2">质量 (1-10)</th>
              <th className="p-2">产能</th>
              <th className="p-2">操作</th>
            </tr>
          </thead>
          <tbody>
            {suppliers.map(supplier => (
              <EditableSupplierRow
                key={supplier.id}
                supplier={supplier}
                onUpdate={handleUpdateSupplier}
                onDelete={() => handleDeleteSupplier(supplier.id)}
                disabled={disabled}
                isEditing={editingSupplierId === supplier.id}
                onEditToggle={() => toggleEdit(supplier.id)}
              />
            ))}
             {suppliers.length === 0 && (
                <tr>
                    <td colSpan={5} className="text-center p-4 text-slate-500">
                        暂无供应商。请添加供应商以开始。
                    </td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
      <button
        onClick={handleAddSupplier}
        disabled={disabled}
        className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-primary-500 disabled:opacity-50 transition-colors"
      >
        <PlusCircleIcon className="w-5 h-5 mr-2" />
        添加供应商
      </button>
    </div>
  );
};

export default SupplierConfigPanel;
