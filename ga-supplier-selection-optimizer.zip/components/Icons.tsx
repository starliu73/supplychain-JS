
import React from 'react';

// Generic Icon Props
interface IconProps extends React.SVGProps<SVGSVGElement> {}

export const PlayIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M2 10a8 8 0 1116 0 8 8 0 01-16 0zm6.39-2.908a.75.75 0 01.766.027l3.5 2.25a.75.75 0 010 1.262l-3.5 2.25A.75.75 0 018 12.25v-4.5a.75.75 0 01.39-.658z" clipRule="evenodd" />
  </svg>
);

export const StopIcon: React.FC<IconProps> = (props) => (
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
  <path d="M5.25 3A2.25 2.25 0 003 5.25v9.5A2.25 2.25 0 005.25 17h9.5A2.25 2.25 0 0017 14.75v-9.5A2.25 2.25 0 0014.75 3h-9.5z" />
</svg>
);


export const ArrowPathIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M15.312 5.312a.75.75 0 010 1.06L11.874 9.81l3.438 3.438a.75.75 0 11-1.06 1.06L10.813 10.87l-3.438 3.438a.75.75 0 11-1.06-1.06l3.438-3.438-3.438-3.438a.75.75 0 011.06-1.06l3.438 3.438 3.438-3.438a.75.75 0 011.06 0zM5.53 4.22A.75.75 0 016 4h8.5a.75.75 0 01.75.75v8.5a.75.75 0 01-1.5 0V5.5H6a.75.75 0 01-.47-.22zM2.5 10a7.5 7.5 0 1115 0 7.5 7.5 0 01-15 0z" clipRule="evenodd" />
     <path fillRule="evenodd" d="M15.312 5.312a.75.75 0 010 1.06L11.874 9.81l3.438 3.438a.75.75 0 11-1.06 1.06L10.813 10.87l-3.438 3.438a.75.75 0 11-1.06-1.06l3.438-3.438-3.438-3.438a.75.75 0 011.06-1.06l3.438 3.438 3.438-3.438a.75.75 0 011.06 0zM4.75 2.5c-1.115 0-2.07.418-2.783 1.082A4.456 4.456 0 001.25 5.5v1.285A.75.75 0 002.75 7.5h.5a.75.75 0 00.75-.75V5.5c0-.501.192-.984.538-1.348A2.94 2.94 0 016.082 3.5h7.836a2.94 2.94 0 011.594.602A2.953 2.953 0 0116.25 5.5v7.836a2.94 2.94 0 01-.602 1.594c-.198.24-.43.454-.688.636a.75.75 0 00.44 1.368 4.456 4.456 0 002.042-2.31A4.439 4.439 0 0018.75 13.336V5.5c0-1.115-.418-2.07-1.082-2.783A4.439 4.439 0 0015.25 1h-9.5c-1.115 0-2.07.418-2.783 1.082A4.439 4.439 0 001.75 4.5V1H.75A.75.75 0 000 1.75V11A.75.75 0 00.75 11.75h9.5A.75.75 0 0011 11V1.75a.75.75 0 00-.75-.75H4.75z" clipRule="evenodd" />
     <path d="M6.772 11.798a.75.75 0 001.06 0l2.561-2.561a.75.75 0 10-1.06-1.06L7.228 10.28V4.75a.75.75 0 00-1.5 0v5.53l-2.104-2.103a.75.75 0 10-1.061 1.06L6.772 11.798z" />
     <path d="M12.96 2.535a.75.75 0 010 1.06L10.907 5.65a.75.75 0 01-1.06-.027L7.009 2.513a.75.75 0 011.087-1.033L10 3.287l2.218-1.788a.75.75 0 01.742.036zM3.75 10a.75.75 0 01.75-.75H11a.75.75 0 010 1.5H4.5a.75.75 0 01-.75-.75z" />
  </svg>
);


export const PlusCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.75-11.25a.75.75 0 00-1.5 0v2.5h-2.5a.75.75 0 000 1.5h2.5v2.5a.75.75 0 001.5 0v-2.5h2.5a.75.75 0 000-1.5h-2.5v-2.5z" clipRule="evenodd" />
  </svg>
);

export const TrashIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M8.75 1A2.75 2.75 0 006 3.75H4.5a.75.75 0 000 1.5h11a.75.75 0 000-1.5H14A2.75 2.75 0 0011.25 1h-2.5zM10 4c.84 0 1.536.255 2.106.683A3.479 3.479 0 0113 5.558V14.25a1.75 1.75 0 01-1.75 1.75h-2.5a1.75 1.75 0 01-1.75-1.75V5.558a3.478 3.478 0 01.894-.875C8.464 4.255 9.16 4 10 4zM7 5.558V14.25a.25.25 0 00.25.25h5.5a.25.25 0 00.25-.25V5.558C12.448 6.448 11.292 7 10 7c-1.292 0-2.448-.552-3-1.442z" clipRule="evenodd" />
  </svg>
);

export const PencilIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M2.695 14.763l-1.262 3.154a.5.5 0 00.65.65l3.155-1.262a4 4 0 001.343-.885L17.5 5.5a2.121 2.121 0 00-3-3L3.58 13.42a4 4 0 00-.885 1.343z" />
  </svg>
);

export const CheckIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" />
  </svg>
);

export const XCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.28 7.22a.75.75 0 00-1.06 1.06L8.94 10l-1.72 1.72a.75.75 0 101.06 1.06L10 11.06l1.72 1.72a.75.75 0 101.06-1.06L11.06 10l1.72-1.72a.75.75 0 00-1.06-1.06L10 8.94 8.28 7.22z" clipRule="evenodd" />
  </svg>
);


export const CheckCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
  </svg>
);

export const ExclamationTriangleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.519 13.007c1.155 2-1.196 4.49-3.231 3.429h-10.95c-2.035 1.06-4.386-1.428-3.231-3.429L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z" clipRule="evenodd" />
  </svg>
);

export const LightBulbIcon: React.FC<IconProps> = (props) => (
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
  <path d="M12.75 16.5a.75.75 0 001.5 0V15c1.138 0 2.163-.333 3.015-.905C18.156 13.528 19.5 12.115 19.5 10.5c0-2.887-2.457-4.717-5.25-4.717A5.25 5.25 0 009 10.5c0 1.615 1.344 3.028 2.235 3.595.852.572 1.877.905 3.015.905v1.5zM12 21a.75.75 0 01.75-.75h.008a.75.75 0 01.75.75v.008a.75.75 0 01-.75.75h-.008a.75.75 0 01-.75-.75v-.008zM12.75 2.25a.75.75 0 00-1.5 0v1.503a8.25 8.25 0 00-4.493 4.493H5.25a.75.75 0 000 1.5h1.503a8.25 8.25 0 004.493 4.493V15a.75.75 0 001.5 0v-1.503a8.25 8.25 0 004.493-4.493H18.75a.75.75 0 000-1.5h-1.503A8.25 8.25 0 0012.75 3.753V2.25z" />
</svg>
);

export const ChartBarIcon: React.FC<IconProps> = (props) => (
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
  <path d="M3 13.5A1.5 1.5 0 014.5 12H6a1.5 1.5 0 011.5 1.5v6A1.5 1.5 0 016 21H4.5A1.5 1.5 0 013 19.5v-6zM8.25 8.25A1.5 1.5 0 019.75 6.75H11.25a1.5 1.5 0 011.5 1.5v11.25a1.5 1.5 0 01-1.5 1.5H9.75a1.5 1.5 0 01-1.5-1.5V8.25zM13.5 3A1.5 1.5 0 0115 1.5h1.5a1.5 1.5 0 011.5 1.5v16.5a1.5 1.5 0 01-1.5 1.5H15a1.5 1.5 0 01-1.5-1.5V3z" />
</svg>
);

export const InformationCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z" clipRule="evenodd" />
  </svg>
);

export const ExclamationCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
  </svg>
);

export const Bars3Icon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10zm0 5.25a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75a.75.75 0 01-.75-.75z" clipRule="evenodd" />
  </svg>
);

// ... Add other icons as needed
