
import { Supplier, GAParameters, DemandConstraints } from './types';

export const DEFAULT_SUPPLIERS: Supplier[] = [
  { id: 'S1', name: 'Supplier A', cost: 100, quality: 7, capacity: 50 },
  { id: 'S2', name: 'Supplier B', cost: 120, quality: 9, capacity: 60 },
  { id: 'S3', name: 'Supplier C', cost: 90, quality: 6, capacity: 40 },
  { id: 'S4', name: 'Supplier D', cost: 150, quality: 10, capacity: 70 },
  { id: 'S5', name: 'Supplier E', cost: 110, quality: 8, capacity: 55 },
  { id: 'S6', name: 'Supplier F', cost: 130, quality: 7, capacity: 65 },
  { id: 'S7', name: 'Supplier G', cost: 80, quality: 5, capacity: 30 },
  { id: 'S8', name: 'Supplier H', cost: 160, quality: 9, capacity: 80 },
];

export const DEFAULT_GA_PARAMETERS: GAParameters = {
  populationSize: 50,
  generations: 100,
  crossoverRate: 0.8,
  mutationRate: 0.05,
  elitismCount: 2,
};

export const DEFAULT_DEMAND_CONSTRAINTS: DemandConstraints = {
  requiredDemand: 100,
  minQualityAverage: 7.0,
};

export const PENALTY_FACTOR_DEMAND = 1000; // Penalty multiplier for not meeting demand
export const PENALTY_FACTOR_QUALITY = 500;  // Penalty multiplier for not meeting quality
