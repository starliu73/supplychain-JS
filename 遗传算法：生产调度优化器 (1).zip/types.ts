
export interface Product {
  id: string;
  name: string;
  processingTime: number; // Time units this product takes
}

export interface Machine {
  id: string;
  name: string;
}

// A Chromosome is an ordered list of product IDs, representing the sequence of production.
export type Chromosome = string[]; // Array of Product IDs

export interface ScheduledTask {
  productId: string;
  productName: string;
  machineId: string;
  machineName: string;
  startTime: number;
  endTime: number;
  duration: number;
}

export interface Schedule {
  tasks: ScheduledTask[];
  makespan: number; // Total time to complete all tasks
}

export interface Individual {
  chromosome: Chromosome;
  fitness: number;
  schedule?: Schedule; // Optional: store the generated schedule
}

export type Population = Individual[];

export interface FitnessHistoryPoint {
  generation: number;
  bestFitness: number;
  averageFitness: number;
}

export interface GAParameters {
  populationSize: number;
  numGenerations: number;
  mutationRate: number; // 0.0 to 1.0
  crossoverRate: number; // 0.0 to 1.0
  tournamentSize: number;
}
    