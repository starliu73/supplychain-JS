
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { FitnessHistoryPoint } from '../types';
import { InfoIcon, ChartBarIcon } from './IconComponents';

interface FitnessChartProps {
  history: FitnessHistoryPoint[];
}

const FitnessChart: React.FC<FitnessChartProps> = ({ history }) => {
  if (history.length === 0) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg shadow-xl flex flex-col items-center justify-center h-[300px]">
        <ChartBarIcon className="w-12 h-12 text-sky-500 mb-4" />
        <p className="text-gray-400 text-lg">适应度历史将在此处显示。</p>
        <p className="text-gray-500 text-sm">开始模拟以查看进度。</p>
      </div>
    );
  }
  
  // Custom tooltip for better readability
  const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-700/80 backdrop-blur-sm p-3 rounded shadow-lg border border-gray-600">
          <p className="label text-sm text-sky-300">{`代数: ${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={`item-${index}`} style={{ color: entry.color }} className="text-xs">
              {`${entry.name}: ${entry.value.toFixed(6)}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-gray-800 p-4 md:p-6 rounded-lg shadow-xl h-[350px] md:h-[400px]">
      <h3 className="text-lg font-semibold text-sky-400 mb-4">适应度进化</h3>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={history}
          margin={{ top: 5, right: 20, left: 0, bottom: 20 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" /> {/* gray-700 */}
          <XAxis 
            dataKey="generation" 
            stroke="#A0AEC0" /* gray-400 */
            label={{ value: '代数', position: 'insideBottom', dy: 20, fill: '#A0AEC0' }} 
            />
          <YAxis 
            stroke="#A0AEC0" /* gray-400 */
            tickFormatter={(tick) => tick.toFixed(4)}
            domain={['auto', 'auto']}
            label={{ value: '适应度', angle: -90, position: 'insideLeft', dx: -10, fill: '#A0AEC0' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{ bottom: 0 }} 
            formatter={(value, entry, index) => {
              if (value === "bestFitness") return "最佳适应度";
              if (value === "averageFitness") return "平均适应度";
              return value;
            }} 
            payload={[
                { value: '最佳适应度', type: 'line', id: 'bestFitness', color: '#38BDF8' }, // sky-400
                { value: '平均适应度', type: 'line', id: 'averageFitness', color: '#34D399' } // emerald-400
            ]}
          />
          <Line type="monotone" dataKey="bestFitness" stroke="#38BDF8" strokeWidth={2} dot={{ r: 2 }} activeDot={{ r: 5 }} name="最佳适应度" />
          <Line type="monotone" dataKey="averageFitness" stroke="#34D399" strokeWidth={2} dot={{ r: 2 }} activeDot={{ r: 5 }} name="平均适应度" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default FitnessChart;
