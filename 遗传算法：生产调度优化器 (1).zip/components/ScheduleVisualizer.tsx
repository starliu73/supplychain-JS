
import React from 'react';
import { Schedule, Machine, Product } from '../types';
import { SCHEDULE_COLORS } from '../constants';
import { InfoIcon } from './IconComponents';

interface ScheduleVisualizerProps {
  schedule: Schedule | null;
  machines: Machine[];
  products: Product[]; // Needed for product names if not in schedule tasks
}

const ScheduleVisualizer: React.FC<ScheduleVisualizerProps> = ({ schedule, machines, products }) => {
  if (!schedule || schedule.tasks.length === 0) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg shadow-xl flex flex-col items-center justify-center h-full min-h-[300px]">
        <InfoIcon className="w-12 h-12 text-sky-500 mb-4" />
        <p className="text-gray-400 text-lg">没有排程可显示。</p>
        <p className="text-gray-500 text-sm">运行模拟以生成排程。</p>
      </div>
    );
  }

  const { tasks, makespan } = schedule;
  const productMap = new Map(products.map(p => [p.id, p]));

  // Determine the scale for the timeline
  const timeScaleFactor = makespan > 0 ? 500 / makespan : 1; // 500px wide timeline roughly

  return (
    <div className="bg-gray-800 p-4 md:p-6 rounded-lg shadow-xl overflow-x-auto">
      <h3 className="text-lg font-semibold text-sky-400 mb-1">找到的最佳排程</h3>
      <p className="text-sm text-gray-400 mb-4">完工时间: <span className="font-bold text-sky-300">{makespan.toFixed(2)}</span> 时间单位</p>
      
      <div className="space-y-3">
        {machines.map((machine) => {
          const machineTasks = tasks.filter(task => task.machineId === machine.id);
          return (
            <div key={machine.id} className="mb-2">
              <h4 className="text-sm font-medium text-gray-300 mb-1">{machine.name}</h4>
              <div className="relative h-10 bg-gray-700 rounded overflow-hidden w-full min-w-[500px]"> {/* min-w to ensure timeline is usable */}
                {machineTasks.map((task, index) => {
                  const product = productMap.get(task.productId);
                  const colorIndex = products.findIndex(p => p.id === task.productId) % SCHEDULE_COLORS.length;
                  const taskColor = SCHEDULE_COLORS[colorIndex] || 'bg-gray-500';
                  
                  return (
                    <div
                      key={`${task.productId}-${task.startTime}-${index}`}
                      className={`absolute h-full ${taskColor} flex items-center justify-center text-xs text-white font-medium transition-all duration-300 ease-in-out`}
                      style={{
                        left: `${task.startTime * timeScaleFactor}px`,
                        width: `${task.duration * timeScaleFactor}px`,
                      }}
                      title={`${product?.name || task.productId} 在 ${machine.name}上\n开始: ${task.startTime.toFixed(1)}, 结束: ${task.endTime.toFixed(1)}, 持续时间: ${task.duration.toFixed(1)}`}
                    >
                      <span className="truncate px-1">{product?.name || task.productId}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      {makespan > 0 && (
         <div className="mt-4 w-full min-w-[500px]">
            <div className="relative h-4 bg-gray-700 rounded">
                {[...Array(Math.ceil(makespan / (makespan > 20 ? 5 : 1)) +1)].map((_, i) => {
                    const timeMark = i * (makespan > 20 ? 5 : 1);
                    if (timeMark > makespan && i !== Math.ceil(makespan / (makespan > 20 ? 5 : 1))) return null; // don't draw too far past makespan
                    const finalMark = Math.min(timeMark, makespan);
                    return (
                        <div key={`tick-${i}`} className="absolute top-0 h-full flex flex-col items-center" style={{ left: `${finalMark * timeScaleFactor}px`}}>
                            <div className="w-px h-2 bg-gray-400"></div>
                            <span className="text-xs text-gray-400 -mt-0.5">{finalMark.toFixed(0)}</span>
                        </div>
                    );
                })}
            </div>
        </div>
      )}
    </div>
  );
};

export default ScheduleVisualizer;
