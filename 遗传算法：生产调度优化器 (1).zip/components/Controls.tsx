
import React from 'react';
import { GAParameters } from '../types';
import { PlayIcon, PauseIcon, StopIcon, RefreshIcon } from './IconComponents';

interface ControlsProps {
  gaParams: GAParameters;
  onParamChange: <K extends keyof GAParameters>(key: K, value: GAParameters[K]) => void;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
  isRunning: boolean;
  isPaused: boolean;
  canStart: boolean;
  canPause: boolean;
  canReset: boolean;
}

const InputField: React.FC<{label: string, id: string, type: string, value: number, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, min?: number, step?: number, helpText?: string}> = 
  ({label, id, type, value, onChange, min, step, helpText}) => (
  <div className="flex-1 min-w-[150px]">
    <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">{label}</label>
    <input
      type={type}
      id={id}
      name={id}
      value={value}
      onChange={onChange}
      min={min}
      step={step}
      className="w-full bg-gray-700 border border-gray-600 text-gray-100 rounded-md shadow-sm p-2 focus:ring-sky-500 focus:border-sky-500"
    />
    {helpText && <p className="mt-1 text-xs text-gray-400">{helpText}</p>}
  </div>
);


const Controls: React.FC<ControlsProps> = ({
  gaParams,
  onParamChange,
  onStart,
  onPause,
  onReset,
  isRunning,
  isPaused,
  canStart,
  canPause,
  canReset,
}) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onParamChange(name as keyof GAParameters, parseInt(value, 10));
  };

  const handleFloatInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onParamChange(name as keyof GAParameters, parseFloat(value));
  };

  return (
    <div className="bg-gray-800 p-4 md:p-6 rounded-lg shadow-xl mb-6">
      <h2 className="text-xl font-semibold text-sky-400 mb-4">遗传算法参数与控制</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <InputField label="种群规模" id="populationSize" type="number" value={gaParams.populationSize} onChange={handleInputChange} min={10} step={10} helpText="每代个体数量。" />
        <InputField label="迭代代数" id="numGenerations" type="number" value={gaParams.numGenerations} onChange={handleInputChange} min={10} step={10} helpText="进化总迭代次数。" />
        <InputField label="锦标赛规模" id="tournamentSize" type="number" value={gaParams.tournamentSize} onChange={handleInputChange} min={2} step={1} helpText="选择锦标赛中的个体数量。" />
        <div>
          <label htmlFor="crossoverRate" className="block text-sm font-medium text-gray-300 mb-1">交叉率</label>
          <input type="range" id="crossoverRate" name="crossoverRate" min="0" max="1" step="0.01" value={gaParams.crossoverRate} onChange={handleFloatInputChange} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-sky-500" />
          <div className="text-xs text-gray-400 mt-1">交叉概率: {gaParams.crossoverRate.toFixed(2)}</div>
        </div>
        <div>
          <label htmlFor="mutationRate" className="block text-sm font-medium text-gray-300 mb-1">变异率</label>
          <input type="range" id="mutationRate" name="mutationRate" min="0" max="1" step="0.01" value={gaParams.mutationRate} onChange={handleFloatInputChange} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-sky-500" />
          <div className="text-xs text-gray-400 mt-1">变异概率: {gaParams.mutationRate.toFixed(2)}</div>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-3 items-center">
        <button
          onClick={onStart}
          disabled={!canStart}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-500 text-white font-semibold py-2 px-4 rounded-md shadow transition-colors duration-150"
        >
          {isRunning && !isPaused ? <PauseIcon /> : <PlayIcon />}
          {isRunning && !isPaused ? '暂停' : (isPaused ? '继续' : '开始')}
        </button>
        <button
          onClick={onReset}
          disabled={!canReset}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-500 text-white font-semibold py-2 px-4 rounded-md shadow transition-colors duration-150"
        >
          <RefreshIcon />
          重置
        </button>
      </div>
    </div>
  );
};

export default Controls;
