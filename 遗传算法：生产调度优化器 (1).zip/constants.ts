
import { Product, Machine, GAParameters } from './types';

export const DEFAULT_GA_PARAMETERS: GAParameters = {
  populationSize: 50,
  numGenerations: 100,
  mutationRate: 0.05,
  crossoverRate: 0.8,
  tournamentSize: 5,
};

export const SAMPLE_PRODUCTS: Product[] = [
  { id: 'P1', name: '产品 Alpha', processingTime: 5 },
  { id: 'P2', name: '产品 Beta', processingTime: 3 },
  { id: 'P3', name: '产品 Gamma', processingTime: 7 },
  { id: 'P4', name: '产品 Delta', processingTime: 4 },
  { id: 'P5', name: '产品 Epsilon', processingTime: 6 },
];

export const SAMPLE_MACHINES: Machine[] = [
  { id: 'M1', name: '机器 1' },
  { id: 'M2', name: '机器 2' },
  // { id: 'M3', name: '机器 3' }, // 为增加复杂性可添加更多机器
];

// Colors for visualization, ensuring good contrast
export const SCHEDULE_COLORS: string[] = [
  'bg-sky-500', 'bg-emerald-500', 'bg-amber-500', 'bg-rose-500', 'bg-indigo-500',
  'bg-teal-500', 'bg-yellow-500', 'bg-pink-500', 'bg-purple-500', 'bg-lime-500'
];
