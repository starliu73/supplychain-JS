
import { GoogleGenAI } from "@google/genai";

// This service is a placeholder and not actively used in the GA core logic.
// It's included to demonstrate structure if Gemini API features were to be added.

let ai: GoogleGenAI | null = null;

const getGenAI = (): GoogleGenAI => {
  if (!ai) {
    if (!process.env.API_KEY) {
      // In a real app, you might want to handle this more gracefully,
      // but per instructions, we assume API_KEY is set.
      // For this placeholder, we'll just log an error if it's called without a key.
      // NOTE: This app does not use Gemini features, so process.env.API_KEY is not strictly required for it to run.
      // If you were to implement features using Gemini, ensure API_KEY is available.
      console.warn("API_KEY environment variable is not set. Gemini features will not be available.");
      // To prevent crashes if called, we'll throw an error or return a mock/stub.
      // For this template, let's assume it would throw if API key is essential.
      // However, since this service is not critical to the GA app, we can be more lenient.
      // To satisfy the "must use process.env.API_KEY" constraint for initialization if it *were* used:
      // throw new Error("API_KEY environment variable is not set.");
      // For now, as it's a placeholder, we'll let it be.
      // A more robust placeholder might return a mock that indicates Gemini is unavailable.
      // For the strict requirement of using process.env.API_KEY if called:
      if (typeof process.env.API_KEY !== 'string' || process.env.API_KEY === '') {
          throw new Error("API_KEY environment variable is not set or empty.");
      }
      ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
  }
  return ai;
};

// Example function (not used by the GA, requires API_KEY to be set in environment)
export const getSimpleExplanation = async (topic: string): Promise<string> => {
  try {
    const genAIClient = getGenAI(); // This will throw if API_KEY is not set per above logic.
    const response = await genAIClient.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", // Ensure this model is appropriate
      contents: `Explain ${topic} in simple terms for a general audience.`,
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching explanation from Gemini:", error);
    if (error instanceof Error && error.message.includes("API_KEY")) {
        return "Could not fetch explanation: API Key for Gemini is not configured.";
    }
    return "Could not fetch explanation at this time.";
  }
};

export default getGenAI; // Export the getter for potential use elsewhere
    