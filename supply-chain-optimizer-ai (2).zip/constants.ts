
import { OptimizationGoal } from './types';

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

export const OPTIMIZATION_GOALS: OptimizationGoal[] = [
  { id: 'cost_reduction', label: 'Cost Reduction' },
  { id: 'lead_time_reduction', label: 'Lead Time Reduction' },
  { id: 'inventory_optimization', label: 'Inventory Optimization' },
  { id: 'risk_mitigation', label: 'Risk Mitigation' },
  { id: 'sustainability_improvement', label: 'Sustainability Improvement' },
  { id: 'enhanced_visibility', label: 'Enhanced Visibility & Tracking' },
  { id: 'demand_forecasting', label: 'Improve Demand Forecasting Accuracy' },
  { id: 'supplier_relationship', label: 'Strengthen Supplier Relationships' },
];
    