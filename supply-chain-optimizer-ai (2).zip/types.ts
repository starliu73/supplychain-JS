
export interface SupplyChainFormData {
  description: string;
  goals: string[];
  constraints: string;
}

export interface OptimizationGoal {
  id: string;
  label: string;
}
    