
import React, { useState, useCallback } from 'react';
import SupplyChainInputForm from './components/SupplyChainInputForm';
import OptimizationResults from './components/OptimizationResults';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import { getOptimizationSuggestions } from './services/geminiService';
import { SupplyChainFormData } from './types';

const App: React.FC = () => {
  const [suggestions, setSuggestions] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (formData: SupplyChainFormData) => {
    setIsLoading(true);
    setError(null);
    setSuggestions(null);

    try {
      const result = await getOptimizationSuggestions(formData);
      setSuggestions(result);
    } catch (err: any) {
      setError(err instanceof Error ? err.message : String(err));
      console.error("Submission error:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <header className="text-center mb-10">
          <h1 className="text-4xl font-extrabold text-primary-700 sm:text-5xl">
            Supply Chain Optimizer <span className="text-gray-900">AI</span>
          </h1>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Leverage AI to analyze your supply chain, identify bottlenecks, and discover actionable optimization strategies.
          </p>
        </header>

        <main>
          <SupplyChainInputForm onSubmit={handleSubmit} isLoading={isLoading} />
          
          {isLoading && (
            <div className="mt-8 flex justify-center">
              <LoadingSpinner />
            </div>
          )}

          <ErrorMessage message={error || ''} />

          {suggestions && !isLoading && (
            <OptimizationResults suggestions={suggestions} />
          )}

          {!isLoading && !suggestions && !error && (
            <div className="mt-8 bg-white p-8 rounded-lg shadow-lg text-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-primary-300 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 9h.01M15 9h.01M10 12h.01M14 12h.01M9 15h.01M15 15h.01" />
              </svg>
              <h3 className="text-xl font-semibold text-gray-700">Ready for Insights?</h3>
              <p className="text-gray-500 mt-2">
                Fill out the form above to receive AI-powered recommendations for optimizing your supply chain.
              </p>
            </div>
          )}
        </main>

        <footer className="text-center mt-12 py-6 border-t border-gray-300">
          <p className="text-sm text-gray-500">
            Powered by Gemini API. For illustrative purposes only.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default App;
    