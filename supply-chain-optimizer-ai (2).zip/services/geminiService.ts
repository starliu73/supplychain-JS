
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SupplyChainFormData } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

// Ensure API_KEY is available in the environment.
// In a real deployed app, this would be set in the environment variables.
// For local development, you might use a .env file with a bundler like Vite or Webpack.
// For this environment, we assume `process.env.API_KEY` is directly available.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY for Gemini is not set. Please set the process.env.API_KEY environment variable.");
  // Potentially throw an error or handle this state in the UI,
  // but per instructions, we assume it's pre-configured.
}

const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Use non-null assertion as we assume it's set.

export const getOptimizationSuggestions = async (
  formData: SupplyChainFormData
): Promise<string> => {
  if (!API_KEY) {
    return Promise.reject("API Key for Gemini is not configured. Please contact support or check environment variables.");
  }
  
  const goalsText = formData.goals.length > 0 ? formData.goals.join(', ') : 'General improvement';

  const prompt = `
You are an expert supply chain optimization consultant with deep knowledge of modern strategies and technologies, including AI-driven approaches and transformer models for supply chain analysis.

A company has provided the following information about their supply chain:

**Current Situation & Challenges:**
${formData.description}

**Primary Optimization Goals:**
${goalsText}

**Key Constraints or Specific Considerations:**
${formData.constraints || 'None specified.'}

Based on this information, please provide comprehensive, actionable, and innovative recommendations to optimize their supply chain. Structure your response clearly with headings and bullet points for readability. Consider the following aspects in your analysis:

1.  **Process Improvements:** Identify bottlenecks and suggest streamlined workflows.
2.  **Technology Adoption:** Recommend relevant technologies (e.g., IoT, AI/ML, blockchain, automation) and how they can be applied. Explain how "transformer models" or similar advanced AI could be specifically leveraged for tasks like demand forecasting, risk assessment, or logistics optimization.
3.  **Cost Reduction Strategies:** Pinpoint areas for cost savings without compromising quality or resilience.
4.  **Efficiency Gains:** Suggest ways to improve speed, reduce waste, and enhance resource utilization.
5.  **Risk Management:** Propose strategies to mitigate potential disruptions and build a more resilient supply chain.
6.  **Sustainability:** If relevant to their goals, suggest eco-friendly practices.
7.  **Data Analytics & Visibility:** How can they better leverage data for decision-making?

Offer specific, practical steps the company can take. If the input is too vague in certain areas, politely note this and provide advice based on common scenarios related to the stated goals, while also suggesting what additional information would be helpful.
Your response should be detailed and insightful, aiming to provide significant value.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        // Omitting thinkingConfig to use default (enabled thinking for higher quality)
        temperature: 0.7, // Balance creativity and factualness
        topK: 40,
        topP: 0.95,
      }
    });
    return response.text;
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            return Promise.reject('The configured API Key for Gemini is invalid. Please check your API key.');
        }
         return Promise.reject(`Failed to get suggestions from AI: ${error.message}`);
    }
    return Promise.reject('An unknown error occurred while contacting the AI service.');
  }
};
    