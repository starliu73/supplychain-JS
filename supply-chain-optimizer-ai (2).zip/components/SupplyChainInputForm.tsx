
import React, { useState } from 'react';
import { SupplyChainFormData, OptimizationGoal } from '../types';
import { OPTIMIZATION_GOALS } from '../constants';

interface SupplyChainInputFormProps {
  onSubmit: (data: SupplyChainFormData) => void;
  isLoading: boolean;
}

const SupplyChainInputForm: React.FC<SupplyChainInputFormProps> = ({ onSubmit, isLoading }) => {
  const [description, setDescription] = useState<string>('');
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [constraints, setConstraints] = useState<string>('');

  const handleGoalChange = (goalId: string) => {
    setSelectedGoals(prevGoals =>
      prevGoals.includes(goalId)
        ? prevGoals.filter(g => g !== goalId)
        : [...prevGoals, goalId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const goalsAsLabels = selectedGoals.map(id => OPTIMIZATION_GOALS.find(g => g.id === id)?.label || id);
    onSubmit({ description, goals: goalsAsLabels, constraints });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-lg shadow-lg">
      <div>
        <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
          Current Supply Chain Description & Challenges
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={6}
          className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
          placeholder="Describe your current supply chain, including its structure, key processes, known issues, pain points, or specific areas you want to improve (e.g., 'High logistics costs in last-mile delivery', 'Poor inventory turnover for product line X')."
          required
        />
      </div>

      <div>
        <span className="block text-sm font-medium text-gray-700 mb-2">Optimization Goals</span>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {OPTIMIZATION_GOALS.map((goal: OptimizationGoal) => (
            <label key={goal.id} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-md hover:bg-primary-50 transition-colors cursor-pointer">
              <input
                type="checkbox"
                checked={selectedGoals.includes(goal.id)}
                onChange={() => handleGoalChange(goal.id)}
                className="h-5 w-5 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
              />
              <span className="text-sm text-gray-700">{goal.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label htmlFor="constraints" className="block text-sm font-medium text-gray-700 mb-1">
          Key Constraints or Specific Considerations
        </label>
        <textarea
          id="constraints"
          value={constraints}
          onChange={(e) => setConstraints(e.target.value)}
          rows={3}
          className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
          placeholder="List any budget limitations, regulatory requirements, existing technology stack, contractual obligations, or other specific factors the AI should consider (e.g., 'Budget for new tech is $50k', 'Must comply with GDPR', 'Currently using SAP ERP')."
        />
      </div>

      <div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? 'Analyzing...' : 'Get Optimization Suggestions'}
        </button>
      </div>
    </form>
  );
};

export default SupplyChainInputForm;
    