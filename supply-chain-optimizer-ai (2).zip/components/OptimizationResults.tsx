
import React from 'react';

interface OptimizationResultsProps {
  suggestions: string | null;
}

const OptimizationResults: React.FC<OptimizationResultsProps> = ({ suggestions }) => {
  if (!suggestions) {
    return null;
  }

  // Basic markdown-like rendering for headings and lists
  const renderFormattedText = (text: string) => {
    return text.split('\n').map((line, index) => {
      if (line.startsWith('**') && line.endsWith('**')) {
        return <h3 key={index} className="text-xl font-semibold text-primary-700 mt-4 mb-2">{line.substring(2, line.length - 2)}</h3>;
      }
      if (line.startsWith('* ') || line.startsWith('- ')) {
        return <li key={index} className="ml-6 list-disc text-gray-700">{line.substring(2)}</li>;
      }
      if (line.startsWith('1. ') || line.startsWith('2. ') || line.startsWith('3. ') || line.startsWith('4. ') || line.startsWith('5. ') || line.startsWith('6. ') || line.startsWith('7. ') || line.startsWith('8. ') || line.startsWith('9. ')) {
         // This is a simple check, could be more robust for nested lists or complex markdown
        return <li key={index} className="ml-6 list-decimal text-gray-700">{line.substring(line.indexOf(' ') + 1)}</li>;
      }
      if (line.trim() === '') {
        return <br key={index} />;
      }
      return <p key={index} className="text-gray-700 leading-relaxed">{line}</p>;
    });
  };


  return (
    <div className="mt-8 bg-white p-8 rounded-lg shadow-lg">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6 border-b pb-3">AI-Powered Optimization Suggestions</h2>
      <div className="prose prose-sm sm:prose lg:prose-lg xl:prose-xl max-w-none space-y-3">
        {renderFormattedText(suggestions)}
      </div>
    </div>
  );
};

export default OptimizationResults;
    