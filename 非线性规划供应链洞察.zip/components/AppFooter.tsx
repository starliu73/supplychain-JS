
import React from 'react';

const AppFooter: React.FC = () => {
  return (
    <footer className="py-10 mt-16 border-t border-slate-300 bg-slate-200">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm text-slate-600">
          © {new Date().getFullYear()} 供应链洞察. 保留所有权利.
        </p>
        <p className="text-xs text-slate-500 mt-1">
          本内容仅供学习和参考。
        </p>
      </div>
    </footer>
  );
};

export default AppFooter;
