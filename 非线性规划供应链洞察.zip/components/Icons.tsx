
import React from 'react';

interface IconProps {
  className?: string;
}

export const DefinitionIcon: React.FC<IconProps> = ({ className }) => (
  <svg aria-hidden="true" className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 15.75s3.75-5.25 9-5.25 9 5.25 9 5.25m-9-5.25v5.25m0 0v2.25m0-2.25H12m0 0H9.75M12 18.75v2.25m0 0H9.75M12 21h2.25M12 3.75h.008v.008H12V3.75zm1.5 0h.008v.008H13.5V3.75zm1.5 0h.008v.008H15V3.75z" />
  </svg>
);

export const ComplexityIcon: React.FC<IconProps> = ({ className }) => (
  <svg aria-hidden="true" className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L18 14.25l-.25-2.25a3.375 3.375 0 00-2.455-2.455L13 9.25l2.25-.25a3.375 3.375 0 002.455-2.455L18 4.25l.25 2.25a3.375 3.375 0 002.455 2.455L22.75 9.25l-2.25.25a3.375 3.375 0 00-2.455 2.455zM12 12l.354-.354m-.708 0L12 12z" />
  </svg>
);

export const ApplicationIcon: React.FC<IconProps> = ({ className }) => (
  <svg aria-hidden="true" className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" />
  </svg>
);

export const GoalIcon: React.FC<IconProps> = ({ className }) => (
  <svg aria-hidden="true" className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
  </svg>
);

export const AlgorithmIcon: React.FC<IconProps> = ({ className }) => (
  <svg aria-hidden="true" className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5h10.5M6.75 12h10.5m-10.5 4.5h10.5M5.25 6.75V5.25a2.25 2.25 0 012.25-2.25h9a2.25 2.25 0 012.25 2.25v13.5a2.25 2.25 0 01-2.25 2.25h-9a2.25 2.25 0 01-2.25-2.25V17.25m0 0V6.75m0 10.5V6.75" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5zM10.5 18a2.25 2.25 0 100 4.5 2.25 2.25 0 000-4.5z" />
 </svg>
);
