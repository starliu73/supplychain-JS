
import React from 'react';
import type { Page } from '../App'; // Ensure this path is correct

interface AppHeaderProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
}

const AppHeader: React.FC<AppHeaderProps> = ({ currentPage, setCurrentPage }) => {
  const navItems = [
    { id: 'main', label: '概览' },
    { id: 'pricingInventory', label: '定价与库存算法' },
  ];

  return (
    <header className="bg-gradient-to-r from-sky-700 via-sky-600 to-cyan-600 text-white shadow-xl sticky top-0 z-50">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row justify-between items-center">
          <div className="text-center sm:text-left mb-4 sm:mb-0">
            <h1 className="text-3xl lg:text-4xl font-extrabold tracking-tight">非线性规划供应链洞察</h1>
            <p className="mt-1 text-sm lg:text-base opacity-90 max-w-md">探索复杂决策中的最优解，驱动供应链效能</p>
          </div>
          <nav className="flex space-x-2 sm:space-x-3" aria-label="主要导航">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id as Page)}
                aria-current={currentPage === item.id ? 'page' : undefined}
                className={`px-3 py-2 sm:px-4 sm:py-2.5 rounded-md text-sm font-medium transition-colors duration-150 ease-in-out
                  ${currentPage === item.id
                    ? 'bg-white text-sky-700 shadow-md'
                    : 'text-sky-100 hover:bg-sky-500 hover:text-white'
                  }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
