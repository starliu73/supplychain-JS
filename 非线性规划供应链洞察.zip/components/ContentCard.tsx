
import React from 'react';

interface ContentCardProps {
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

const ContentCard: React.FC<ContentCardProps> = ({ title, icon, children, className = '' }) => {
  return (
    <div className={`bg-white shadow-xl rounded-xl p-6 md:p-8 hover:shadow-2xl transition-shadow duration-300 ${className}`}>
      <div className="flex items-start sm:items-center mb-5">
        {icon && <div className="mr-4 flex-shrink-0">{icon}</div>}
        <h2 className="text-2xl md:text-3xl font-bold text-slate-800">{title}</h2>
      </div>
      <div className="text-slate-700 space-y-3 leading-relaxed text-base md:text-lg">
        {children}
      </div>
    </div>
  );
};

export default ContentCard;
