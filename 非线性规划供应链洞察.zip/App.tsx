
import React, { useState } from 'react';
import AppHeader from './components/AppHeader';
import ContentCard from './components/ContentCard';
import { DefinitionIcon, ComplexityIcon, ApplicationIcon, GoalIcon } from './components/Icons';
import AppFooter from './components/AppFooter';
import PricingInventoryPage from './components/PricingInventoryPage';

export type Page = 'main' | 'pricingInventory';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('main');

  const MainContent: React.FC = () => (
    <>
      <div className="text-center mb-12">
        <img
          src="https://picsum.photos/seed/optimization/1000/250"
          alt="供应链优化概念图"
          className="w-full max-w-4xl mx-auto h-auto object-cover rounded-xl shadow-2xl"
          aria-label="Conceptual image of supply chain optimization"
        />
      </div>

      <div className="max-w-3xl mx-auto mb-12 bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold text-slate-800 mb-3">引言</h2>
        <p className="text-slate-700 leading-relaxed">
          非线性规划是运筹学中的一个重要分支，它为解决目标函数或约束条件包含非线性函数的优化问题提供了数学工具。在现代复杂且动态的供应链管理中，非线性规划因其能够更真实地反映市场需求、成本结构和运营约束而扮演着越来越关键的角色。本应用将简要介绍非线性规划的基本概念、其在供应链，特别是在定价和库存决策方面的应用，以及它如何帮助企业实现利润最大化。
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <ContentCard
          title="什么是非线性规划？"
          icon={<DefinitionIcon className="w-10 h-10 text-sky-600" />}
        >
          <p>非线性规划 (Non-Linear Programming, NLP) 是一种数学优化技术，其目标函数或约束条件中至少包含一个非线性关系。这意味着变量之间的关系不是简单的直线或平面，而是曲线或曲面。</p>
          <p>与线性规划相比，非线性规划能够更准确地模拟现实世界中复杂的、非线性的系统。例如，需求曲线、成本函数等在实际中往往呈现非线性特征。</p>
        </ContentCard>

        <ContentCard
          title="求解的复杂性"
          icon={<ComplexityIcon className="w-10 h-10 text-sky-600" />}
        >
          <p>求解非线性规划问题通常比线性规划问题更为复杂。主要挑战包括：</p>
          <ul className="list-disc list-inside space-y-1 mt-2">
            <li><strong>局部最优与全局最优：</strong> 非线性问题可能存在多个局部最优点，找到全局最优解是一个难题。</li>
            <li><strong>算法多样性：</strong> 没有一种通用的算法能有效解决所有类型的NLP问题，需要针对具体问题特性选择或设计算法。</li>
            <li><strong>计算资源：</strong> 复杂的NLP问题可能需要大量的计算时间和高级计算资源。</li>
          </ul>
        </ContentCard>

        <ContentCard
          title="在供应链中的应用"
          icon={<ApplicationIcon className="w-10 h-10 text-sky-600" />}
          className="md:col-span-2"
        >
          <p>非线性规划在解决复杂的供应链问题方面展现出强大的能力，尤其是在需要精细调整和优化的决策场景中。一个典型的应用是：</p>
          <p className="font-semibold mt-2">定价与库存联合决策：</p>
          <p>在供应链网络中，产品的价格会影响需求量，而需求量又会影响库存水平。这些关系往往是非线性的。非线性规划可以帮助企业同时优化定价策略和库存管理，以应对市场变化。例如：</p>
          <ul className="list-disc list-inside space-y-1 mt-2">
            <li>需求可能随价格下降而非线性增加（初期降价效果明显，后期趋缓）。</li>
            <li>库存成本随库存量增加而非线性增长（如仓储空间限制、资金占用成本、管理复杂度增加）。</li>
            <li>生产成本可能由于规模效应或资源限制而呈现非线性。</li>
          </ul>
        </ContentCard>

        <ContentCard
          title="核心目标"
          icon={<GoalIcon className="w-10 h-10 text-sky-600" />}
          className="md:col-span-2"
        >
          <p>应用非线性规划于供应链决策的核心目标是：</p>
          <ul className="list-disc list-inside space-y-1 mt-2">
            <li><strong>确定最优价格：</strong> 找到能最大化收入或利润的价格点，同时考虑需求弹性、竞争对手行为等非线性因素。</li>
            <li><strong>优化库存水平：</strong> 在满足客户需求的前提下，平衡库存持有成本、订货成本、缺货成本，确定使总成本最小或服务水平最优的库存量。</li>
            <li><strong>最大化整体利润：</strong> 最终目标是为供应链中的各个成员（生产商、分销商、零售商等）创造最大的综合利润，或达成某种帕累托最优状态。</li>
          </ul>
          <p className="mt-2">通过精确建模这些非线性关系，企业可以做出更明智、更接近实际情况的决策。</p>
        </ContentCard>
      </div>
      <div className="max-w-3xl mx-auto mt-12 bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold text-slate-800 mb-3">总结</h2>
        <p className="text-slate-700 leading-relaxed">
          总而言之，非线性规划为处理供应链中固有的复杂性和非线性动态提供了一个强大的框架。它使得企业能够超越简化的线性假设，更精确地捕捉现实世界的细微差别，从而在定价、库存管理、网络设计等关键领域做出更明智、更优化的决策，最终提升整体运营效率和盈利能力。
        </p>
      </div>
    </>
  );

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <AppHeader currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {currentPage === 'main' && <MainContent />}
        {currentPage === 'pricingInventory' && <PricingInventoryPage />}
      </main>
      <AppFooter />
    </div>
  );
};

export default App;
