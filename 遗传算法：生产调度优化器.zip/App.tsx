
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Product, Machine, GAParameters, Population, Individual, FitnessHistoryPoint } from './types';
import { DEFAULT_GA_PARAMETERS, SAMPLE_PRODUCTS, SAMPLE_MACHINES } from './constants';
import * as GAService from './services/gaService';
import Controls from './components/Controls';
import ScheduleVisualizer from './components/ScheduleVisualizer';
import FitnessChart from './components/FitnessChart';
// import { getSimpleExplanation } from './services/geminiService'; // Example, not used in core GA

const App: React.FC = () => {
  const [gaParams, setGaParams] = useState<GAParameters>(DEFAULT_GA_PARAMETERS);
  const [products]  = useState<Product[]>(SAMPLE_PRODUCTS); // Could make these configurable later
  const [machines] = useState<Machine[]>(SAMPLE_MACHINES); // Could make these configurable later

  const [population, setPopulation] = useState<Population>([]);
  const [currentGeneration, setCurrentGeneration] = useState<number>(0);
  const [bestIndividualOverall, setBestIndividualOverall] = useState<Individual | null>(null);
  const [fitnessHistory, setFitnessHistory] = useState<FitnessHistoryPoint[]>([]);
  
  const [simulationStatus, setSimulationStatus] = useState<'idle' | 'running' | 'paused' | 'completed'>('idle');

  const simulationTimeoutRef = useRef<number | null>(null);

  const resetSimulation = useCallback(() => {
    if (simulationTimeoutRef.current) {
      clearTimeout(simulationTimeoutRef.current);
      simulationTimeoutRef.current = null;
    }
    const initialPopulation = GAService.initializePopulation(products, gaParams.populationSize);
    const evaluatedPopulation = GAService.evaluatePopulation(initialPopulation, products, machines);
    
    setPopulation(evaluatedPopulation);
    setCurrentGeneration(0);
    setFitnessHistory([]);
    
    const bestInitial = evaluatedPopulation.reduce((best, curr) => (curr.fitness > best.fitness ? curr : best), evaluatedPopulation[0] || null);
    setBestIndividualOverall(bestInitial);
    
    setSimulationStatus('idle');
  }, [products, machines, gaParams.populationSize]);

  // Initialize on mount or when products/machines/params change in a way that requires reset
  useEffect(() => {
    resetSimulation();
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gaParams.populationSize]); // Only reset if population size changes, other params handled by user starting.


  const runSingleGenerationStep = useCallback(() => {
    if (simulationStatus !== 'running' || products.length === 0 || machines.length === 0) return;

    setPopulation(prevPopulation => {
      const newPopulation = GAService.runSingleGeneration(prevPopulation, gaParams, products, machines);
      
      const bestInGeneration = newPopulation.reduce((best, curr) => (curr.fitness > best.fitness ? curr : best), newPopulation[0] || null);
      const averageFitness = newPopulation.reduce((sum, ind) => sum + ind.fitness, 0) / newPopulation.length;

      setFitnessHistory(prevHistory => [...prevHistory, { generation: currentGeneration + 1, bestFitness: bestInGeneration?.fitness || 0, averageFitness }]);
      
      if (bestInGeneration && (!bestIndividualOverall || bestInGeneration.fitness > bestIndividualOverall.fitness)) {
        setBestIndividualOverall(bestInGeneration);
      }
      return newPopulation;
    });

    setCurrentGeneration(prevGen => {
      const nextGen = prevGen + 1;
      if (nextGen >= gaParams.numGenerations) {
        setSimulationStatus('completed');
        return nextGen;
      }
      return nextGen;
    });

  }, [simulationStatus, gaParams, products, machines, currentGeneration, bestIndividualOverall]);


  useEffect(() => {
    if (simulationStatus === 'running' && currentGeneration < gaParams.numGenerations) {
      simulationTimeoutRef.current = window.setTimeout(runSingleGenerationStep, 50); // Delay for UI update
    } else if (simulationStatus === 'completed' || simulationStatus === 'paused' || simulationStatus === 'idle'){
      if(simulationTimeoutRef.current) clearTimeout(simulationTimeoutRef.current);
    }
    return () => {
      if (simulationTimeoutRef.current) clearTimeout(simulationTimeoutRef.current);
    };
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [simulationStatus, currentGeneration, runSingleGenerationStep]); // runSingleGenerationStep is memoized


  const handleParamChange = <K extends keyof GAParameters>(key: K, value: GAParameters[K]) => {
    setGaParams(prev => ({ ...prev, [key]: value }));
    // Reset if critical params change while idle/completed
    if(simulationStatus === 'idle' || simulationStatus === 'completed') {
        if(key === 'populationSize') { // Only for populationSize, other params change take effect on next run
             // This will trigger the useEffect for resetSimulation
        }
    }
  };

  const handleStartPause = () => {
    if (simulationStatus === 'running') {
      setSimulationStatus('paused');
    } else if (simulationStatus === 'paused' || simulationStatus === 'idle' || simulationStatus === 'completed') {
      if (simulationStatus === 'idle' || simulationStatus === 'completed' || currentGeneration >= gaParams.numGenerations) {
        // Reset and start if it was idle, completed, or generations were finished
        resetSimulation(); // This will set status to 'idle'
        setSimulationStatus('running'); // then immediately start
      } else {
        // Resume if paused
        setSimulationStatus('running');
      }
    }
  };

  const handleReset = () => {
    resetSimulation();
  };
  
  // const [explanation, setExplanation] = useState('');
  // const fetchExplanation = async () => {
  //   setExplanation("Loading explanation from Gemini...");
  //   const exp = await getSimpleExplanation("Genetic Algorithms for scheduling");
  //   setExplanation(exp);
  // };
  // useEffect(() => { fetchExplanation(); }, []); // Example of calling Gemini service

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-4 md:p-8">
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold text-sky-400">Genetic Algorithm for Production Scheduling</h1>
        <p className="text-lg text-gray-400 mt-2">Visualizing evolutionary optimization in action.</p>
      </header>

      {/* Optional Gemini Explanation Section - uncomment to use if API_KEY is set
      <div className="my-4 p-4 bg-gray-800 rounded-lg shadow">
        <h2 className="text-xl text-sky-300 mb-2">About This Simulation (via Gemini)</h2>
        <p className="text-sm text-gray-300 whitespace-pre-wrap">{explanation || "Click button to load explanation..."}</p>
        <button onClick={fetchExplanation} className="mt-2 bg-sky-600 hover:bg-sky-700 text-white py-1 px-3 rounded">Reload Explanation</button>
      </div>
      */}

      <Controls
        gaParams={gaParams}
        onParamChange={handleParamChange}
        onStart={handleStartPause}
        onPause={() => setSimulationStatus('paused')} // Not directly used, start/pause is one button
        onReset={handleReset}
        isRunning={simulationStatus === 'running'}
        isPaused={simulationStatus === 'paused'}
        canStart={products.length > 0 && machines.length > 0}
        canPause={simulationStatus === 'running'}
        canReset={simulationStatus !== 'idle' || currentGeneration > 0}
      />

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section>
          <h2 className="text-2xl font-semibold text-sky-400 mb-4">Best Schedule Visualization</h2>
          <ScheduleVisualizer schedule={bestIndividualOverall?.schedule || null} machines={machines} products={products} />
        </section>
        <section>
           <h2 className="text-2xl font-semibold text-sky-400 mb-4">Performance Metrics</h2>
          <div className="bg-gray-800 p-4 rounded-lg shadow-xl mb-6">
            <div className="grid grid-cols-2 gap-4 text-center md:text-left">
              <div>
                <p className="text-sm text-gray-400">Current Generation</p>
                <p className="text-2xl font-bold text-sky-300">{currentGeneration} / {gaParams.numGenerations}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Best Fitness (Overall)</p>
                <p className="text-2xl font-bold text-green-400">{bestIndividualOverall?.fitness.toFixed(6) || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Best Makespan (Overall)</p>
                <p className="text-2xl font-bold text-green-400">{bestIndividualOverall?.schedule?.makespan.toFixed(2) || 'N/A'}</p>
              </div>
               <div>
                <p className="text-sm text-gray-400">Simulation Status</p>
                <p className={`text-xl font-semibold capitalize ${
                    simulationStatus === 'running' ? 'text-green-400' :
                    simulationStatus === 'paused' ? 'text-yellow-400' :
                    simulationStatus === 'completed' ? 'text-sky-400' :
                    'text-gray-400'
                }`}>{simulationStatus}</p>
              </div>
            </div>
          </div>
          <FitnessChart history={fitnessHistory} />
        </section>
      </div>
      
      <footer className="text-center mt-12 py-4 border-t border-gray-700">
        <p className="text-sm text-gray-500">Genetic Algorithm Demo - React & Tailwind CSS</p>
      </footer>
    </div>
  );
};

export default App;
    