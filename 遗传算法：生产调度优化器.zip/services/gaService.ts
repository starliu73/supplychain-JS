
import { Population, Individual, Chromosome, Product, Machine, Schedule, ScheduledTask, GAParameters } from '../types';

// Helper to shuffle an array (Fisher-Yates shuffle)
function shuffleArray<T,>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export const initializePopulation = (products: Product[], populationSize: number): Population => {
  const population: Population = [];
  const productIds = products.map(p => p.id);

  for (let i = 0; i < populationSize; i++) {
    const chromosome = shuffleArray(productIds);
    population.push({ chromosome, fitness: 0 }); // Fitness calculated later
  }
  return population;
};

export const calculateFitnessAndSchedule = (
  chromosome: Chromosome,
  products: Product[],
  machines: Machine[]
): { fitness: number; schedule: Schedule } => {
  if (machines.length === 0 || products.length === 0) {
    return { fitness: 0, schedule: { tasks: [], makespan: 0 } };
  }

  const productMap = new Map(products.map(p => [p.id, p]));
  const machineFreeTime: number[] = new Array(machines.length).fill(0); // Tracks when each machine becomes free
  const scheduledTasks: ScheduledTask[] = [];
  let makespan = 0;

  for (const productId of chromosome) {
    const product = productMap.get(productId);
    if (!product) continue;

    let bestMachineIndex = -1;
    let earliestFinishTime = Infinity;
    let taskStartTime = 0;

    for (let i = 0; i < machines.length; i++) {
      const currentMachineFreeTime = machineFreeTime[i];
      const finishTime = currentMachineFreeTime + product.processingTime;
      if (finishTime < earliestFinishTime) {
        earliestFinishTime = finishTime;
        bestMachineIndex = i;
        taskStartTime = currentMachineFreeTime;
      }
    }
    
    if (bestMachineIndex !== -1) {
        machineFreeTime[bestMachineIndex] = earliestFinishTime;
        scheduledTasks.push({
            productId: product.id,
            productName: product.name,
            machineId: machines[bestMachineIndex].id,
            machineName: machines[bestMachineIndex].name,
            startTime: taskStartTime,
            duration: product.processingTime,
            endTime: earliestFinishTime,
        });
        if (earliestFinishTime > makespan) {
            makespan = earliestFinishTime;
        }
    }
  }

  // Fitness: Higher is better. We want to minimize makespan.
  const fitness = makespan > 0 ? 1 / makespan : 0;
  return { fitness, schedule: { tasks: scheduledTasks, makespan } };
};

export const evaluatePopulation = (population: Population, products: Product[], machines: Machine[]): Population => {
  return population.map(individual => {
    const { fitness, schedule } = calculateFitnessAndSchedule(individual.chromosome, products, machines);
    return { ...individual, fitness, schedule };
  });
};

// Tournament Selection
export const selection = (population: Population, tournamentSize: number): Individual => {
  let bestIndividual: Individual | null = null;
  for (let i = 0; i < tournamentSize; i++) {
    const randomIndex = Math.floor(Math.random() * population.length);
    const randomIndividual = population[randomIndex];
    if (!bestIndividual || randomIndividual.fitness > bestIndividual.fitness) {
      bestIndividual = randomIndividual;
    }
  }
  return bestIndividual!; // Non-null assertion: tournamentSize > 0 and population not empty
};

// Order Crossover (OX1) for permutation-based chromosomes
export const crossover = <T,>(
  parent1Chromosome: T[],
  parent2Chromosome: T[],
  crossoverRate: number
): [T[], T[]] => {
  if (Math.random() > crossoverRate || parent1Chromosome.length <= 1) {
    return [[...parent1Chromosome], [...parent2Chromosome]]; // No crossover
  }

  const size = parent1Chromosome.length;
  let point1 = Math.floor(Math.random() * size);
  let point2 = Math.floor(Math.random() * size);

  if (point1 > point2) [point1, point2] = [point2, point1];
  if (point1 === point2 && size > 1) { // Ensure distinct points if possible
     point2 = (point1 + 1 + Math.floor(Math.random() * (size -1))) % size;
     if (point1 > point2) [point1, point2] = [point2, point1];
  }


  const child1: T[] = new Array(size).fill(null);
  const child2: T[] = new Array(size).fill(null);

  // Copy segment from parent1 to child1, parent2 to child2
  for (let i = point1; i <= point2; i++) {
    child1[i] = parent1Chromosome[i];
    child2[i] = parent2Chromosome[i];
  }

  // Fill remaining for child1 from parent2
  let currentParent2Idx = 0;
  for (let i = 0; i < size; i++) {
    if (child1[i] === null) {
      while (child1.includes(parent2Chromosome[currentParent2Idx])) {
        currentParent2Idx++;
      }
      child1[i] = parent2Chromosome[currentParent2Idx];
    }
  }

  // Fill remaining for child2 from parent1
  let currentParent1Idx = 0;
  for (let i = 0; i < size; i++) {
    if (child2[i] === null) {
      while (child2.includes(parent1Chromosome[currentParent1Idx])) {
        currentParent1Idx++;
      }
      child2[i] = parent1Chromosome[currentParent1Idx];
    }
  }
  return [child1, child2];
};


// Swap Mutation for permutation-based chromosomes
export const mutation = (chromosome: Chromosome, mutationRate: number): Chromosome => {
  const newChromosome = [...chromosome];
  if (Math.random() < mutationRate && newChromosome.length > 1) {
    const idx1 = Math.floor(Math.random() * newChromosome.length);
    let idx2 = Math.floor(Math.random() * newChromosome.length);
    while (idx1 === idx2 && newChromosome.length > 1) { // ensure different indices if possible
        idx2 = Math.floor(Math.random() * newChromosome.length);
    }
    // Swap
    [newChromosome[idx1], newChromosome[idx2]] = [newChromosome[idx2], newChromosome[idx1]];
  }
  return newChromosome;
};

export const runSingleGeneration = (
    currentPopulation: Population,
    gaParams: GAParameters,
    products: Product[],
    machines: Machine[]
): Population => {
    const newPopulation: Population = [];

    // Elitism: carry over the best individual (optional, but often good)
    const sortedPopulation = [...currentPopulation].sort((a, b) => b.fitness - a.fitness);
    if (sortedPopulation.length > 0) {
        newPopulation.push(sortedPopulation[0]);
    }

    while (newPopulation.length < gaParams.populationSize) {
        const parent1 = selection(currentPopulation, gaParams.tournamentSize);
        const parent2 = selection(currentPopulation, gaParams.tournamentSize);

        let [child1Chromosome, child2Chromosome] = crossover(
            parent1.chromosome,
            parent2.chromosome,
            gaParams.crossoverRate
        );

        child1Chromosome = mutation(child1Chromosome, gaParams.mutationRate);
        child2Chromosome = mutation(child2Chromosome, gaParams.mutationRate);
        
        const { fitness: fitness1, schedule: schedule1 } = calculateFitnessAndSchedule(child1Chromosome, products, machines);
        newPopulation.push({ chromosome: child1Chromosome, fitness: fitness1, schedule: schedule1 });

        if (newPopulation.length < gaParams.populationSize) {
            const { fitness: fitness2, schedule: schedule2 } = calculateFitnessAndSchedule(child2Chromosome, products, machines);
            newPopulation.push({ chromosome: child2Chromosome, fitness: fitness2, schedule: schedule2 });
        }
    }
    return newPopulation.slice(0, gaParams.populationSize); // Ensure population size is maintained
};
    