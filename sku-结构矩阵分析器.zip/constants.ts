
import { SKUQuadrant, QuadrantConfig, SKU } from './types';

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';
export const API_KEY_ENV_VAR = 'API_KEY'; // To inform user which env var is used

export const QUADRANT_MIDPOINT = 50;

export const QUADRANT_DEFINITIONS: Record<SKUQuadrant, QuadrantConfig> = {
  [SKUQuadrant.CORE]: {
    label: SKUQuadrant.CORE,
    color: 'bg-quadrant-core',
    textColor: 'text-green-700',
    chartColor: '#10B981',
    description: '高动销率和高利润率。这些是您的明星产品。',
    baseRecommendation: '优先补货，投资战略推广，并保护市场份额。如果适用，考虑扩展产品变体。',
  },
  [SKUQuadrant.FALSE_SALES]: {
    label: SKUQuadrant.FALSE_SALES,
    color: 'bg-quadrant-false-sales',
    textColor: 'text-amber-700',
    chartColor: '#F59E0B',
    description: '高动销率但低利润率。卖得好，但可能对利润贡献不大。',
    baseRecommendation: '分析成本结构。为促销活动设定严格的投资回报率目标。考虑调整价格或与高利润产品捆绑销售。除非对引流至关重要，否则限制投入。',
  },
  [SKUQuadrant.POTENTIAL]: {
    label: SKUQuadrant.POTENTIAL,
    color: 'bg-quadrant-potential',
    textColor: 'text-blue-700',
    chartColor: '#3B82F6',
    description: '低动销率但高利润率。售出时利润可观，但销量不足。',
    baseRecommendation: '提高可见性和客户接触度。使用有针对性的营销，与核心SKU捆绑，或作为追加销售产品。改进产品教育和陈列。',
  },
  [SKUQuadrant.REDUNDANT]: {
    label: SKUQuadrant.REDUNDANT,
    color: 'bg-quadrant-redundant',
    textColor: 'text-red-700',
    chartColor: '#EF4444',
    description: '低动销率和低利润率。这些产品可能正在消耗资源。',
    baseRecommendation: '考虑逐步淘汰。通过清仓促销清算库存。避免进一步补货和投资。分析表现不佳的原因，以避免未来出现类似的SKU。',
  },
  [SKUQuadrant.UNDEFINED]: {
    label: SKUQuadrant.UNDEFINED,
    color: 'bg-quadrant-undefined',
    textColor: 'text-gray-700',
    chartColor: '#9CA3AF',
    description: 'SKU数据不完整或超出了定义的象限边界。',
    baseRecommendation: '检查SKU数据，确保所有指标都已正确输入。如有必要，调整象限边界定义。',
  },
};

export const INITIAL_SKUS: SKU[] = [
  { id: crypto.randomUUID(), name: "优质小部件A", salesVelocity: 75, profitability: 80, salesVolume: 500, quadrant: SKUQuadrant.CORE },
  { id: crypto.randomUUID(), name: "经济小部件B", salesVelocity: 85, profitability: 30, salesVolume: 1200, quadrant: SKUQuadrant.FALSE_SALES },
  { id: crypto.randomUUID(), name: "小众配件C", salesVelocity: 25, profitability: 70, salesVolume: 150, quadrant: SKUQuadrant.POTENTIAL },
  { id: crypto.randomUUID(), name: "旧款配件D", salesVelocity: 15, profitability: 20, salesVolume: 80, quadrant: SKUQuadrant.REDUNDANT },
  { id: crypto.randomUUID(), name: "标准小部件E", salesVelocity: 60, profitability: 65, salesVolume: 700, quadrant: SKUQuadrant.CORE },
];

// Function to derive quadrant, used in App.tsx
export const getSkuQuadrant = (salesVelocity: number, profitability: number): SKUQuadrant => {
  if (salesVelocity > QUADRANT_MIDPOINT && profitability > QUADRANT_MIDPOINT) {
    return SKUQuadrant.CORE;
  } else if (salesVelocity > QUADRANT_MIDPOINT && profitability <= QUADRANT_MIDPOINT) {
    return SKUQuadrant.FALSE_SALES;
  } else if (salesVelocity <= QUADRANT_MIDPOINT && profitability > QUADRANT_MIDPOINT) {
    return SKUQuadrant.POTENTIAL;
  } else if (salesVelocity <= QUADRANT_MIDPOINT && profitability <= QUADRANT_MIDPOINT) {
    return SKUQuadrant.REDUNDANT;
  }
  return SKUQuadrant.UNDEFINED;
};
