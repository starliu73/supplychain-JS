
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SKU } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

let ai: GoogleGenAI | null = null;

const initializeAi = () => {
  if (!ai) {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.error("未找到 API_KEY 环境变量。");
      // 应用将在UI层面处理API密钥缺失的反馈
      return null;
    }
    try {
      ai = new GoogleGenAI({ apiKey });
    } catch (error) {
      console.error("初始化 GoogleGenAI 失败:", error);
      return null;
    }
  }
  return ai;
};


export const getAIInsightForSKU = async (sku: SKU): Promise<string> => {
  const currentAi = initializeAi();
  if (!currentAi) {
    return "错误：Gemini API 客户端无法初始化。请确保 API_KEY 环境变量已正确设置。";
  }

  const prompt = `你是一位战略业务顾问。针对一款名为“${sku.name}”的SKU，该SKU被归类为“${sku.quadrant}”，其销售速度评分为 ${sku.salesVelocity}/100，盈利能力评分为 ${sku.profitability}/100，销量为 ${sku.salesVolume} 单位，请为其在零售业务中的整体产品组合结构角色提供一个简洁、可操作的战略建议。建议应包含2-3个要点。重点关注此特定SKU的市场营销、库存管理或整体策略。请用中文回答。`;

  try {
    const response: GenerateContentResponse = await currentAi.models.generateContent({
        model: GEMINI_MODEL_NAME,
        contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("获取AI洞察时出错:", error);
    if (error instanceof Error) {
        return `获取AI洞察时出错: ${error.message}。请检查控制台以获取详细信息。确保您的API密钥有效并且有权访问 '${GEMINI_MODEL_NAME}' 模型。`;
    }
    return "获取AI洞察时发生未知错误。";
  }
};
