
import React, { useState, useEffect, useCallback } from 'react';
import { SKU, SKUQuadrant } from './types'; // Added SKUQuadrant
import { API_KEY_ENV_VAR, INITIAL_SKUS, QUADRANT_DEFINITIONS, getSkuQuadrant } from './constants';
import SKUInputForm from './components/SKUInputForm';
import SKUMatrixChart from './components/SKUMatrixChart';
import SKUList from './components/SKUList';
import Modal from './components/Modal';
import { getAIInsightForSKU } from './services/geminiService';
import { InfoIcon, LoadingSpinner } from './components/icons';

const App: React.FC = () => {
  const [skus, setSkus] = useState<SKU[]>(() => {
    const savedSkus = localStorage.getItem('skus');
    if (savedSkus) {
      try {
        const parsedSkus = JSON.parse(savedSkus) as SKU[]; // Cast for type safety
        // Ensure quadrant is correctly re-derived for potentially old data structures
        return parsedSkus.map((sku: SKU) => ({...sku, quadrant: getSkuQuadrant(sku.salesVelocity, sku.profitability)}));
      } catch (e) {
        console.error("从本地存储解析SKU时出错", e);
        return INITIAL_SKUS.map(sku => ({...sku, quadrant: getSkuQuadrant(sku.salesVelocity, sku.profitability)}));
      }
    }
    return INITIAL_SKUS.map(sku => ({...sku, quadrant: getSkuQuadrant(sku.salesVelocity, sku.profitability)}));
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSkuForInsight, setSelectedSkuForInsight] = useState<SKU | null>(null);
  const [aiInsight, setAiInsight] = useState('');
  const [isFetchingInsight, setIsFetchingInsight] = useState(false);
  const [apiKeyAvailable, setApiKeyAvailable] = useState(false);
  const [showApiKeyWarning, setShowApiKeyWarning] = useState(true); // Default to true, useEffect will correct

  useEffect(() => {
    if (process.env.API_KEY) {
      setApiKeyAvailable(true);
      setShowApiKeyWarning(false);
    } else {
      setApiKeyAvailable(false);
      setShowApiKeyWarning(true);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('skus', JSON.stringify(skus));
  }, [skus]);

  const addSku = (newSkuData: Omit<SKU, 'id' | 'quadrant'>) => { // Corrected type
    const skuWithIdAndQuadrant: SKU = { 
        ...newSkuData, 
        id: crypto.randomUUID(), 
        quadrant: getSkuQuadrant(newSkuData.salesVelocity, newSkuData.profitability) 
    };
    setSkus(prevSkus => [...prevSkus, skuWithIdAndQuadrant]);
  };

  const deleteSku = (skuId: string) => {
    setSkus(prevSkus => prevSkus.filter(sku => sku.id !== skuId));
  };

  const handleGetAIInsight = useCallback(async (sku: SKU) => {
    if (!apiKeyAvailable) {
      setAiInsight(`无法获取AI洞察：环境变量 ${API_KEY_ENV_VAR} 未设置或无效。请确保其已正确配置。`);
      setSelectedSkuForInsight(sku);
      setIsModalOpen(true);
      return;
    }
    setSelectedSkuForInsight(sku);
    setIsModalOpen(true);
    setIsFetchingInsight(true);
    setAiInsight(''); 
    
    try {
      const insight = await getAIInsightForSKU(sku);
      setAiInsight(insight);
    } catch (error) {
      console.error("handleGetAIInsight 中出错:", error);
      setAiInsight("获取AI洞察时发生错误。请检查控制台以获取更多详细信息。");
    } finally {
      setIsFetchingInsight(false);
    }
  }, [apiKeyAvailable]);

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedSkuForInsight(null);
    setAiInsight('');
  };
  
  const clearAllData = () => {
    if (window.confirm("您确定要清除所有SKU数据吗？此操作无法撤销。")) {
      setSkus([]);
      localStorage.removeItem('skus'); // Also clear from localStorage
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-10 text-center">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-primary-dark tracking-tight">SKU结构矩阵分析器</h1>
          <p className="mt-3 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto">
            分析您产品组合的结构价值，并获取AI驱动的战略洞察。
          </p>
        </header>

        {showApiKeyWarning && (
          <div className="mb-8 bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-md shadow-sm" role="alert">
            <div className="flex">
              <div className="flex-shrink-0">
                <InfoIcon className="h-6 w-6 text-yellow-500" aria-hidden="true" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-yellow-700">Gemini API密钥可能缺失</p>
                <p className="mt-1 text-sm text-yellow-600">
                  环境变量 "{API_KEY_ENV_VAR}" 可能未设置。“获取AI洞察”功能需要此密钥。
                  如果洞察功能无法使用，请参考Gemini API文档进行设置。
                </p>
              </div>
            </div>
          </div>
        )}
        
        <div className="bg-white p-6 sm:p-8 rounded-xl shadow-xl mb-10">
            <SKUInputForm onAddSKU={addSku} />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-6 gap-8 mb-10">
          <div className="xl:col-span-4 bg-white p-6 sm:p-8 rounded-xl shadow-xl">
            <SKUList skus={skus} onDeleteSKU={deleteSku} onGetAIInsight={handleGetAIInsight} isApiKeyAvailable={apiKeyAvailable} />
          </div>
          <div className="xl:col-span-2 bg-white p-6 sm:p-8 rounded-xl shadow-xl">
            <SKUMatrixChart skus={skus} />
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <button
            onClick={clearAllData}
            className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 focus:ring-offset-slate-50 transition-all duration-150 ease-in-out disabled:opacity-60 disabled:cursor-not-allowed"
            disabled={skus.length === 0}
          >
            清除所有SKU数据
          </button>
        </div>

        <Modal isOpen={isModalOpen} onClose={closeModal} title={`针对 ${selectedSkuForInsight?.name || 'SKU'} 的AI洞察`}>
          {isFetchingInsight ? (
            <div className="flex flex-col items-center justify-center py-10">
              <LoadingSpinner className="w-10 h-10 text-primary" />
              <p className="mt-4 text-slate-600 text-lg">正在从 Gemini AI 获取洞察...</p>
            </div>
          ) : (
             <div 
                className="prose prose-sm sm:prose-base max-w-none text-slate-700 leading-relaxed py-2 ai-insight-content"
                // Process newlines and basic list formatting for Gemini output.
                // Replace simple '*' list markers with HTML lists.
                // This is a basic formatter; more complex Markdown might need a dedicated library.
                dangerouslySetInnerHTML={{ __html: aiInsight 
                                            ? aiInsight
                                                .replace(/\n\s*\*\s/g, '<br />* ') // Ensure space after asterisk for list item detection
                                                .replace(/\n/g, '<br />')
                                                .replace(/\* (.*?)(?=<br \/>|$)/g, (match, item) => `<ul class="list-disc pl-5"><li>${item.trim()}</li></ul>`)
                                                .replace(/<\/ul><br \/>\s*<ul class="list-disc pl-5">/g, '') // Merge adjacent list items
                                            : "<p>无可用洞察或发生错误。</p>" 
                                        }}
            />
          )}
        </Modal>

        <footer className="mt-16 pt-8 border-t border-slate-200 text-center text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} SKU分析器。采用 React、Tailwind CSS 和 Google Gemini 构建。</p>
          <p className="mt-1">一个基于动销指数和利润指数可视化SKU表现，以揭示其结构价值的工具。</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
