
export enum SKUQuadrant {
  CORE = "核心SKU (高动销, 高利润)",
  FALSE_SALES = "伪动销SKU (高动销, 低利润)",
  POTENTIAL = "潜力SKU (低动销, 高利润)",
  REDUNDANT = "冗余SKU (低动销, 低利润)",
  UNDEFINED = "未定义",
}

export interface SKU {
  id: string;
  name: string;
  salesVelocity: number; // 0-100
  profitability: number; // 0-100
  salesVolume: number; // For bubble size
  quadrant: SKUQuadrant; // Derived
}

export interface QuadrantConfig {
  label: SKUQuadrant;
  color: string; // Tailwind bg color class e.g. 'bg-green-500'
  textColor: string; // Tailwind text color class e.g. 'text-green-700'
  chartColor: string; // Hex color for chart
  description: string;
  baseRecommendation: string;
}

export interface ChartDataItem extends SKU {
  // Recharts specific fields if necessary, like x, y, z
  x: number; // salesVelocity
  y: number; // profitability
  z: number; // salesVolume
}
