
import React, { useState } from 'react';
import { SKU } from '../types';
// import { getSkuQuadrant } from '../constants'; // Not used in this component directly

interface SKUInputFormProps {
  onAddSKU: (sku: Omit<SKU, 'id' | 'quadrant'>) => void;
}

const SKUInputForm: React.FC<SKUInputFormProps> = ({ onAddSKU }) => {
  const [name, setName] = useState('');
  const [salesVelocity, setSalesVelocity] = useState('');
  const [profitability, setProfitability] = useState('');
  const [salesVolume, setSalesVolume] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const sv = parseFloat(salesVelocity);
    const p = parseFloat(profitability);
    const vol = parseInt(salesVolume, 10);

    if (!name.trim()) {
      setError('SKU 名称是必填项。');
      return;
    }
    if (isNaN(sv) || sv < 0 || sv > 100) {
      setError('动销指数必须是 0 到 100 之间的数字。');
      return;
    }
    if (isNaN(p) || p < 0 || p > 100) {
      setError('利润指数必须是 0 到 100 之间的数字。');
      return;
    }
    if (isNaN(vol) || vol < 0) {
      setError('销量必须是非负整数。');
      return;
    }
    
    onAddSKU({
      name: name.trim(),
      salesVelocity: sv,
      profitability: p,
      salesVolume: vol,
    });

    // Reset form
    setName('');
    setSalesVelocity('');
    setProfitability('');
    setSalesVolume('');
  };

  return (
    <div className="w-full">
      <h2 className="text-2xl font-semibold text-slate-800 mb-6 border-b border-slate-200 pb-3">添加新SKU</h2>
      {error && (
        <div className="bg-red-50 border border-red-300 text-red-700 px-4 py-3 rounded-md mb-6 text-sm" role="alert">
          {error}
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="skuName" className="block text-sm font-medium text-slate-700 mb-1">SKU 名称</label>
          <input
            type="text"
            id="skuName"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-primary focus:border-primary sm:text-sm placeholder-slate-400"
            placeholder="例如：高级小部件 X"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-6">
          <div>
            <label htmlFor="salesVelocity" className="block text-sm font-medium text-slate-700 mb-1">动销指数 (0-100)</label>
            <input
              type="number"
              id="salesVelocity"
              value={salesVelocity}
              onChange={(e) => setSalesVelocity(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-primary focus:border-primary sm:text-sm placeholder-slate-400"
              placeholder="例如：75"
              min="0" max="100" step="0.1"
            />
          </div>
          <div>
            <label htmlFor="profitability" className="block text-sm font-medium text-slate-700 mb-1">利润指数 (0-100)</label>
            <input
              type="number"
              id="profitability"
              value={profitability}
              onChange={(e) => setProfitability(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-primary focus:border-primary sm:text-sm placeholder-slate-400"
              placeholder="例如：80"
              min="0" max="100" step="0.1"
            />
          </div>
          <div>
            <label htmlFor="salesVolume" className="block text-sm font-medium text-slate-700 mb-1">销量 (单位)</label>
            <input
              type="number"
              id="salesVolume"
              value={salesVolume}
              onChange={(e) => setSalesVolume(e.target.value)}
              className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-primary focus:border-primary sm:text-sm placeholder-slate-400"
              placeholder="例如：500"
              min="0" step="1"
            />
          </div>
        </div>
        
        <button
          type="submit"
          className="w-full bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-4 rounded-lg shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary focus:ring-offset-slate-50 transition-all duration-150 ease-in-out"
        >
          添加到SKU矩阵
        </button>
      </form>
    </div>
  );
};

export default SKUInputForm;
