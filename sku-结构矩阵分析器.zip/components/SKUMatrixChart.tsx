
import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, Label, LegendType } from 'recharts';
import { SKU, ChartDataItem, SKUQuadrant } from '../types';
import { QUADRANT_DEFINITIONS, QUADRANT_MIDPOINT } from '../constants';

interface SKUMatrixChartProps {
  skus: SKU[];
}

const CustomTooltipContent: React.FC<any> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload as ChartDataItem;
    const quadrantConfig = QUADRANT_DEFINITIONS[data.quadrant];
    return (
      <div className="bg-white p-3 border border-slate-300 rounded-lg shadow-xl text-sm">
        <p className="font-bold text-slate-800 mb-1">{data.name}</p>
        <p className="text-slate-600">动销指数: <span className="font-medium">{data.salesVelocity.toFixed(1)}</span></p>
        <p className="text-slate-600">利润指数: <span className="font-medium">{data.profitability.toFixed(1)}</span></p>
        <p className="text-slate-600">销量: <span className="font-medium">{data.salesVolume}</span></p>
        <p className="mt-1">象限: <span style={{ color: quadrantConfig.chartColor }} className="font-semibold">{data.quadrant.split('(')[0].trim()}</span></p>
      </div>
    );
  }
  return null;
};


const SKUMatrixChart: React.FC<SKUMatrixChartProps> = ({ skus }) => {
  const chartData: ChartDataItem[] = skus.map(sku => ({
    ...sku,
    x: sku.salesVelocity,
    y: sku.profitability,
    z: sku.salesVolume, // This will determine bubble size
  }));
  
  const quadrantsForLegend = Object.values(SKUQuadrant).filter(q => q !== SKUQuadrant.UNDEFINED && skus.some(s => s.quadrant === q)).map(q => ({
    value: q.split('(')[0].trim(), // Use short name for legend
    type: 'circle' as LegendType,
    id: q,
    color: QUADRANT_DEFINITIONS[q].chartColor,
  }));


  return (
    <div className="h-full flex flex-col">
      <h2 className="text-2xl font-semibold text-slate-800 mb-1 border-b border-slate-200 pb-3">SKU矩阵可视化</h2>
      <p className="text-sm text-slate-500 mb-6">X轴: 动销指数, Y轴: 利润指数, 气泡大小: 销量</p>
      
      {skus.length === 0 ? (
         <div className="flex-grow flex flex-col items-center justify-center text-center text-slate-500 bg-slate-50 rounded-lg p-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-slate-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            <p className="text-lg font-medium">图表无SKU数据</p>
            <p className="text-sm">请使用表单添加SKU以查看矩阵可视化图表。</p>
        </div>
      ) : (
        <div className="flex-grow min-h-[450px]"> {/* Ensure a minimum height for the chart area */}
            <ResponsiveContainer width="100%" height="100%">
            <ScatterChart
                margin={{
                top: 20, right: 20, bottom: 50, left: 30, // Adjusted margins for labels
                }}
            >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0"/>
                <XAxis 
                    type="number" 
                    dataKey="x" 
                    name="动销指数"
                    unit="" 
                    domain={[0, 100]}
                    ticks={[0, 25, 50, 75, 100]}
                    label={{ value: "动销指数 (0-100)", position: 'insideBottom', offset: -25, dy: 20, style: { fill: '#64748b', fontSize: '0.875rem' } }}
                    style={{ fontSize: '0.75rem', fill: '#64748b' }}
                />
                <YAxis 
                    type="number" 
                    dataKey="y" 
                    name="利润指数" 
                    unit="" 
                    domain={[0, 100]}
                    ticks={[0, 25, 50, 75, 100]}
                    label={{ value: "利润指数 (0-100)", angle: -90, position: 'insideLeft', dx: -25, style: { fill: '#64748b', fontSize: '0.875rem' } }}
                    style={{ fontSize: '0.75rem', fill: '#64748b' }}
                />
                <ZAxis type="number" dataKey="z" range={[100, 1000]} name="销量" unit="" />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<CustomTooltipContent />} />
                <Legend 
                  payload={quadrantsForLegend}
                  verticalAlign="top" 
                  height={36}
                  wrapperStyle={{fontSize: "0.8rem", color: "#334155" }}
                />
                <ReferenceLine x={QUADRANT_MIDPOINT} stroke="#cbd5e1" strokeDasharray="3 3">
                  <Label value={`中点 (${QUADRANT_MIDPOINT})`} position="insideTopRight" fill="#9ca3af" fontSize="0.7rem" dy={-5} />
                </ReferenceLine>
                <ReferenceLine y={QUADRANT_MIDPOINT} stroke="#cbd5e1" strokeDasharray="3 3">
                   <Label value={`中点 (${QUADRANT_MIDPOINT})`} position="insideTopRight" fill="#9ca3af" fontSize="0.7rem" dx={-45} dy={-5}/>
                </ReferenceLine>
                
                {Object.values(SKUQuadrant).filter(q => q !== SKUQuadrant.UNDEFINED).map((quadrant) => (
                  <Scatter 
                    key={quadrant}
                    name={quadrant.split('(')[0].trim()} // Use short name for scatter plot series name
                    data={chartData.filter(d => d.quadrant === quadrant)} 
                    fill={QUADRANT_DEFINITIONS[quadrant].chartColor} 
                    shape="circle"
                   />
                ))}
            </ScatterChart>
            </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

export default SKUMatrixChart;
