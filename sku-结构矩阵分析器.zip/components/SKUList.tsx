
import React from 'react';
import { SKU, SKUQuadrant } from '../types'; // Ensure SKUQuadrant is imported if used for typing quadrantConfig.label
import { QUADRANT_DEFINITIONS } from '../constants';
import { SparklesIcon, TrashIcon } from './icons';

interface SKUListProps {
  skus: SKU[];
  onDeleteSKU: (skuId: string) => void;
  onGetAIInsight: (sku: SKU) => void;
  isApiKeyAvailable: boolean;
}

const SKUList: React.FC<SKUListProps> = ({ skus, onDeleteSKU, onGetAIInsight, isApiKeyAvailable }) => {
  if (skus.length === 0) {
    return (
      <div className="text-center py-10">
        <svg className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
          <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
        </svg>
        <h3 className="mt-2 text-lg font-medium text-slate-800">未添加SKU</h3>
        <p className="mt-1 text-sm text-slate-500">请使用上方表单添加您的第一个SKU。</p>
      </div>
    );
  }

  // Helper to get only the badge relevant classes, not text color or full bg
  const getBadgeBgClass = (quadrant: SKUQuadrant): string => {
    return QUADRANT_DEFINITIONS[quadrant].color; // e.g., 'bg-green-500'
  };
  const getBadgeTextClass = (quadrant: SKUQuadrant): string => {
    const config = QUADRANT_DEFINITIONS[quadrant];
    // Attempt to derive a suitable text color for badges. 
    // This is a simple heuristic; a more robust solution might involve a color contrast library or more specific Tailwind classes.
    if (config.color.includes('yellow') || config.color.includes('amber') || config.color.includes('lime') || config.color.includes('gray-400')) { // Lighter backgrounds
      return config.textColor.replace('text-', 'text-').replace('-700', '-800').replace('-400', '-700'); // Darken text
    }
    return 'text-white'; // Default to white text for darker backgrounds
  };


  return (
    <div>
      <h2 className="text-2xl font-semibold text-slate-800 mb-1 border-b border-slate-200 pb-3">SKU详情与建议</h2>
       <p className="text-sm text-slate-500 mb-6">查看单个SKU数据并获取AI驱动的战略建议。</p>
      <div className="overflow-x-auto rounded-lg border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-100">
            <tr>
              <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">名称</th>
              <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">动销指数</th>
              <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">利润指数</th>
              <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">销量</th>
              <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider">象限</th>
              <th scope="col" className="px-5 py-3.5 text-left text-xs font-semibold text-slate-600 uppercase tracking-wider min-w-[200px]">基础建议</th>
              <th scope="col" className="px-5 py-3.5 text-center text-xs font-semibold text-slate-600 uppercase tracking-wider">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {skus.map((sku) => {
              const quadrantConfig = QUADRANT_DEFINITIONS[sku.quadrant];
              const badgeBgClass = getBadgeBgClass(sku.quadrant);
              const badgeTextClass = getBadgeTextClass(sku.quadrant);
              return (
                <tr key={sku.id} className="hover:bg-slate-50/70 transition-colors duration-150 ease-in-out">
                  <td className="px-5 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{sku.name}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-slate-600">{sku.salesVelocity.toFixed(1)}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-slate-600">{sku.profitability.toFixed(1)}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-slate-600">{sku.salesVolume}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm">
                    <span 
                      className={`px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${badgeBgClass} ${badgeTextClass}`}
                    >
                      {quadrantConfig.label.split('(')[0].trim()}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-sm text-slate-600 max-w-xs break-words">{quadrantConfig.baseRecommendation}</td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm font-medium text-center">
                    <div className="flex items-center justify-center space-x-2">
                      <button
                        onClick={() => onGetAIInsight(sku)}
                        disabled={!isApiKeyAvailable}
                        title={isApiKeyAvailable ? "获取AI洞察" : "API密钥未配置"}
                        aria-label={`获取 ${sku.name} 的AI洞察`}
                        className={`p-2 rounded-md transition-all duration-150 ease-in-out group focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-primary-light ${
                          isApiKeyAvailable 
                          ? 'text-primary hover:text-primary-dark hover:bg-primary/10' 
                          : 'text-slate-400 cursor-not-allowed bg-slate-100'
                        }`}
                      >
                        <SparklesIcon className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => onDeleteSKU(sku.id)}
                        title="删除SKU"
                        aria-label={`删除 ${sku.name}`}
                        className="p-2 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-500/10 transition-all duration-150 ease-in-out group focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-red-500"
                      >
                        <TrashIcon className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SKUList;
