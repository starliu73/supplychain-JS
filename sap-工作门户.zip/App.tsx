
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import PostJobPage from './pages/PostJobPage';
import { Job } from './types';
import { INITIAL_JOBS } from './constants';

const App: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>(() => {
    const savedJobs = localStorage.getItem('sapJobs');
    // Ensure that INITIAL_JOBS is used if localStorage is empty or parsing fails
    let initialData = INITIAL_JOBS;
    if (savedJobs) {
      try {
        const parsedJobs = JSON.parse(savedJobs);
        if (Array.isArray(parsedJobs) && parsedJobs.length > 0) {
          initialData = parsedJobs;
        }
      } catch (e) {
        console.error("Failed to parse jobs from localStorage", e);
      }
    }
    return initialData;
  });

  useEffect(() => {
    localStorage.setItem('sapJobs', JSON.stringify(jobs));
  }, [jobs]);

  const addJob = (newJob: Job) => {
    setJobs(prevJobs => [newJob, ...prevJobs]);
  };

  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen bg-slate-50">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage jobs={jobs} />} />
            <Route path="/post-job" element={<PostJobPage onAddJob={addJob} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;
