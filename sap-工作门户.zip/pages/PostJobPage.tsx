
import React from 'react';
import PostJobForm from '../components/PostJobForm';
import { Job } from '../types';

interface PostJobPageProps {
  onAddJob: (job: Job) => void;
}

const PostJobPage: React.FC<PostJobPageProps> = ({ onAddJob }) => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <PostJobForm onAddJob={onAddJob} />
    </div>
  );
};

export default PostJobPage;
