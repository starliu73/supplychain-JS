
import React, { useState } from 'react';
import { Job } from '../types';
import JobList from '../components/JobList';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';

interface HomePageProps {
  jobs: Job[];
}

const HomePage: React.FC<HomePageProps> = ({ jobs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('');

  const filteredJobs = jobs.filter(job => {
    const titleMatch = job.title.toLowerCase().includes(searchTerm.toLowerCase());
    const companyMatch = job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const descriptionMatch = job.description.toLowerCase().includes(searchTerm.toLowerCase());
    const locationMatch = job.location.toLowerCase().includes(locationFilter.toLowerCase());
    return (titleMatch || companyMatch || descriptionMatch) && locationMatch;
  });

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-gradient-to-r from-sky-600 to-cyan-500 p-8 md:p-12 rounded-xl shadow-xl mb-12 text-white">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">寻找您的下一个 SAP 机会</h1>
        <p className="text-lg md:text-xl opacity-90 mb-6">
          浏览 SAP 生态系统中的最新职位空缺。从咨询到开发，您的理想工作正等待着您。
        </p>
        <Link to="/post-job">
            <Button variant="secondary" size="lg" leftIcon={<PlusCircleIcon className="w-5 h-5"/>} aria-label="发布一个职位空缺">
                发布职位空缺
            </Button>
        </Link>
      </div>

      <div className="mb-10 p-6 bg-white rounded-xl shadow-lg border border-slate-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-slate-700 mb-1">搜索职位 (职位名称, 公司, 关键词)</label>
            <input
              type="text"
              id="search"
              placeholder="例如：FICO, ABAP 开发人员, Innovatech"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-sky-500 focus:border-sky-500"
              aria-label="搜索职位输入框"
            />
          </div>
          <div>
            <label htmlFor="location" className="block text-sm font-medium text-slate-700 mb-1">按地点筛选</label>
            <input
              type="text"
              id="location"
              placeholder="例如：纽约, 远程"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-sky-500 focus:border-sky-500"
              aria-label="按地点筛选输入框"
            />
          </div>
        </div>
      </div>
      
      {filteredJobs.length > 0 && (
        <p className="mb-6 text-sm text-slate-600" aria-live="polite">
          显示 {jobs.length} 个职位中的 {filteredJobs.length} 个。
        </p>
      )}
      <JobList jobs={filteredJobs} />
    </div>
  );
};

export default HomePage;
