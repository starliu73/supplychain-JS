
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-700 text-slate-300 py-8 mt-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <p>&copy; {new Date().getFullYear()} SAP 工作门户. 版权所有.</p>
        <p className="text-sm mt-1">由 AI 和对 SAP 职业的热情驱动</p>
      </div>
    </footer>
  );
};

export default Footer;
