
import React from 'react';
import { Link } from 'react-router-dom';
import BriefcaseIcon from './icons/BriefcaseIcon';
import PlusCircleIcon from './icons/PlusCircleIcon';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-800 text-white shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center space-x-3">
            <BriefcaseIcon className="w-8 h-8 text-sky-400" />
            <span className="text-2xl font-bold tracking-tight">SAP 工作门户</span>
          </Link>
          <nav className="flex items-center space-x-4 sm:space-x-6">
            <Link 
              to="/" 
              className="px-3 py-2 rounded-md text-sm font-medium hover:bg-slate-700 transition-colors"
              aria-label="浏览职位"
            >
              浏览职位
            </Link>
            <Link 
              to="/post-job" 
              className="flex items-center bg-sky-500 hover:bg-sky-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors shadow hover:shadow-lg"
              aria-label="发布一个职位"
            >
              <PlusCircleIcon className="w-5 h-5 mr-2" />
              发布职位
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
