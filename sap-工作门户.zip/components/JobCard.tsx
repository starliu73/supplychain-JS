
import React from 'react';
import { Job } from '../types';
import MapPinIcon from './icons/MapPinIcon';
import BuildingOfficeIcon from './icons/BuildingOfficeIcon';
import BriefcaseIcon from './icons/BriefcaseIcon'; // Using this for employment type

interface JobCardProps {
  job: Job;
}

const JobCard: React.FC<JobCardProps> = ({ job }) => {
  const timeSincePosted = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays <= 1) return "今日发布";
    if (diffDays < 30) return `${diffDays} 天前发布`;
    const diffMonths = Math.floor(diffDays / 30);
    if (diffMonths === 1) return "1 个月前发布";
    return `${diffMonths} 个月前发布`;
  };

  return (
    <div className="bg-white shadow-lg rounded-xl overflow-hidden hover:shadow-xl transition-shadow duration-300 ease-in-out border border-slate-200">
      <div className="p-6">
        <div className="flex items-start space-x-4">
          {job.companyLogo && (
            <img 
              src={job.companyLogo} 
              alt={`${job.company} 公司标志`} 
              className="w-16 h-16 rounded-lg object-cover border border-slate-200"
            />
          )}
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-sky-700 hover:text-sky-800 transition-colors">
              {job.title}
            </h3>
            <div className="mt-1 flex items-center text-sm text-slate-600">
              <BuildingOfficeIcon className="w-4 h-4 mr-1.5 text-slate-400" />
              {job.company}
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-2 sm:space-y-0 text-sm text-slate-500">
          <div className="flex items-center">
            <MapPinIcon className="w-4 h-4 mr-1.5 text-slate-400" />
            {job.location}
          </div>
          <div className="flex items-center">
            <BriefcaseIcon className="w-4 h-4 mr-1.5 text-slate-400" />
            {job.employmentType}
          </div>
          {job.salaryRange && (
            <div className="flex items-center">
              <span className="text-lg mr-1.5 text-slate-400 leading-none">💰</span>
              {job.salaryRange}
            </div>
          )}
        </div>

        <p className="mt-4 text-sm text-slate-600 line-clamp-3 leading-relaxed">
          {job.description}
        </p>

        <div className="mt-6 flex flex-col sm:flex-row sm:justify-between sm:items-center">
          <span className="text-xs text-slate-400 mb-2 sm:mb-0">
            {timeSincePosted(job.postedDate)}
          </span>
          {job.applyUrl && job.applyUrl !== '#' ? (
             <a 
              href={job.applyUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium py-2 px-4 rounded-lg transition-colors shadow hover:shadow-md"
            >
              立即申请
            </a>
          ) : (
             <span className="inline-block bg-slate-200 text-slate-500 text-sm font-medium py-2 px-4 rounded-lg cursor-not-allowed">
              申请 (链接不可用)
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobCard;
