
import React, { useState, ChangeEvent, FormEvent } from 'react';
import { Job, EmploymentType } from '../types';
import { generateJobDescription } from '../services/geminiService';
import Button from './Button';
import Spinner from './Spinner';
import SparklesIcon from './icons/SparklesIcon';

interface PostJobFormProps {
  onAddJob: (job: Job) => void;
}

const PostJobForm: React.FC<PostJobFormProps> = ({ onAddJob }) => {
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [employmentType, setEmploymentType] = useState<EmploymentType>(EmploymentType.FULL_TIME);
  const [salaryRange, setSalaryRange] = useState('');
  const [applyUrl, setApplyUrl] = useState('');
  const [companyLogo, setCompanyLogo] = useState('');
  
  const [aiKeywords, setAiKeywords] = useState('');
  const [isGeneratingDesc, setIsGeneratingDesc] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleGenerateDescription = async () => {
    if (!title) {
      setError("请先输入职位名称以生成描述。");
      return;
    }
    setError(null);
    setSuccessMessage(null);
    setIsGeneratingDesc(true);
    try {
      const generatedDesc = await generateJobDescription(title, aiKeywords);
      setDescription(generatedDesc);
      setSuccessMessage("AI 已成功生成职位描述！");
    } catch (err: any) {
      setError(err.message || "生成描述失败。");
      console.error(err);
    } finally {
      setIsGeneratingDesc(false);
    }
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!title || !company || !location || !description) {
      setError("请填写所有必填字段：职位名称、公司名称、工作地点和职位描述。");
      return;
    }
    setIsSubmitting(true);

    const newJob: Job = {
      id: Date.now().toString(), // Simple ID generation
      title,
      company,
      location,
      description,
      employmentType,
      salaryRange: salaryRange || undefined,
      applyUrl: applyUrl || undefined,
      companyLogo: companyLogo || `https://picsum.photos/seed/${company.replace(/\s+/g, '-').toLowerCase()}/100/100`, // Default placeholder
      postedDate: new Date().toISOString().split('T')[0], // YYYY-MM-DD
    };

    // Simulate API call delay
    setTimeout(() => {
      onAddJob(newJob);
      setSuccessMessage(`职位 "${title}" 发布成功！`);
      // Reset form
      setTitle('');
      setCompany('');
      setLocation('');
      setDescription('');
      setEmploymentType(EmploymentType.FULL_TIME);
      setSalaryRange('');
      setApplyUrl('');
      setCompanyLogo('');
      setAiKeywords('');
      setIsSubmitting(false);
    }, 1000);
  };

  const inputClass = "mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm placeholder-slate-400";
  const labelClass = "block text-sm font-medium text-slate-700";

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-2xl border border-slate-200">
      <h2 className="text-3xl font-bold text-slate-800 mb-8 text-center">发布新的 SAP 职位</h2>
      
      {error && <div className="mb-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded-md" role="alert">{error}</div>}
      {successMessage && <div className="mb-4 p-3 bg-green-100 text-green-700 border border-green-300 rounded-md" role="alert">{successMessage}</div>}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className={labelClass}>职位名称 <span className="text-red-500">*</span></label>
          <input type="text" id="title" value={title} onChange={(e) => setTitle(e.target.value)} className={inputClass} placeholder="例如：高级 SAP MM 顾问" required aria-required="true" />
        </div>

        <div>
          <label htmlFor="company" className={labelClass}>公司名称 <span className="text-red-500">*</span></label>
          <input type="text" id="company" value={company} onChange={(e) => setCompany(e.target.value)} className={inputClass} placeholder="例如：Acme 创新" required aria-required="true" />
        </div>

        <div>
          <label htmlFor="location" className={labelClass}>工作地点 <span className="text-red-500">*</span></label>
          <input type="text" id="location" value={location} onChange={(e) => setLocation(e.target.value)} className={inputClass} placeholder="例如：德国柏林或远程" required aria-required="true" />
        </div>

        <div>
          <label htmlFor="employmentType" className={labelClass}>雇佣类型</label>
          <select id="employmentType" value={employmentType} onChange={(e) => setEmploymentType(e.target.value as EmploymentType)} className={inputClass}>
            {Object.values(EmploymentType).map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        
        <div className="p-4 bg-sky-50 border border-sky-200 rounded-lg">
          <label htmlFor="aiKeywords" className={`${labelClass} mb-1`}>AI 描述关键词 (可选)</label>
          <input type="text" id="aiKeywords" value={aiKeywords} onChange={(e) => setAiKeywords(e.target.value)} className={inputClass} placeholder="例如：S/4HANA, 物流, 敏捷, 团队领导" />
          <Button 
            type="button"
            onClick={handleGenerateDescription}
            isLoading={isGeneratingDesc}
            disabled={isGeneratingDesc || !title}
            variant="secondary"
            size="sm"
            className="mt-3 w-full sm:w-auto"
            leftIcon={<SparklesIcon className="w-4 h-4" />}
            aria-label="使用AI生成职位描述"
          >
            {isGeneratingDesc ? '生成中...' : '使用 AI 生成描述'}
          </Button>
           {!title && <p className="text-xs text-slate-500 mt-1">请先在上方输入职位名称以启用 AI 生成功能。</p>}
        </div>

        <div>
          <label htmlFor="description" className={labelClass}>职位描述 <span className="text-red-500">*</span></label>
          {isGeneratingDesc && <div className="my-2" aria-live="polite"><Spinner size="sm" /> <span className="sr-only">正在生成描述</span></div>}
          <textarea 
            id="description" 
            value={description} 
            onChange={(e) => setDescription(e.target.value)} 
            rows={8} 
            className={inputClass}
            placeholder="详细的职位描述..." 
            required
            aria-required="true"
          />
        </div>

        <div>
          <label htmlFor="salaryRange" className={labelClass}>薪资范围 (可选)</label>
          <input type="text" id="salaryRange" value={salaryRange} onChange={(e) => setSalaryRange(e.target.value)} className={inputClass} placeholder="例如：$100,000 - $130,000 或 €70,000 - €90,000" />
        </div>

        <div>
          <label htmlFor="applyUrl" className={labelClass}>申请链接 (可选)</label>
          <input type="url" id="applyUrl" value={applyUrl} onChange={(e) => setApplyUrl(e.target.value)} className={inputClass} placeholder="https://example.com/apply-here" />
        </div>

        <div>
          <label htmlFor="companyLogo" className={labelClass}>公司Logo链接 (可选)</label>
          <input type="url" id="companyLogo" value={companyLogo} onChange={(e) => setCompanyLogo(e.target.value)} className={inputClass} placeholder="https://example.com/logo.png" />
        </div>

        <Button 
          type="submit" 
          isLoading={isSubmitting} 
          disabled={isSubmitting || isGeneratingDesc}
          className="w-full text-lg"
          size="lg"
        >
          {isSubmitting ? '发布职位中...' : '发布职位空缺'}
        </Button>
      </form>
    </div>
  );
};

export default PostJobForm;
