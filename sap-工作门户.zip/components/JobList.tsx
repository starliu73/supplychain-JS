
import React from 'react';
import { Job } from '../types';
import JobCard from './JobCard';

interface JobListProps {
  jobs: Job[];
}

const JobList: React.FC<JobListProps> = ({ jobs }) => {
  if (jobs.length === 0) {
    return (
      <div className="text-center py-12">
        <img src="https://picsum.photos/seed/empty/300/200" alt="未找到职位" className="mx-auto mb-4 rounded-lg opacity-70" />
        <h2 className="text-2xl font-semibold text-slate-700">未找到职位</h2>
        <p className="text-slate-500 mt-2">请稍后再回来查看或尝试调整您的搜索条件。</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {jobs.map(job => (
        <JobCard key={job.id} job={job} />
      ))}
    </div>
  );
};

export default JobList;
