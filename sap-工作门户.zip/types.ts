
export enum EmploymentType {
  FULL_TIME = "全职",
  PART_TIME = "兼职",
  CONTRACT = "合同",
  INTERNSHIP = "实习",
  TEMPORARY = "临时",
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  postedDate: string; // YYYY-MM-DD
  employmentType: EmploymentType;
  salaryRange?: string;
  applyUrl?: string;
  companyLogo?: string; // URL to company logo
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web: GroundingChunkWeb;
}
