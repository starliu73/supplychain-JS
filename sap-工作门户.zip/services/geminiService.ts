
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_API_MODEL_TEXT } from '../constants';

// This assumes process.env.API_KEY is set in the environment
// In a real Vite/Create React App, you'd use import.meta.env.VITE_API_KEY or process.env.REACT_APP_API_KEY
// For this environment, we directly use process.env.API_KEY as per instructions.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set. Gemini API calls will fail.");
  // alert("Gemini API Key is not configured. AI features will be unavailable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Use non-null assertion as we check above

export const generateJobDescription = async (jobTitle: string, keywords: string): Promise<string> => {
  if (!API_KEY) {
    // This message is for developers, keep in English or make it bilingual if necessary.
    // For user-facing errors, they are handled in the component.
    return Promise.reject("API Key not configured. Cannot generate description."); 
  }
  try {
    const prompt = `
您是一位专业的人力资源助理，专门为 SAP 职位撰写引人入胜的职位描述。
请为以下 SAP 职位生成一份详细且引人入胜的职位描述。
描述应约为 150-250 字。

职位名称: ${jobTitle}
需要包含或侧重的关键职责/技能/关键词: ${keywords || '此职位的标准职责'}

职位描述应包括：
1. 对职位简短而吸引人的介绍。
2. 2-4 项关键职责。
3. 2-4 项基本资格和技能。
4. 可选的 1-2 项优先资格。
5. 简短积极的结束语，鼓励申请。

使用清晰、专业的中文语言。除非是 SAP 特定术语且求职者能够理解，否则避免使用过于复杂的行话。
请勿在回应中使用 markdown。输出适合招聘信息的纯文本。
不要包含像“[公司名称]”这样的占位符；假设描述足够通用或后续会进行调整。
`;

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_API_MODEL_TEXT,
        contents: prompt,
    });
    
    return response.text.trim();

  } catch (error) {
    console.error("Error generating job description with Gemini:", error);
    throw new Error("生成职位描述失败。请重试或手动填写。");
  }
};
