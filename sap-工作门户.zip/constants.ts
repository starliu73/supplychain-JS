
import { Job, EmploymentType } from './types';

export const GEMINI_API_MODEL_TEXT = 'gemini-2.5-flash-preview-04-17';

export const INITIAL_JOBS: Job[] = [
  {
    id: '1',
    title: '高级 SAP FICO 顾问',
    company: 'Innovatech Solutions',
    location: '纽约, NY',
    description: '诚聘经验丰富的 SAP FICO 顾问，负责领导实施项目。要求深入了解财务会计和控制流程。至少8年经验。',
    postedDate: '2024-07-28',
    employmentType: EmploymentType.FULL_TIME,
    salaryRange: '$120,000 - $150,000',
    companyLogo: 'https://picsum.photos/seed/innovatech/100/100',
    applyUrl: '#',
  },
  {
    id: '2',
    title: 'SAP ABAP 开发人员',
    company: 'TechCore Services',
    location: '远程',
    description: '加入我们充满活力的团队，担任 SAP ABAP 开发人员。职责包括开发和维护 SAP 应用程序、自定义报告和接口。必须精通 ABAP、OO ABAP 和 SAP HANA。',
    postedDate: '2024-07-25',
    employmentType: EmploymentType.FULL_TIME,
    salaryRange: '$90,000 - $110,000',
    companyLogo: 'https://picsum.photos/seed/techcore/100/100',
    applyUrl: '#',
  },
  {
    id: '3',
    title: '初级 SAP SD 分析师',
    company: 'GlobalLogix Inc.',
    location: '芝加哥, IL',
    description: '为初级 SAP SD 分析师提供的绝佳机会。支持 SAP 销售和分销模块，协助配置、测试和用户培训。有1-2年经验者优先。',
    postedDate: '2024-07-22',
    employmentType: EmploymentType.FULL_TIME,
    companyLogo: 'https://picsum.photos/seed/globallogix/100/100',
    applyUrl: '#',
  },
  {
    id: '4',
    title: 'SAP Basis 管理员',
    company: 'SecureSys Ltd.',
    location: '奥斯汀, TX',
    description: '我们正在寻找一名熟练的 SAP Basis 管理员来管理我们的 SAP 系统环境。任务包括系统监控、性能调优、升级和安全管理。',
    postedDate: '2024-07-20',
    employmentType: EmploymentType.CONTRACT,
    salaryRange: '$70 - $90 / 小时',
    companyLogo: 'https://picsum.photos/seed/securesys/100/100',
    applyUrl: '#',
  }
];
